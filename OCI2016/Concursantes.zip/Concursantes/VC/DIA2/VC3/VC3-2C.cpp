/**
  Edenys Deniz Gonz�lez
  IPVCE Ernesto Guevara
  11no Grado
  VC7
**/

 #include <bits/stdc++.h>

 using namespace std;

 int main(){
    freopen("FUMIGACION.in", "r", stdin);
    freopen("FUMIGACION.out", "w", stdout);
    int N;
    cin >> N;
    cout<<N<<endl;
    return 0;
 }

