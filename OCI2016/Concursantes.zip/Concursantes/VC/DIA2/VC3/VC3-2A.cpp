/**
  Edenys Deniz Gonz�lez
  IPVCE Ernesto Guevara
  11no Grado
  VC7
**/

 #include <bits/stdc++.h>


 using namespace std;

 vector <int> C_a;
 vector <int> C_b;
 vector <int> R_a;
 vector <int> R_b;
 vector <int> C_c;
 int N, A, B,c1;
 int p1[100],p2[100];
 int Prov(){
    for(int i=0; i<C_a.size(); i++){
        p1[i]=C_a[i];
    }
    for(int i=C_a.size(); i<N; i++){
        p1[i]=R_a[i-C_a.size()];
    }
    sort(p1,p1+N);
    for(int i=0; i<C_b.size(); i++){
        p2[i]=C_b[i];
    }
    for(int i=C_b.size(); i<N; i++){
        p2[i]=R_b[i-C_b.size()];
    }
    sort(p2,p2+N);
    for(int i=0; i<N; i++){
        if(p1[i]>p2[i]){
            return 0;
        }
    }
    return 1;
 }

 int mak[100];
 int main(){
    freopen("TABLAS.in", "r", stdin);
    freopen("TABLAS.out", "w", stdout);
    scanf("%d", &N);
    scanf("%d", &A);

    for(int i=0; i<A; i++){
        scanf("%d", &c1);
        C_a.push_back(c1);
        mak[c1]=1;
    }

    scanf("%d", &B);
    for(int i=0; i<B; i++){
        scanf("%d", &c1);
        C_b.push_back(c1);
        mak[c1]=1;
    }
    if(mak[1]==0){
        mak[1]=1;
        C_a.push_back(1);
        A++;
    }
    if(mak[N*2]==0){
        mak[N*2]=1;
        C_b.push_back(N*2);
        B++;
    }
    for(int i=1; i<=N*2; i++){
        if(mak[i]==0)
            C_c.push_back(i);
    }
    for(int i=0; i<N-A; i++){
        R_a.push_back(C_c[i]);
    }
    for(int i=N-A; i<C_c.size(); i++){
        R_b.push_back(C_c[i]);
    }
    int sv=Prov();
    for(int i=0; i<R_b.size(); i++){
        for(int x=0; x<R_a.size(); x++){
           swap(R_b[i],R_a[x]);
           sv+=Prov();
        }
    }
    printf("%d\n",sv);
    return 0;
 }
