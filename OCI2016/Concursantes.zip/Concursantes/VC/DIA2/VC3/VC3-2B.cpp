/**
  Edenys Deniz Gonz�lez
  IPVCE Ernesto Guevara
  11no Grado
  VC7
**/

 #include <bits/stdc++.h>

 using namespace std;
 struct d{
    int nod,cost;
 };
 vector <d> V[500005];
 int mark[10000][10000];
 int N1[10000];
 int N2[10000];

 int dijk(int nod){
    queue <d> Q;
    int sv=0;
    int markk[10000];
    fill(markk,markk+10000, 0);
     Q.push({nod,0});
     while(!Q.empty()){
        int node=Q.front().nod;
        int cost=Q.front().cost;Q.pop();if(markk[node]==1)continue;
        if(cost>sv)sv=cost;
        markk[node]=1;
        for(int i=0; i<V[node].size(); i++){
            if(mark[node][V[node][i].nod]==0){
                Q.push({V[node][i].nod,cost+V[node][i].cost});
            }
        }
     }
     return sv;
 }

 int Fun(int nod){
     int sv=0;
     int markk[10000];
     fill(markk,markk+10000,0);
     queue <d> Q;
     Q.push({nod,0});
     while(!Q.empty()){
        int node = Q.front().nod;Q.pop();
        if(markk[node]==1){
            continue;
        }
        markk[node]=1;
        sv=max(sv,dijk(node));

        for(int i=0; i<V[node].size(); i++){
            if(mark[node][V[node][i].nod]==0){
                Q.push({V[node][i].nod,0});
            }

        }
     }
     return sv;
 }
 int main(){
    freopen("RUTAS.in", "r", stdin);
    freopen("RUTAS.out", "w", stdout);

    int N,c1,c2,c3;
    scanf("%d", &N);

    for(int i=0; i<N-1; i++){
        scanf("%d%d%d",&c1,&c2,&c3);
        N1[i]=c1;
        N2[i]=c2;
        V[c1].push_back({c2,c3});
        V[c2].push_back({c1,c3});
    }
    for(int i=0; i<N-1; i++){
        mark[N1[i]][N2[i]]=1;
        mark[N2[i]][N1[i]]=1;
        int op1=Fun(N1[i]);
        int op2=Fun(N2[i]);
        printf("%d %d\n", min(op1, op2),max(op1,2));
    }
    return 0;
 }

