



     /**************************************
      *  Nombre: Jose Luis Sanchez Chavez  *
      *  Escuela: Ernesto Che Guevara      *
      *  Grado: 10                         *
      *  Provincia: Villa Clara            *
      *  VC5                               *
      *  CI: 00021970561                   *
      **************************************/



       #include<bits/stdc++.h>
       using namespace std;

       int n,l,w,h;

       int main (){

           freopen( "FUMIGACION.IN","r",stdin );
           freopen( "FUMIGACION.OUT","w",stdout );

           scanf ( "%d%d%d%d",&n,&l,&w,&h );

           for ( int i = 1,a,b; i <= n; i++ ){
                scanf ( "%d%d",&a,&b );
           }
//
//           for ( int i = 1,a,b; i <= 10; i++ ){
//
//                if ( a > b ){
//                    a = b;
//                }
//                else b = a;
//
//                for ( int j = 0; j <= 24; j++  ){
//                     if ( a != b ){
//                        a = b;
//                     }
//                     else b = a;
//                }
//           }

            n = n - 2;


            if ( n = 0 ){
                printf ( "%d",-1 );
                return 0;
            }
            if ( l - n < 0 ){

             printf ( "%d\n",n-2 );

            }
            else{
                printf( "%d\n",-1 );
            }





       return 0;
       }
