



     /**************************************
      *  Nombre: Jose Luis Sanchez Chavez  *
      *  Escuela: Ernesto Che Guevara      *
      *  Grado: 10                         *
      *  Provincia: Villa Clara            *
      *  VC5                               *
      *  CI: 00021970561                   *
      **************************************/



       #include<bits/stdc++.h>
       using namespace std;

       struct two{
              int n;
              bool v;

       };


       int n,a,b,s;

       int ca[36],cb[36],cc[36],c,d;

       bool mk[3][71];


       void fun( int x ){

           if ( x > d ){
               s++;
               return;
           }

            for ( int j = 1; j <= a; j++ ){
                    if ( j == 1 ){
                        if ( cc[x] < ca[j] ){
                            fun( x + 1 );
                        }
                    }

                    if ( j == a ){
                       if ( cc[x] > ca[j] ){
                           fun(x+1);
                       }
                    }

                     if ( cc[x] < ca[j+1] && cc[x] > ca[j] ){

                         fun( x+1 );

                     }
                     }

                     for ( int j = 1; j <= b; j++ ){

                          if ( j == 1 ){
                              if ( cc[x] < cb[j] ){
                                  fun(x+1);
                              }
                          }
                          if ( j == b ){
                              if ( cc[x] > cb[j] ){
                                 fun (x+1);
                              }
                          }

                          if ( cc[x] < ca[j+1] && cc[x] > ca[j] ){
                              fun(x+1);
                          }

                     }
       }



       int main (){

           freopen( "TABLAS.IN","r",stdin );
           freopen( "TABLAS.OUT","w",stdout );


           scanf ( "%d",&n );
           scanf ( "%d",&a );

           for ( int i = 1; i <= a; i++ ){
                scanf ( "%d",&ca[i] );
           }
           sort ( ca+1,ca+a+1 );

           scanf ( "%d",&b );

           for ( int i = 1; i <= b; i++ ){
                scanf ( "%d",&cb[i] );
           }
           sort ( cb+1,cb+1+b );

           for ( int i = 1; i <= 2*n; i++ ){
                c = 0;
           for ( int j = 1; j <= a; j++ ){

                if ( i == ca[j] ){
                    c++;
                    break;
                }
                if ( i < ca[j] )
                    break;
           }
           if ( c == 0 ){
           for ( int j = 1; j <= b; j++ ){

                if ( i == cb[j] ){
                    c++;
                    break;
                }
                if ( i < cb[j] )
                    break;

           }
           }

           if ( c == 0 ){
               cc[++d]=i;
           }

           }
           c = 0;

           fun(1);


           printf ( "%d",s );

       return 0;
       }
