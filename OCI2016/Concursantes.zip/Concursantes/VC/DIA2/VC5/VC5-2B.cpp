



     /**************************************
      *  Nombre: Jose Luis Sanchez Chavez  *
      *  Escuela: Ernesto Che Guevara      *
      *  Grado: 10                         *
      *  Provincia: Villa Clara            *
      *  VC5                               *
      *  CI: 00021970561                   *
      **************************************/



       #include<bits/stdc++.h>
       #define oo (1<<30)
       using namespace std;

       int n,s1,s2;

       vector<int>G[500001];

       int main (){

           freopen( "RUTAS.IN","r",stdin );
           freopen( "RUTAS.OUT","w",stdout );

           scanf ( "%d",&n );

           for ( int i = 1,a,b,c; i <= n-1; i++ ){

                scanf ( "%d%d%d",&a,&b,&c );

                G[i].push_back(a);
                G[i].push_back(b);
                G[i].push_back(c);

           }

           for ( int i = 1,a,b; i <= n-1; i++ ){
                s1 = 0;
                s2 = 0;
                a = G[i][0];
                b = G[i][1];

                for ( int j = i+1; j <= n-1; j++ ){

                     if ( G[j][0] == a ){
                         s1 += G[j][2];
                     }
                     if ( G[j][0] == b ){
                         s2 += G[j][2];
                     }

                }
                printf( "%d %d\n",s2,s1 );
           }


       return 0;
       }
