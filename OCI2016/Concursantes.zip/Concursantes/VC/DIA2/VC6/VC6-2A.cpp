/**
Javier A.Oramas Lopez
IPVCE: Ernesto Guevara
10mo
VC-6
00022567688
**/

  #include <bits/stdc++.h>
  using namespace std;

char A[75], B[75], A1[75], B1[74],C[75];
int N,a,b,c,sol = 0;

int main(){

    freopen("tablas.in","r" , stdin);
    freopen("tablas.out","w" , stdout);

      scanf("%d", &N);

      scanf("%d", &a);
      for(int i = 1; i <= a;i++)
        scanf("%d", &A[i]);

      scanf("%d", &b);
      for(int i = 1; i <= b; i++)
        scanf("%d", &B[i]);

       c = 2*N - (a + b);

        for(int j = 1; j <= N; j++)
            C[j] = j;

         for(int i = 1; i <= a; i++)
            for(int j = 1; j <= N; j++)
              if(C[j] == A[i]) C[i] = -1;

    for(int i = 1;i <= c; i++){
       strcpy(A,A1);
       strcpy(B,B1);

       int j = i;

       for(int k = a; j <= N-a; j++, k++){
               A1[k] = C[j];
               if(j == C[c])
                 j = 1;
         }

       for(int k = j+1, h = b; k <= N-b; k++, h++){
               A1[h] = C[j];
               if(j == C[c])
                 j = 1;
       }

       for(int k = 1; k <= N; k++){
          int s = 0;
          if(A1[k] < A1[k-1]){
            swap(A1[k], A1[k-1]);
            s = 1;
          }
          if(A1[k] < A1[k-1]){
            swap(A1[k], A1[k-1]);
            s = 1;
          }
          if(s > 0)
            k = 1;
       }

      for(int k = 1; k <= N; k++){
        if(A1[k] > B1[k]) break;
        if(k == N) sol++;
      }
    }
    printf("%d", sol-1);

    return 0;
}
