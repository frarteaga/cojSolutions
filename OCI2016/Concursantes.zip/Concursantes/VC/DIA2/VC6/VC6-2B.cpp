/**
Javier A.Oramas Lopez
IPVCE: Ernesto Guevara
10mo
VC-6
00022567688
**/
  #include <bits/stdc++.h>
  #define MAXN 500010
  #define oo 1<<30
  using namespace std;

struct par{
   int nod, cost;
   bool operator <(const par &p) const{
      return cost < p.cost;
   }
};

vector <par> G[MAXN];
priority_queue <par> Q;
queue <par> Q1;
bool mka[MAXN];
bool mkb[MAXN];
int cost[MAXN];
int nnod, ncost,C,men;

int dijkstra(int ni){
    fill(cost, cost+MAXN,oo);
         cost[ni] = 0;
    int mval = 0;
    int nod = ni;
    int costo = 0;
    for(Q.push((par){nod,costo}); !Q.empty(); Q.pop()){
        for(int i = 0; i < G[nod].size(); i++){
               nnod = G[nod][i].nod;
               ncost = G[nod][i].cost + costo;
            if(mka[nnod] != true)
             if(cost[nnod] > ncost){
                cost[nnod] = ncost;
                nod = nnod;
                costo = ncost;
               Q.push((par){nod,costo});
             }
             else nod = ni;

        }
    }

    for(int i = 1;i <= C; i++){
         if(cost[i] != oo && mval < cost[i])  mval = cost[i];
    }
    return mval;
}
int dijkstrab(int ni){
    fill(cost, cost+MAXN,oo);
         cost[ni] = 0;
    int mval = 0;
    int nod = ni;
    int costo = 0;
    for(Q.push((par){nod,costo}); !Q.empty(); Q.pop()){
        for(int i = 0; i < G[nod].size(); i++){
               nnod = G[nod][i].nod;
               ncost = G[nod][i].cost + costo;
            if(mkb[nnod] != true)
             if(cost[nnod] > ncost){
                cost[nnod] = ncost;
                nod = nnod;
                costo = ncost;
               Q.push((par){nod,costo});
             }
             else nod = ni;

        }
    }

    for(int i = 1;i <= C; i++){
         if(cost[i] != oo && mval < cost[i])  mval = cost[i];
    }
    return mval;
}

int a,b,c,ni,x = 0;

int main(){

    freopen("rutas.in","r" , stdin);
    freopen("rutas.out","w" , stdout);

    scanf("%d", &C);

    for(int i = 1; i <= C-1; i++){
        scanf("%d %d %d", &a, &b, &c);
        G[a].push_back((par){b,c});
        G[b].push_back((par){a,c});
        Q1.push((par){a,b});
    }

    for(int i = 1; i <= C-1; i++){
        a = Q1.front().nod;
        b = Q1.front().cost;
        mka[b] = true;

        int l = dijkstra(a);
         if(i == 1)
            men = l;
            printf("%d " ,l);
            mkb[a] = true;
            if(i > 1)
                x = 1;
            if(i > 2)
                x = men;
            printf("%d\n", dijkstrab(b) - x);
            Q.pop();
        }
    return 0;
}
