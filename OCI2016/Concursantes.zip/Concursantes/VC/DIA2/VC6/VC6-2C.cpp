/**
Javier A.Oramas Lopez
IPVCE: Ernesto Guevara
10mo
VC-6
00022567688
**/
  #include <bits/stdc++.h>
  using namespace std;
int a,b,c,d,nu,cu,sol;

int main(){

    freopen("fumigacion.in","r" , stdin);
    freopen("fumigacion.out","w" , stdout);

    scanf("%d %d %d %d", &a, &b,&c,&d);

    for(int i = 1; i <= a; i++){
        scanf("%d %d",&nu, &cu );
    }

    sol = a - (max(c,d)-min(c,d));

    printf("%d",sol);
    return 0;
}
