
 ///-=-=-Marcos A. Gonzales Mejias-=-=- 10mo
 ///-=-=-IPVCE Ernesto Guevara-=-=-=-VC7-=-

 #include<bits/stdc++.h>
 using namespace std;

       int c, h, re, N, i, j, k, l, x1, x2, li, g, C[100];
      long long A[10000][10000], L, W, H;
 int main(){


 freopen("FUMIGACION.in","r",stdin);
 freopen("FUMIGACION.out","w",stdout);

    scanf("%d%d%d%d", &N, &L, &W, &H );

    li = W * H;

    for ( i = 0; i <= N; i++ ){
         scanf("%d%d", &x1, &x2);
           h = 0;
              c++;
              if ( x1 < 1500 || x2 < 1500 ){
              for ( j = x1; j <= x1+W-1; j++ ){
                   for ( k = x2; k <= x2+H-1; k++ ){
                        if ( A[j][k] == 1 ){
                            h++;
                        }
                        else
                            A[j][k] = 1;
                   }
              }
              if ( h == li ){
                  g++;
                       C[g] = c;
                              re = 1;
              }
              }
              else
                re = 0;
    }

   if ( re == 1 ){
    cout<< C[2];
  }
  else
     cout<< "-1";
 return 0;
 }
