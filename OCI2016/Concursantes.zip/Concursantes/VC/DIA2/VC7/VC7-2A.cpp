
 ///-=-=-Marcos A. Gonzales Mejias-=-=- 10mo
 ///-=-=-IPVCE Ernesto Guevara-=-=-=-VC7-=-

 #include<bits/stdc++.h>
 using namespace std;

 struct STU{
      int num, g;
 };

      int B[36], N, M, K, i, j, k, l, o, res, pos, h, g, c, v, b, con;
      STU A[40], T[3][36];
 int main(){


 freopen("TABLAS.in", "r", stdin);
 freopen("TABLAS.out", "w", stdout);

 scanf("%d%d", &N, &M);

 for ( i = 1; i <= M; i++ ){
     scanf("%d", &o);
         A[o].num = o;
             A[o].g = 1;
 }

 scanf("%d", &K);

 for ( j = M+1; j < N*2; j++){
    scanf("%d", &o);
        A[o].num = o;
             A[o].g = 2;
 }

 for ( k = 1; k <= N*2; k++ ){
     if ( A[k].num == 0 ){
         A[k].num = k;
             A[k].g = 3;
     }
      if ( A[k].g == 1 ){
          if ( A[k].num > N ){
              T[1][N].num == k;
                   T[1][N].g++;
          }
          else{
              T[1][k].num = k;
                  T[1][k].g++;
          }
      }
      else{
          if ( A[k].g == 2 ){
                pos = A[k].num / 2;
                    res = A[k].num % 2;
                      if ( res == 1 ){
                          T[2][pos].num = k;
                               T[2][pos].g++;
                      }
                      else{
                            if ( pos == N ){
                                T[2][pos].num = k;
                                    T[2][pos].g++;
                            }
                            else{
                              T[2][pos-1].num = k;
                                   T[2][pos-1].g++;
                            }
                      }
          }
        if ( A[k].g == 3 ){
           c++;
              B[c] = k;
        }
      }

 }

  for ( v = 1; v <= c; v++ ){
       if ( B[v] == 1 ){
          T[1][1].num = B[v];
             T[1][1].g++;
       }
       else{
        if ( B[v] > N ){
          pos = B[v] / 2;
              res = B[v] % 2;
                  if ( res == 1 ){
                      T[2][pos].num = B[v];
                          T[2][pos].g++;
                  }
                  else{
                  if ( B[v] > T[2][pos-1].num && B[v] > T[1][pos-1].num ){
                      T[2][pos-1].num = B[v];
                          T[2][pos-1].g++;
                 }
                 }
       }
       else
        T[1][B[v]].num = B[v];
           T[1][B[v]].g++;
     }

  }
con = 1;
  for ( h = 1; h <= 2; h++ ){
        for ( g = 1; g <= N; g++ ){
              if ( T[h][g].g == 2 ){
                   con++;
              }
           }
  }

  printf("%d", con);

 return 0;
 }
