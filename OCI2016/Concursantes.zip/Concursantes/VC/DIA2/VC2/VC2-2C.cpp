/* Fumigacion */
/* Luis Enrique Saborit Gonzalez VC2 */

 #include <bits/stdc++.h>
 using namespace std;

 int n, p, l, w, h;
 int X[100010], Y[100010], C[2010][2010];
 bool M[2010][2010];

 int cant(int a, int b, int c, int d){
       return C[b][d] - C[a-1][d] - C[b][c-1] + C[a-1][c-1];
 }

 bool check(int k){
      for(int i=0; i<=2000; i++)
         for(int j=0; j<=2000; j++)
             M[i][j] = 0, C[i][j] = 0;

      for(int i=1; i<=k; i++)
          M[X[i]][Y[i]] = 1;

      for(int i=0; i<=l; i++){
          for(int j=0; j<=l; j++){
              if(i > 0)
                 C[i][j] += C[i-1][j];
              if(j > 0)
                 C[i][j] += C[i][j-1];
              if(i > 0 && j > 0)
                 C[i][j] -= C[i-1][j-1];
              if(M[i][j])
                 C[i][j]++;
          }
      }


      for(int i=0; i+w-1<=l; i++){
          for(int j=0; j+h-1<=l; j++){
              if(!cant(i, i+w-1, j, j+h-1))
                 return 0;
          }
      }

      return 1;

 }

 main(){
    freopen("fumigacion.in", "r", stdin);
    freopen("fumigacion.out", "w", stdout);

    scanf("%d%d%d%d", &n, &l, &w, &h);
    for(int i=1; i<=n; i++){
        scanf("%d%d", &X[i], &Y[i]);
        if(X[i] > 2000 || Y[i] > 2000 ){
           printf("-1\n");
           return 0;
        }
    }

    int p = n+1;
    for(int i=log2(n); i>=0; i--){
        if( p-(1<<i)>=0 && check(p-(1<<i)) ){
           p = p - (1<<i);
        }
    }

    if(p==n+1){
       printf("-1\n");
       return 0;
    }


    printf("%d\n", p);

    return 0;
 }
