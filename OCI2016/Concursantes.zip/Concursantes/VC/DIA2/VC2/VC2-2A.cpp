/* Tablas */
/* Luis Enrique Saborit Gonzalez VC2 */

 #include <bits/stdc++.h>
 using namespace std;

 int n, ca, cb, sol, P[100], counta, countb;
 bool A[100], B[100];

 bool check(){
     counta = countb = 0;

     for(int i=1; i < n; i++){
         if(P[i] > P[i+1])
            return 0;
         if(P[i+n] > P[i+n+1])
            return 0;
         if(P[i] > P[i+n])
            return 0;
     }
     if(P[n] > P[2*n])
        return 0;

     for(int i=1; i<=2*n; i++){
         if(1<=i && i<=n && A[P[i]])
            counta++;
         if(n+1<=i && i<=2*n && B[P[i]])
            countb++;
     }

     if(ca==counta && cb==countb)
        return 1;

     return 0;
 }

 main(){
    freopen("tablas.in", "r", stdin);
    freopen("tablas.out", "w", stdout);

    scanf("%d", &n);
    scanf("%d", &ca);
    for(int i=1, a; i<=ca; i++){
        scanf("%d", &a);
        A[a] = 1;
    }
    scanf("%d", &cb);
    for(int i=1, a; i<=cb; i++){
        scanf("%d", &a);
        B[a] = 1;
    }

    for(int i=1; i<=2*n; i++)
        P[i] = i;

    sol += check();

    while(next_permutation(P+1, P+2*n+1)){
        sol += check();
    }

    printf("%d\n", sol);

    return 0;
 }
