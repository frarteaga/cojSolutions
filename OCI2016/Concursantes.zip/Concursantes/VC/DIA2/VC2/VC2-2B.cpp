/* Rutas */
/* Luis Enrique Saborit Gonzalez VC2 */

 #include <bits/stdc++.h>
 using namespace std;

 int cn, v, sol, nd, nn, sa, sb;
 bool mk[500010];
 pair<int, int> V[500010];

 struct par{
     int nod, cost;
     bool mk;
 };

 vector<par> G[500010];

 int tree_diam(int nod){
     mk[nod] = 1;

     int best = 0;

     for(int i=0; i < G[nod].size(); i++){
         int nwn = G[nod][i].nod;
         if(G[nod][i].mk || mk[nwn])
            continue;

         int tmp = tree_diam(nwn) + G[nod][i].cost;
         sol = max(sol, tmp + best);
         best = max(best, tmp);
     }

     return best;
 }

 void prepare(){
     sol = 0;
     for(int i=1; i<=cn; i++)
        mk[i] = 0;
 }

 main(){
    freopen("rutas.in", "r", stdin);
    freopen("rutas.out", "w", stdout);

    scanf("%d", &cn);
    for(int i=1, a, b, c; i < cn; i++){
        scanf("%d%d%d", &a, &b, &c);
        G[a].push_back((par){b, c});
        G[b].push_back((par){a, c});
        V[++v] = make_pair(a, b);
    }

    for(int i=1; i < cn; i++){
        nd = V[i].first;
        nn = V[i].second;

        for(int i=0; i < G[nd].size(); i++)
            if(G[nd][i].nod==nn){
               G[nd][i].mk = 1;
               break;
            }
        for(int i=0; i < G[nn].size(); i++)
            if(G[nn][i].nod==nd){
               G[nn][i].mk = 1;
               break;
            }

        prepare();
        tree_diam(nd);
        sa = sol;

        prepare();
        tree_diam(nn);
        sb = sol;

        if(sa > sb)
           printf("%d %d\n", sb, sa);
        else
           printf("%d %d\n", sa, sb);
    }


    return 0;
 }
