#include<bits/stdc++.h>
using namespace std;

     int N,cb,B[100],ca,A[100],Nu[100],x,C[100];

    int main(){
         freopen("TABLAS.IN","r",stdin);
         freopen("TABLAS.OUT","w",stdout);
       scanf("%d",&N);
       for(int i=1;i<=N*2;i++){
        Nu[i]=i;
       }
       scanf("%d",&ca);
       if(ca>N){
        printf("0");
        return 0;
       }
     for(int i=0;i<ca;i++){

        scanf("%d",&A[i]);
        Nu[A[i]]=0;
     }
     scanf("%d",&cb);
     if(cb>N){
        printf("0");
        return 0;
     }
      for(int i=0;i<cb;i++){

        scanf("%d",&B[i]);
        Nu[B[i]]=0;
      }

           sort(A,A+ca);
          sort(B,B+cb);

          if(ca==N&&cb==N){
            for(int i=0;i<N;i++){
                if(A[i]>B[i]){
                 printf("0");
                 return 0;
            }

          }
          printf("1");
          return 0;
          }

          for(int i=1;i<=N*2;i++){
            if(Nu[i]!=0){
                C[x]=Nu[i];
                x++;
            }

          }



          sort(C,C+x);

          if(ca==N&&cb<N){
            int e=0,d=0;
          for(int i=0;i<N;i++){
            if((B[e]<C[d]&&B[e]!=0)||(C[d]==0&&B[e]!=0)){
                Nu[i]=B[e];
                e++;
            }
            if((B[e]>C[d]&&C[d]!=0)||(B[e]==0&&C[d]!=0)){
                Nu[i]=C[d];
                //printf("%d\n",C[d]);
                d++;
            }
          }
           for(int i=0;i<N;i++){
            //printf("%d %d\n",A[i],Nu[i]);
            if(A[i]>Nu[i]){
                printf("0");
                return 0;
            }
           }
           printf("1");
           return 0;
          }


          if(cb==N&&ca<N){
            int e=0,d=0;
           // printf("bvb");
          for(int i=0;i<N;i++){
            if((A[e]<C[d]&&A[e]!=0)||(C[d]==0&&A[e]!=0)){
                Nu[i]=A[e];
                e++;
            }
            if((A[e]>C[d]&&C[d]!=0)||(A[e]==0&&C[d]!=0)){
                Nu[i]=C[d];
                d++;
            }
          }

           for(int i=0;i<N;i++){
           //printf("%d %d\n",B[i],Nu[i]);
           if(B[i]<Nu[i]){
                printf("0");
                return 0;
            }
           }
           printf("1");
           return 0;
          }


//          for(int i=0;i<ca;i++){
//            printf("%d ",A[i]);
//          }
//          printf("\n");
//          for(int i=0;i<cb;i++){
//            printf("%d ",B[i]);
//          }
//          printf("\n");
//          for(int i=0;i<x;i++){
//            printf("%d ",C[i]);
//          }
           if(A[ca-1]==N&&B[0]==N+1){
            printf("1");
            return 0;
    }
          printf("2");

   return 0;
    }
