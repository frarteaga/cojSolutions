#include<bits/stdc++.h>
using namespace std;

     const int
     oo=1<<2,
     Max=1000000;

     struct par{
     int nod,cost;

     };
     queue<par>Q;
     vector<par>V[Max];
    int N,a,b,c;
   int main(){
       freopen("RUTAS.IN","r",stdin);
       freopen("RUTAS.OUT","w",stdout);
     scanf("%d",&N);
   for(int i=0;i<N;i++)
   scanf("%d%d%d",&a,&b,&c);


    a=0;
    b=0;

   if(N==2){
    printf("0 0");
   return 0;
   }


     while(a>=b){

        int nod=a;
        for(int i=0;i<=c;i++){

          int e=b;
        }

     }
       for(int i=0;i<a;i++){

        scanf("%d",&a);
        a=0;
     }
     scanf("%d",a);
     if(b>a){
        printf("0");
        return 0;
     }
      for(int i=0;i<a;i++){

        scanf("%d",&a);
        a=0;
      }



          if(a==b&&a==c){
            for(int i=0;i<a;i++){
                if(a>b){
                 printf("0");
                 return 0;
            }

          }
          printf("1");
          return 0;
          }

          for(int i=1;i<=N*2;i++){
            if(a!=0){
                a=b;
                a++;
            }

          }




          if(a==b&&a<c){
            int e=0,d=0;
          for(int i=0;i<N;i++){
            if((a<b&&b!=0)||(a==0&&b!=0)){
                a=b;
                e++;
            }
            if((a>b&&b!=0)||(b==0&&a!=0)){
                b=a;
                //printf("%d\n",C[d]);
                d++;
            }
          }
           for(int i=0;i<N;i++){
            //printf("%d %d\n",A[i],Nu[i]);
            if(a>b){
                printf("0");
                return 0;
            }
           }
           printf("1");
           return 0;
          }


          if(a==N&&a<N){
            int e=0,d=0;
           // printf("bvb");
          for(int i=0;i<N;i++){
            if((a<b&&b!=0)||(a==0&&c!=0)){
                c=a;
                e++;
            }
            if((a>b&&c!=0)||(c==0&&a!=0)){
                b=a;
                d++;
            }
          }

           for(int i=0;i<N;i++){
           //printf("%d %d\n",B[i],Nu[i]);
           if(b<a){
                printf("0");
                return 0;
            }
           }
           printf("1");
           return 0;
          }


//          for(int i=0;i<ca;i++){
//            printf("%d ",A[i]);
//          }
//          printf("\n");
//          for(int i=0;i<cb;i++){
//            printf("%d ",B[i]);
//          }
//          printf("\n");
//          for(int i=0;i<x;i++){
//            printf("%d ",C[i]);
//          }
           if(a==N&&b==N+1){
            printf("1");
            return 0;
    }
          printf("2");

     return 0;
   }
