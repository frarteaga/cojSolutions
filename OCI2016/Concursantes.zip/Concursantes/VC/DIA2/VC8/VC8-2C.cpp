//JEZZER GONZALEZ ARDITES
//ERNESTO GUEVARA
//10M0 VILLA CLARA

#include<bits/stdc++.h>
using namespace std ;

   int main () {

   int a , b , c , d , x[10000] ,y[10000] , z ;


    freopen("fumigacion.in", "r" ,stdin) ;
    freopen("fumigacion.out" ,"w" , stdout) ;


    scanf("%d%d%d%d",&a,&b,&c,&d);

      for(int i=1 ; i<=a ; i++)
        scanf("%d%d",&x[i],&y[i]) ;


      sort(x+1,x+a+1) ;
      sort(y+1,y+a+1) ;


   for(int i=2; i<=a ; i++){
    if(x[i]-x[i-1] >= c || y[i]-y[i-1]>=d){
    printf("-1") ;
    break;
    }

      if(i==a){

     srand(z < a) ;
     printf("%d",z);
      }
   }
   return 0 ;
   }
