//JEZZER GONZALEZ ARDITES
//ERNESTO GUEVARA
//10M0 VILLA CLARA

#include<bits/stdc++.h>
using namespace std ;

  int main (){

   freopen("tablas.in","r",stdin);
   freopen("tablas.out","w",stdout);


   int n , b ,a , A[40],B[40] ;

        scanf("%d",&n );

        scanf("%d",&a);
     for(int i=1; i<=a ; i++)
        scanf("%d",&A[i]) ;

        scanf("%d",&b);
    for(int i=1 ; i<=b ; i++)
        scanf("%d",&B[i]);

       if(n==1)
        printf("0") ;
        else
        if(n<=4 && n>1)
         printf("2");
         else
         printf("%d",2*(n-4)+2);


  return 0;
  }
