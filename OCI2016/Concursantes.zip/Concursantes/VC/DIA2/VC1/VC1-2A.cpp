
 /************************************
 * Name: Victor Edel Sanchez Miranda *
 * School: IPVCE "Ernesto Guevara"   *
 * Grade: 12nd VC1 Villa Clara       *
 ************************************/

 #include <bits/stdc++.h>

 #define MAXN 36

 using namespace std;

 long long N, A, B, id[2*MAXN], dp[MAXN][MAXN][2*MAXN], mk[2*MAXN][2*MAXN][2*MAXN];

 void solve( int a, int b, int now ){
     if ( now == 2*N ){
        mk[a][b][now] = true;
        dp[a][b][now] = true;
        return;
     }
     if ( !id[now+1] ){
        if ( a > b ){
           if ( !mk[a][b+1][now+1] )
              solve( a, b+1, now+1 );
           dp[a][b][now] += dp[a][b+1][now+1];
        }
        if ( a < N ){
           if ( !mk[a+1][b][now+1] )
              solve( a+1, b, now+1 );
           dp[a][b][now] += dp[a+1][b][now+1];
        }
     }
     if ( a < N && id[now+1] == 1 ){
        if ( !mk[a+1][b][now+1] )
           solve( a+1, b, now+1 );
        dp[a][b][now] += dp[a+1][b][now+1];
     }
     if ( a > b && id[now+1] == 2 ){
        if ( !mk[a][b+1][now+1] )
           solve( a, b+1, now+1 );
        dp[a][b][now] += dp[a][b+1][now+1];
     }
     mk[a][b][now] = true;
 }

 int main(){

     freopen( "tablas.in", "r", stdin );
     freopen( "tablas.out", "w", stdout );

     scanf( "%d", &N );

     scanf( "%d", &A );
     for ( int i = 0, temp; i < A; i++ )
         scanf( "%d", &temp ), id[temp] = 1;

     scanf( "%d", &B );
     for ( int i = 0, temp; i < B; i++ )
         scanf( "%d", &temp ), id[temp] = 2;

     solve( 0, 0, 0 );

     printf( "%lld\n", dp[0][0][0] );

 return 0;
 }
