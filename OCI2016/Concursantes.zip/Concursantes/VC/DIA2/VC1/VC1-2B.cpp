
 /************************************
 * Name: Victor Edel Sanchez Miranda *
 * School: IPVCE "Ernesto Guevara"   *
 * Grade: 12nd VC1 Villa Clara       *
 ************************************/

 #include <bits/stdc++.h>

 #define MAXN 500005

 using namespace std;

 struct path{
     int a, b, c;
 }way[MAXN];

 struct two{
     int a, b;
 }ans[MAXN], best[MAXN], A, B;

 int N, cost[MAXN];

 bool mk[MAXN];

 queue <int> Q;

 vector <two> G[MAXN];

 void dfs( int nod, int val ){
     cost[nod] = val;
     mk[nod] = true;
     Q.push( nod );
     for ( int next, l = 0; l < G[nod].size(); l++ ){
         next = G[nod][l].a;
         if ( !mk[next] )
            dfs( next, val+G[nod][l].b );
     }
 }

 two diam( int nod ){
     two ret = (two){0, 0}, temp = (two){0, 0};
     mk[nod] = true;
     for ( int next, val, l = 0; l < G[nod].size(); l++ ){
         next = G[nod][l].a;
         val = G[nod][l].b;
         if ( !mk[next] ){
            temp = diam( next );
            if ( ret.a > temp.a+val )
               ret.b = max( ret.b, temp.a+val );
            else
               ret.b = max( ret.a, temp.b+val ), ret.a = temp.a+val;
         }
     }
     return ret;
 }

 int main(){

     freopen( "rutas.in", "r", stdin );
     freopen( "rutas.out", "w", stdout );

     scanf( "%d", &N );

     for ( int i = 1; i < N; i++ )
         scanf( "%d %d %d", &way[i].a, &way[i].b, &way[i].c );

     for ( int i = N-1, nod, big; i > 0; i-- ){
         dfs( way[i].a, 0 );
         big = -1;
         while ( !Q.empty() ){
               if ( cost[Q.front()] > big )
                  big = cost[Q.front()], nod = Q.front();
               mk[Q.front()] = false;
               Q.pop();
         }
         A = diam( nod );
         dfs( way[i].b, 0 );
         big = -1;
         while ( !Q.empty() ){
               if ( cost[Q.front()] > big )
                  big = cost[Q.front()], nod = Q.front();
               mk[Q.front()] = false;
               Q.pop();
         }
         B = diam( nod );
         if ( A.a > B.a ){
            printf( "%d ", A.a );
            printf( "%d\n", max( A.b, B.a ) );
         }
         else {
            printf( "%d ", B.a );
            printf( "%d\n", max( B.b, A.a ) );
         }
         G[way[i].a].push_back( (two){way[i].b, way[i].c} );
         G[way[i].b].push_back( (two){way[i].a, way[i].c} );
     }

 return 0;
 }
