/***Roberto Luis Garcia Quintana**
 ******IPVCE:Ernesto Guevara******
 **********VILLA CLARA************
 **************11NO***************/

#include<bits/stdc++.h>
#define MAXN 500005

using namespace std;

int N,from[MAXN],to[MAXN],cost;
int C[MAXN];

struct two{
int nn,cost;
};

queue<two>Q;
vector<two>V[MAXN];

int main(){

   freopen("RUTAS.in","r",stdin);
   freopen("RUTAS.out","w",stdout);

 scanf("%d",&N);
 for(int i = 1;i <= N-1;i++){
    scanf("%d %d %d",&from[i],&to[i],&cost);
    V[from[i]].push_back((two){to[i],cost});
    V[to[i]].push_back((two){from[i],cost});
 }

 for(int i = 1;i <= N-1;i++){
 V[from[i]=0].push_back((two){to[i]=0,cost=0});
 fill(C+1,C+N+1,0);

 C[from[i]]=0;
 Q.push((two){from[i],N});
 while(!Q.empty()){
    int nod=Q.front().nn;
    Q.pop();

     for(int i = 0;i < V[nod].size();i++){
        int nn = V[nod][i].nn;
        int ncost = V[nod][i].cost + C[nod];

           if( C[nn] > ncost ){
            C[nn] = ncost;
            Q.push((two){nn,C[nn]});
            }
        }
    }
}

  for(int i = 1;i <= N-1;i++){
    printf("%d %d\n",C[i],C[i]);
  }

return 0;
}
