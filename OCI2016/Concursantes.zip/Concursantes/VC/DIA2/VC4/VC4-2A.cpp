/**Roberto Luis Garcia Quintana**
******IPVCE:Ernesto Guevara******
**********VILLA CLARA************
**************11NO**************/

#include<bits/stdc++.h>
#define MAXN 105

using namespace std;

int n,A,B,C;
int a[MAXN],b[MAXN],c[MAXN];

long long fact(int x){
if(x==1 || x==2)
    return x;
else
    return x*fact(x-1);
}

int main(){

    freopen("TABLAS.in","r",stdin);
    freopen("TABLAS.out","w",stdout);

 scanf("%d",&n);

 scanf("%d",&A);
 for(int i = 1;i <= A;i++){
 scanf("%d",&a[i]);
 }
 sort(a,a+A);
 scanf("%d",&B);
 for(int i = 1;i <= B;i++){
 scanf("%d",&b[i]);
 }
 sort(b,b+B);

printf("%I64d",fact(n*2) / ( fact(A+B) + fact(n*2-(A+B)) ) );

return 0;
}
