/**Roberto Luis Garcia Quintana**
******IPVCE:Ernesto Guevara******
**********VILLA CLARA************
**************11NO**************/

#include<bits/stdc++.h>
#define MIN(a,b) ((a<b)?a:b)
#define MAX(a,b) ((a>b)?a:b)
#define MAXN 1000005

using namespace std;

int N,CN,b,a;
int x[MAXN],y[MAXN],x_b[MAXN],y_a[MAXN];

int main(){

   freopen("FUMIGACION.in","r",stdin);
   freopen("FUMIGACION.out","w",stdout);

  scanf("%d %d %d %d",&N,&CN,&b,&a);
  for(int i = 1;i <= N;i++){
    scanf("%d %d",&x[i],&y[i]);
  }

  for(int i = 1;i <= N;i++){
    x_b[i]=x[i]+b;
    y_a[i]=y[i]+a;
  }

  float q=0;
  int t=0;
  for(int i = 1;i <= N;i++){
    float sum=99999;
    for(int j = 1;j <= N;j++){
      float tot=0;
      tot=sqrt( (x_b[i]-x[j])*(x_b[i]-x[j]) + (y_a[i]-y[j])*(y_a[i]-y[j]) );
      sum=MIN(sum,tot);
     }
   if(q < sum){
   q=sum;
   t=i;
   }
  }

  if( q <= t ){
   printf("%d\n",t);
  }
  else{
    printf("-1\n");
  }

return 0;
}
