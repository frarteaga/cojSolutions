//JEZZER GONZALEZ ARDITES
//ERNESTO GUEVARA
//10MO 00061270642
#include<bits/stdc++.h>
using namespace std ;

   int main (){

     int n , m , k , f=1 , c=1 , d=0  ;  ;
     char res[110] , a[210][210] ;


       freopen("robot.in","r" , stdin) ;
       freopen("robot.out" ,"w",stdout);

       scanf("%d%d%d",&n,&m,&k) ;

        for(int i=1; i<=n ;i++)
            for(int j=1 ; j<=m ; j++)
              scanf("%c\n",&a[i][j]) ;


            while(f<=n && c<=m){
                if(a[f+1][c]=='#' || a[f+1][c] >= a[f][c+1]){
                   c++ ;
                   d++ ;
                   res[d]='R' ;
                }
                else
                 if(a[f][c+1]=='#' || a[f][c+1] > a[f+1][c] ){
                    f++ ;
                    d++ ;
                 res[d]='D';
                 }

            }

            d=k ;

            for(int i=1 ; i<=d ; i++)
                printf("%c",res[i]);

   return 0 ;
   }
