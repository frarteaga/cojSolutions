//JEZZER GONZALEZ ARDITES
//ERNESTO GUEVARA
//10MO 00061270642
#include<bits/stdc++.h>
using namespace std;

  int main(){

   freopen("cuentas.in","r",stdin);
   freopen("cuentas.out","w",stdout);



      char  cuentas [210][3010] ;
       int c=0 , d=0  , n ,s , l  ;

    scanf("%d%d%d\n",&n,&l,&s );


     for(int i=1 ; i<=n ; i++)
         for(int j=1 ; j<=l ; j++)
        scanf("%c\n", &cuentas[i][j]);

        for(int i=1 ; i<=n-1 ; i++){
            for(int j=i+1 ; j<=n ; j++){
                  for(int k=1 ; k<=l ; k++){
                if(cuentas[i][k] == cuentas[j][k]){
                        c++ ;
                    }
                  }

                 if(c == l-1 )
                    d++;

                    c=0 ;
            }

        }

            printf("%d",d);


    return 0;
}
