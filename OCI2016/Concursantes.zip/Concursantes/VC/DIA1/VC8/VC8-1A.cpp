//JEZZER GONZALEZ ARDITES
//ERNESTO GUEVARA
//10MO 00061270642
#include<bits/stdc++.h>
using namespace std ;

  int main (){

  int   n , m , s , p , q  ;

     freopen("hexagono.in","r",stdin);
     freopen("hexagono.out","w",stdout);

    scanf("%d%d%d%d%d",&n,&m,&s,&p,&q) ;


         if(m-s>n)

     printf("%d\n", (s*q)+(m-s+1));

          else
            printf("0\n") ;


     printf("%d %d",n+1,n) ;



  }
