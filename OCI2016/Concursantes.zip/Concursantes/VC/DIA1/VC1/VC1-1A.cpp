
 /************************************
 * Name: Victor Edel Sanchez Miranda *
 * School: IPVCE: "Ernesto Guevara"  *
 * Grade: 12nd VC1                   *
 ************************************/

 #include <bits/stdc++.h>

 #define MIN(a, b) ((a<b)?a:b)
 #define DIF(a, b) ((a>b)?a-b:b-a)

 using namespace std;

 typedef unsigned long long int64;

 int64 N, M, S, X, Y, A, B;

 int64 sum( int64 num ){
     if ( num&1 )
        return ((num+1)/2)*num;
     return (num/2)*(num+1);
 }

 int64 value( int64 f, int64 c ){
     int64 lv = MIN( DIF( N, f ), MIN( DIF( c, N+DIF(N, f) ), c-1 ) )+1, loops, tf, tc, temp;
     loops = (sum( N-1 )-sum( N-lv ))*6;
     temp = N-lv+1;
     tc = c-temp+1;
     tf = f-temp+1;
     if ( f == N ){
        if ( c <= N )
           loops += 5*lv-4;
        else
           loops += N-lv;
     }
     if ( f < N ){
        if ( c > lv || ( c == lv && f == lv ) )
           loops += c-lv+1;
        else
           loops += 6*(N-lv)-(f-lv)-lv+2;
     }
     if ( f > N ){
        if ( c > temp )
           loops += lv*4-2-c;
        else
           loops += lv*4+(f-N)-1;
     }
     if ( loops > M )
        return 0;
     loops += S-1;
     return loops;
 }

 int64 find_lv( int64 steps ){
     int64 a = 1, b = N, mid, ret = 1;
     while ( a < b ){
           mid = (a+b)/2;
           if ( (sum( mid-1 )-((mid>1)?sum( mid-2 ):0) )*6 > steps )
              b = mid-1;
           else
              ret = mid, a = mid+1;
     }
     return ret;
 }

 int64 sec( int64 steps ){
     int64 lv = 0;
     for ( int64 temp; steps; ){
         temp = find_lv( steps );
         if ( lv == temp )
            break;
         lv = temp;
         steps -= (sum( lv-1 )-((lv>1)?sum( lv-2 ):0) )*6;
     }
     if ( !steps )
        return N-lv+2;
     else {
        return 0;
     }
 }

 int main(){

     ios_base::sync_with_stdio( 0 );
     cin.tie( 0 );

     freopen( "hexagono.in", "r", stdin );
     freopen( "hexagono.out", "w", stdout );

     cin >> N >> M >> S >> X >> Y;

     cout << value( X, Y ) << '\n';
     S = sec( M );
     if ( S )
        cout << S << ' ' << 1 << '\n';
     else
        cout << N << ' ' << N << '\n';

 return 0;
 }
