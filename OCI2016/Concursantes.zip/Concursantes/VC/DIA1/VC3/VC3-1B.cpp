/******************************
Nombre:Edenys Deniz Gonzalez
Escuela:IPVCE Ernesto Che Guevara
Grado:11no
	    VC3
******************************/
#include <bits/stdc++.h>

using namespace std;

map <string, int> M;
int mark;
int main(){
    freopen("CUENTAS.in", "r", stdin);
    freopen("CUENTAS.out", "w", stdout);
    cin.sync_with_stdio(0);
    cin.tie(0);
    int N,L, O;
    string pal;
    char s;
    cin>>N >>L>>O;
    for(int i=0; i<N; i++){
        cin>>pal;
        if(M.find(pal)!=M.end()){
            mark-=L*M[pal];
            M[pal]++;
        }
        else{
            M[pal]=1;
        }
        for(int i=0; i<pal.size(); i++){
             s=pal[i];
             pal[i]='*';
             if(M.find(pal)!=M.end()){
                mark+=M[pal];
                M[pal]++;
             }
             else{
                M[pal]=1;
             }
             pal[i]=s;
        }
    }
    cout<< mark<<endl;
    return 0;
}
