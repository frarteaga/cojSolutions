/******************************
Nombre:Edenys Deniz Gonzalez
Escuela:IPVCE Ernesto Che Guevara
Grado:11no
	    VC3
******************************/

#include <bits/stdc++.h>

using namespace std;
vector <char> V;
int mat[204][204];
char mark[204][204];
int main(){
    freopen("ROBOT.in", "r", stdin);
    freopen("ROBOT.out", "w", stdout);
    int N, M, K;
    char c;
    scanf("%d%d%d", &N, &M, &K);
    for(int i=1; i<=N; i++){
        scanf("\n");
        for(int x=1; x<=M; x++){
              scanf("%c", &c);
             if(c=='#')
                mat[i][x]=-10000000;
             else{
                mat[i][x]=c-'0';
             }
        }
    }
    for(int i=1; i<=N; i++){
        for(int x=1 ;x<=M; x++){
              if(mat[i-1][x]>mat[i][x-1]){
                 mat[i][x]+=mat[i-1][x];
                 mark[i][x]='D';
              }
              else{
                mark[i][x]='R';
                 mat[i][x]+=mat[i][x-1];
              }
        }
    }
    int c1,c2,sv=0;
    for(int i=1; i<=N; i++){
        if(mat[i][M]>sv){
            sv=mat[i][M];
            c1=i;
            c2=M;
        }
    }
    for(int i=1; i<=M; i++){
        if(mat[N][i]>sv){
            sv=mat[N][i];
            c1=i;
            c2=N;
        }
    }
    while(c1!=1 && c2!=1){
        if(mark[c1][c2]=='D'){
            V.push_back('D');
            c1--;
        }
        else{
            V.push_back('R');
            c2--;
        }
    }
    cout<<"R";
    for(int i= V.size()-1; i>-1; i--){
        cout<<V[i];
    }
    return 0;
}
