/******************************
Nombre:Edenys Deniz Gonzalez
Escuela:IPVCE Ernesto Che Guevara
Grado:11no
	    VC3
******************************/

 #include <bits/stdc++.h>

 using namespace std;
 long long N, M, OP, c1, c2;
 long long lo(){
     if(c1==1||c1==N*2-1)
        return false;
     if(c2==N+c1-1){
        return false;
     }
     if(c2==1)
        return false;
     return true;
 }

 int main (){
     freopen("HEXAGONO.in", "r", stdin);
     freopen("HEXAGONO.out", "w", stdout);
     cin >> N>> M>> OP>>c1 >>c2;
     long long t1=N,t2=M,t3= OP,t4=c1,t5=c2;
     long long sv=OP-1;
     while(lo()){
            sv+=N*(N+1);
            c1--;
            c2--;
            N--;
     }
     int b=0;
     if(c1==1&&c2==1&&b!=1){
        sv++;
        cout<<sv<<endl;
        b=1;
     }
     if(c1<N&&c2<N*2&&b!=1){
        sv+=c2;
        cout<<sv<<endl;
        b=1;
     }

     if(c1<N*2-1&&c2>1&&b!=1){
         sv+=c2;
         sv+=c1-N;
        cout<<sv<<endl;
        b=1;
     }
     int j;
     if(c1==N*2-1&&b!=1){
         if(N%2==0)j=1;
         sv+=N*2-j;
         sv+=N-c2+1;
         cout<<sv<<endl;
         b=1;
     }
     if(c2==1&&b!=1){
        sv+=N*3;
        sv+=(N*2-1)-c1;
        cout<< sv<<endl;
        b=1;
     }

     N=t1;M=t2;OP=t3;sv=OP-1;b=0;
     long long num=OP+M-1;
     long long r=0;
     while(num>sv){
        sv+=N*(N+1);
        N--;
        r++;
     }
     N++;
     r--;
     sv-=N*(N+1);
     if(num<=sv+N){
        cout<< r+1 <<" "<<r+(num-sv);
        return 0;
     }
     sv+=N;
     if(num<sv+N){
        cout<<num-sv+1+r<<" "<<(N+r)*2-1<<endl;
        return 0;
     }
     sv+=N-1;

     if(num<sv+N-1){

         cout<<num-sv+1+r<<" "<<(N)*2-(num-sv)-1+r<<endl;
        return 0;
     }
     sv+=N;
     if(num<=sv){

        cout<<N*2-1+r<< " "<< N- (num-(sv-N))   +r+1<<endl;
        return 0;
     }
     sv+=N;
     if(N%2==1)
     cout<<3+r+sv-num<<" "<<1+r<<endl;
    else{
        cout<<1+r+sv-num<<" "<<1+r<<endl;
    }
     return 0;
 }
