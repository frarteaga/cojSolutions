#include <bits/stdc++.h>
/***
Nombre:Rub�n David P�rez Jim�nez
Grado:11
Escuela: F.O.C. M�rtires de Bolivia
VC10-1B
CI:97110710602
*/
using namespace std;

int n,l,s,diff,sol;
char c[3010][210];

bool differ(int pos1,int pos2){
    diff=0;
    for(int a=0;a<l;a++){
        diff+=c[pos1][a]==c[pos2][a];
        if (diff+1<a){
            break;
        }
    }
    if (diff==l-1){
        return 1;
    }
    return 0;
}

int main (){
    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);
    scanf("%d%d%d",&n,&l,&s);
    for(int a=0;a<n;a++){
        scanf("%s",c[a]);
        for(int b=a-1;b>=0;b--){
            if (differ(a,b)){
                sol++;
            }
        }
    }
    printf("%d",sol);
    return 0;
}
/**
4 3 64
Fax
fax
max
mac
*/
