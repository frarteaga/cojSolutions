#include <bits/stdc++.h>
/***
Nombre:Rub�n David P�rez Jim�nez
Grado:11
Escuela: F.O.C. Martires de Bolivia
VC10-1C
CI:97110710602
*/
using namespace std;

char s[210];
int t[210][210],n,m,k;
bool cam[110],cs[110];
int pot,x=1,y=1,sum,sol;

void game(){
    pot=0,y=1,x=1,sum=0;
    sum+=t[x][y];
    while(t[x][y]!='#'-'0'&&t[x][y]!=10){
        y+=cam[pot]?1:0;
        x+=cam[pot]?0:1;
        sum+=t[x][y];
        if (pot+1==k){
            pot=0;
        }
        else{
            pot++;
        }
    }
    if (t[x][y]=='#'-'0'){
        sum='#'-'0';
    }
}
void dfs(int pos){
    if (pos==k){
        game();
        if (sum!='#'-'0'){
            if (sum-10>sol){
                sol=sum-10;
                for (int a=0;a<k;a++){
                    cs[a]=cam[a];
                }
            }
        }
    }
    else{
        for (int a=0;a<=1;a++){
            cam[pos]=a;
            dfs(pos+1);
        }
    }
}

int main (){
    freopen("ROBOT.IN","r",stdin);
    freopen("ROBOT.OUT","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int a=1;a<=n+1;a++){
        if (a!=n+1){
            scanf("%s",s+1);
            for (int b=0;b<=m+1;b++){
                if (b!=m+1){
                    t[a][b]=s[b]-'0';
                }
                else{
                    t[a][b]=10;
                }
            }
        }
        else{
            fill(t[a],t[a]+m+1,10);
        }
    }
    dfs(0);
    for (int a=0;a<k;a++){
        printf("%c",cs[a]?'R':'D');
    }
    return 0;
}
/**
3 4 3
012#
#045
6###
*/
