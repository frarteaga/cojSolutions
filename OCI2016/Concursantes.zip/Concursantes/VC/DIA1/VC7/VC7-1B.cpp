
///-=-=-Marcos A. Gonzales Mejias-=-=-10mo-=-=
///-=-=-IPVCE Ernesto Che Guevara-=-=-VC7-=-=
///-=-=-=-=-=-CI = 00081070583-=-=-=-=-=-=

 #include<bits/stdc++.h>
 using namespace std;

        int  c, h;
       char A[30050][250];
 int main(){
       int N, M, ALF, i, j, k, l, mul, div;

        freopen("CUENTAS.in", "r", stdin);
        freopen("CUENTAS.out", "w", stdout);

        scanf("%d%d%d", &N, &M, &ALF);

        for ( i = 0; i < N; i++ ){
            scanf("%s",&A[i]);
        }

        for ( k = 0; k <= N; k++ ){
                for ( l = 0; l <= M; l++ ){
                    if ( A[k][l] == A[k+1][l])
                         c++;
             }
             if ( c == M )
                  h++;
                      c = 0;
        }

        printf("%d", h+1);

 return 0;
 }
