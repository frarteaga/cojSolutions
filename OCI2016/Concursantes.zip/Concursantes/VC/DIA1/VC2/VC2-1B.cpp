/* Cuentas */
/* Luis Enrique Saborit Gonzalez  VC2 */

 #include <bits/stdc++.h>
 using namespace std;

 int n, l, s, sol;
 char S[1010];

 int val(char a){
     if(s==2){
        return a - '0';
     }
     else{
        if('a'<=a && a<='z')
           return a-'a';
        if('A'<=a && a<='Z')
           return a-'A'+26;
        if('0'<=a && a<='9')
           return a-'0'+52;
        if(a=='_')
           return 62;
        if(a=='@')
           return 63;
     }
 }

 struct node{
     bool fin;
     node *A[70];
     node(){
         fin = 0;
         memset(A, NULL, sizeof A);
     }

     void update(int p){
         if(l==p){
            fin = 1;
            return;
         }
         if(A[val(S[p])]==NULL)
            A[val(S[p])] = new node();

         A[val(S[p])]->update(p+1);
     }

     int dfs(int p, bool error){
         if(l==p && fin){
            return 1;
         }

         int tmp = 0;

         for(int i=0; i < s; i++){
             if(val(S[p])==i && A[i]!=NULL){
                tmp = A[i]->dfs(p+1, error);
             }
             else{
                if(!error && A[i]!=NULL)
                   tmp += A[i]->dfs(p+1, error + 1);
             }
         }

         return tmp;
     }
 };

 main(){
    freopen("cuentas.in", "r", stdin);
    freopen("cuentas.out", "w", stdout);

    node data = node();

    scanf("%d%d%d\n", &n, &l, &s);

    for(int i=1; i<=n; i++){
        scanf("%s\n", &S);
        sol += data.dfs(0, 0);
        data.update(0);
    }

    printf("%d\n", sol);

    return 0;
 }
