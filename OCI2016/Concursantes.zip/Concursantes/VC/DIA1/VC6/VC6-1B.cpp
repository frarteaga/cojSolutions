///Javier A. Oramas Lopez///
///IPVCE: Ernesto Guevara///
///10mo///
///00022567688///
  #include <bits/stdc++.h>
  using namespace std;

int N,L,S,c = 0, sol = 0;
char cads[30000][210];

int main(){

    freopen("cuentas.in","r" , stdin);
    freopen("cuentas.out","w" , stdout);

  scanf("%d %d %d\n",&N, &L, &S);

   for(int i = 1; i <= N;i++)
    for(int j = 0; j < L; j++)
     scanf("%c\n", &cads[i][j]);

  for(int i = 1, j = 1; i <= N; j++){
      if(j == i && j != N) j++;

      c = 0;

      for(int k = 0; k < L; k++){
        if(cads[i][k] != cads[j][k])
            c++;
            if(c > 1)
                break;
      }

      if(c == 1)
        sol++;
      if(j == N){
        j = i;
        i++;
        }
  }


   printf("%d", sol);
    return 0;
}
