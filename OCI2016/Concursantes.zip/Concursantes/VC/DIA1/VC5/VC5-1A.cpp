

    /*
      Nombre: Jose Luis Sanchez Chavez
      Escuela: Ernesto Che Guevara
      Grado: 10
      Provincia: Villa Clara
      CI: 00021970561
    */

      #include<bits/stdc++.h>
      using namespace std;

      long long n,m,s,p,q,st;

      long long r;

      int main (){

          freopen ( "HEXAGONO.IN","r",stdin );
          freopen ( "HEXAGONO.OUT","w",stdout );

          scanf ( "%I64d%I64d%I64d%I64d%I64d",&n,&m,&s,&p,&q );

          for ( int i = 1; i <= n-1; i++ ){
              st += i * 6;
          }
          printf ( "%I64d\n",st+=s );

          printf ( "%I64d %I64d\n",n,n );

      return 0;
      }
