
    /*
      Nombre: Jose Luis Sanchez Chavez
      Escuela: Ernesto Che Guevara
      Grado: 10
      Provincia: Villa Clara
      CI: 00021970561
    */

      #include<bits/stdc++.h>
      using namespace std;

      int n,l,s,c,d;

      char a;

      vector<char>m[30001];

      int main (){

          freopen ( "CUENTAS.IN","r",stdin );
          freopen ( "CUENTAS.OUT","w",stdout );

          scanf ( "%d%d%d",&n,&l,&s );

          for ( int i = 1; i <= n; i++ ){
             for ( int j = 0; j <= l; j++ ){
                  scanf ( "%c",&a );
                  m[i].push_back(a);
             }
          }

         for ( int i = 1; i <= n; i++ ){
            for ( int j = i+1; j <= n; j++ ){
                    c = 0;
                 for ( int k = 1; k <= l; k++ ){
                     if ( m[i][k] != m[j][k] ){
                         c++;
                     }
            }
                     if ( c == 1 ){
                         d++;
                     }
            }
         }

         printf ( "%d\n",d );

      return 0;
      }
