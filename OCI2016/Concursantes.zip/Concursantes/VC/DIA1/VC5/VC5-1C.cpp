
    /*
      Nombre: Jose Luis Sanchez Chavez
      Escuela: Ernesto Che Guevara
      Grado: 10
      Provincia: Villa Clara
      CI: 00021970561
    */


     #include<bits/stdc++.h>
     #define oo (1<<30)
     using namespace std;

     int n,m,k,g=0,g1,g2,x1,x2,c=0;

     char a,rev[101];

     char ma[201][201];

     bool re[201][201];

     int mat[201][201];

     int main (){

         freopen ( "ROBOT.IN","r",stdin );
         freopen ( "ROBOT.OUT","w",stdout );

         scanf ( "%d%d%d",&n,&m,&k );


         for ( int i = 1; i <= n; i++ ){
            for ( int j = 0; j <= m; j++ ){
                 scanf ( "%c",&ma[i][j] );
                 if ( ma[i][j] == '#' )
                    mat[i][j] = oo;
                 if ( ma[i][j] == '0' )
                     mat[i][j] = 0;

                 if ( ma[i][j] == '1' )
                     mat[i][j] = 1;

                 if ( ma[i][j] == '2' )
                     mat[i][j] = 2;

                 if ( ma[i][j] == '3' )
                     mat[i][j] = 3;

                 if ( ma[i][j] == '4' )
                     mat[i][j] = 4;

                 if ( ma[i][j] == '5' )
                     mat[i][j] = 5;

                 if ( ma[i][j] == '6' )
                     mat[i][j] = 6;

                 if ( ma[i][j] == '7' )
                     mat[i][j] = 7;

                 if ( ma[i][j] == '8' )
                     mat[i][j] = 8;

                 if ( ma[i][j] == '9' )
                     mat[i][j] = 9;

            }
         }

         for ( int i = 1; i <= m; i++ ){
              if ( mat[1][i] != oo ){
                  mat[1][i] += mat[1][i-1];
                  re[1][i] = false;
                  }
              else {
                   for ( int j = i+1; j <= m; j++ )
                        mat[1][j] = oo;
                   break;
              }
         }

         for ( int i = 1; i <= n; i++ ){
              if ( mat[i][1] != oo ){
                  mat[i][1] += mat[i-1][1];
                  re[i][1] = true;
                  }
              else {
                for ( int j = i+1; j <= n; j++ ){
                     mat[j][1] = oo;
                }
                break;
              }
         }

         for ( int i = 2; i <= n; i++ ){
            for ( int j = 2; j <= m; j++ ){
                 if ( mat[i][j] != oo ){
                 if ( mat[i-1][j] != oo && mat[i][j-1] != oo ){
                     if ( mat[i-1][j] > mat[i][j-1] ){
                         mat[i][j] += mat[i-1][j];
                         re[i][j] = true;
                     }
                     else {
                            mat[i][j] += mat[i][j-1];
                            re[i][j] = false;
                     }
                 }
                 else {
                     if ( mat[i-1][j] != oo ){
                         mat[i][j] += mat[i-1][j];
                         re[i][j] = true;
                         }
                     else {
                         if ( mat[i][j-1] != oo ){
                             mat[i][j] += mat[i][j-1];
                             re[i][j] = false;
                         }
                         else{
                            mat[i][j] = oo;
                         }
                     }
                 }
                }
            }
         }

         for ( int i = 1; i <= m; i++ ){
              if ( mat[n][i] != oo && mat[n][i] > g ){
                  g = mat[n][i];
                  g1 = n;
                  g2 = i;
              }
              if ( mat[i][m] != oo && mat[i][m] > g ){
                  g = mat[i][m];
                  g1 = i;
                  g2 = m;
              }
         }
         x1 = g1;
         x2 = g2;

          while ( x1 != 1 || x2 != 1 ){

                 if ( re[x1][x2] == true ){
                     x1 -= 1;
                     rev[++c] = 'D';
                 }
                 else {
                        x2 -=1;
                        rev[++c] = 'R';
                 }

          }

          for ( int i = c; i >= 1 && k >= 1; i--,k-- ){
               printf ( "%c",rev[i] );
          }

     return 0;
     }
