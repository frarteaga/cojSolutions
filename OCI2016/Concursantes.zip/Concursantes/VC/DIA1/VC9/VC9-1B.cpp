/***Alexei Luis Diaz Acosta***
**********Villa Clara********
***IPVCE Ernesto Guevara****
******VC-9***11no grado****
*****CI:99062310448*******/
#include<bits/stdc++.h>
 using namespace std;

     int N,L,S,cant,dif;
     char C[30001][201];

     int main(){
     freopen("CUENTAS.IN","r",stdin);
     freopen("CUENTAS.OUT","w",stdout);
     scanf("%d %d %d",&N,&L,&S);

        for(int i=0;i<N;i++){

           for(int e=0;e<L;e++){

            scanf(" %c",&C[i][e]);
           }
        }

           for(int i=0;i<N;i++){
             for(int e=i+1;e<N;e++){
                dif=0;
                for(int j=0;j<L;j++){
                    //printf("%c %c\n",C[i][j],C[e][j]);
                    if(C[i][j]!=C[e][j]){
                        dif++;
                    //printf("%d/n",dif);
                    }
                    if(dif>1)
                        break;
                }
                if(dif==1)
                    cant++;
             }
           }
          printf("%d",cant);

    return 0;
     }

