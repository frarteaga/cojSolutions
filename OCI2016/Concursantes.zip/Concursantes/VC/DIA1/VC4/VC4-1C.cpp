/**Roberto Luis Garcia Quintana**
******IPVCE:Ernesto Guevara******
**********VILLA CLARA************
**************11NO**************
***********99122710447*********/


#include<bits/stdc++.h>
#define MAXN 10005
#define MAXT 1005

using namespace std;

int f,c,can,M=0,ff,cf;
char tab[MAXT][MAXT];
int C[MAXT][MAXT];
char mov[MAXT];

struct two{
int f,c;
};

queue<two>Q;

const int mf[]={1,0},
          mc[]={0,1};

int main(){

    freopen("ROBOT.in","r",stdin);
    freopen("ROBOT.out","w",stdout);

  scanf("%d %d %d",&f,&c,&can);
   for(int i = 0;i < f;i++){
     for(int j = 0;j < c;j++){
       scanf("%c",&tab[i][j]);
       C[i][j]=1<<30;
       if(tab[i][c] != '#')
        ff=i;
        cf=c;
       }
   }

  C[1][1]=0;
  Q.push((two){1,1});
  while(!Q.empty()){
    int f=Q.front().f;
    int c=Q.front().c;
    Q.pop();

       for(int i = 0;i < 2;i++){
         int nf=mf[i]+f;
         int nc=mc[i]+c;

            if(nf < 0 || nf > f || nc < 0 || nc > c || tab[nf][nc]=='#')continue;

                 if(C[nf][nc]>C[f][c]+1 && tab[nf][nc] == tab[f+1][c]){
                  C[nf][nc]=C[f][c]+1;
                  M++;
                  mov[M]='D';
                  Q.push((two){nf,nc});
                  }

                 if(C[nf][nc]>C[f][c]+1 && tab[nf][nc] == tab[f][c+1]){
                     C[nf][nc]=C[f][c]+1;
                     M++;
                     mov[M]='R';
                     Q.push((two){nf,nc});
                     }

          }
    }

  for(int i = 1;i <= can;i++){
    if(i%2==0){
        printf("D");
    }
    if(i%2!=0){
        printf("R");
    }
  }


return 0;
}
