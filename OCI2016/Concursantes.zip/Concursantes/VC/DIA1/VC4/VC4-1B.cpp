/**Roberto Luis Garcia Quintana**
******IPVCE:Ernesto Guevara******
**********VILLA CLARA************
**************11NO**************
***********99122710447*********/


#include<bits/stdc++.h>

using namespace std;

int N,C,x;
char cad[205][100005];

int main(){

freopen("CUENTAS.in","r",stdin);
freopen("CUENTAS.out","w",stdout);

 scanf("%d %d %d",&N,&C,&x);

  for(int i = 0;i < N;i++){
     for(int j = 0;j < C;j++){
      scanf("%c\n",&cad[i][j]);
    }
  }

  int par=0;
  for(int i = 0;i < N;i++){
    for(int j = i+1;j < N;j++){
     int c=0;
       for(int k = 0;k < C;k++){
          if(cad[i][k] == cad[j][k]){
          c++;
     }
    }

  if(c == C-1){
    par++;
    ///printf("%d %d\n",i,j);
    }

    }
  }

  printf("%d",par*2);

return 0;
}
