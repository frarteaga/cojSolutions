/**Roberto Luis Garcia Quintana**
******IPVCE:Ernesto Guevara******
**********VILLA CLARA************
**************11NO**************
***********99122710447*********/

#include<bits/stdc++.h>

using namespace std;

int side,s,f,c,C,sol;
long long tot=0,x=0,y=0,sum=0;

int main(){

  freopen("HEXAGONO.in","r",stdin);
  freopen("HEXAGONO.out","w",stdout);

 scanf("%d%d%d%d%d",&side,&C,&s,&f,&c);

  x=((side*2-1)*(side*2))/2;
  y = (side-1)*side/2;
  sum=(x-y)*2-(side*2-1);

  if(sum != C){
    printf("%d\n",sol);
    printf("%d %d",side+1,side-1);
  }

  if(sum == C){
    sol=sum+s-1;
    printf("%d\n",sol);
    printf("%d %d\n",side,side);
  }

return 0;
}
