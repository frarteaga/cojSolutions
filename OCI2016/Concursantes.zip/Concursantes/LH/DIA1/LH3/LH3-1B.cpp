#include <iostream>
#include <cstdio>

using namespace std;

char arre[30005][205];

int main()
{
    //cin.tie(0);
    //ios_base::sync_with_stdio(0);

    freopen("cuentas.in", "r", stdin);
    freopen("cuentas.out", "w", stdout);

    int n, l, s, sol = 0;
    //cin >> n >> l >> s;
    scanf("%d %d %d", &n, &l, &s);

    for(int i = 0; i < n; i++)
        for(int j = 0; j < l; j++)
            cin >> arre[i][j];

    for(int i = 0; i < n; i++)
        for(int j = i + 1; j < n; j++)
        {
            int cont = 0;
            int lug = 0;
            for(lug; lug < l; lug++)
            {
                if(arre[i][lug] != arre[j][lug])
                    {
                        cont++;
                        if(cont > 1)
                            break;
                    }
            }
            if(lug == l)
                sol++;
        }
    printf("%d", sol);
    return 0;
}
