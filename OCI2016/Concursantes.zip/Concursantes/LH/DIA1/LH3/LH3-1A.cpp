#include <iostream>
#include <cstdio>
#define ll long long

using namespace std;

struct com
{
    ll n;//numero
    ll fila;
};

com arre[10000000];

int main()
{
    //cin.tie(0);
    //ios_base::sync_with_stdio(0);

    freopen("hexagono.in", "r", stdin);
    freopen("hexagono.out", "w", stdout);

    ll n, m, s, p, q;
    cin >> n >> m >> s >> p >> q;
    arre[0].n = s;
    ll conti = 0;
    ll contm = 0;
    ll contr = 0;
    ll fila = 1;
    ll cont = -1;//cuantas casillas hay en ese lado;
    ll iteraciones = 0;// cant de vueltas que he dado;
    ll o = 1; // operacion;
    ll a = n; // lado opuesto
    ll b = n * 2 - 2;
    for(ll i = 0; i < m; i++)
    {
        if(i == 0)
            arre[0].n = s;
        else
            arre[i].n = arre[i - 1].n + 1;
        if(conti < a && o == 1) // igual1
        {
                arre[i].fila = fila;
                conti++;
        }
        else if(conti == a && o == 1)
        {
            conti = 0;
            o++;
            a--;
        }
        if(contm < b && o == 2) // suma
        {
            fila++;
            arre[i].fila = fila;
            contm++;
        }
        else if(contm == b && o == 2)
        {
            o++;
            contr = 0;
            b--;
        }
        if(conti < a && o == 3) // igual2
        {
            arre[i].fila = fila;
            conti++;
        }
        else if(conti == a && o == 3)
        {
            o++;
            conti = 0;
            a--;
        }
        if(contr < b && o == 4) // resta
        {
            fila--;
            arre[i].fila = fila;
            contr++;
        }
        else if(contr == b && o == 4)
        {
            contm = 0;
            o = 1;
            b--;
        }
        arre[i].fila = fila;
    }
    printf("23\n");
    cout << arre[m - 1].fila << " " << endl;

    return 0;
}
