#include <bits/stdc++.h>

using namespace std;
struct est{
char cuentas[209];

};
int cont;
int n,l,s,res=0;
est arr[30009];


int main()
{
    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);
    cin>>n>>l>>s;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<l;j++)
            cin>>arr[i].cuentas[j];
    }
    for(int i=0;i<n-1;i++)
        {
            for(int j=i+1;j<n;j++)
                {
                    cont=0;
                    for(int y=0;y<l;y++)
                    {
                        if(arr[i].cuentas[y]!=arr[j].cuentas[y])
                        {
                            cont++;

                        }
                        if (cont==2)
                            break;
                    }
                    if (cont==1)
                    {
                        res++;
                    }
                }

        }
        cout<<res;


    return 0;
}




