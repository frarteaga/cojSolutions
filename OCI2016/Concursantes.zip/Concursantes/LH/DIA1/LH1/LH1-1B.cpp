#include <bits/stdc++.h>
#define endl '\n'
using namespace std;

int n,l,s,sol;

void similar(string a,string b)
{   int cont=0;
    for(int k=0;k<l;k++)
        if(a[k]!=b[k])
        {
            cont++;
            if(cont>1)
                break;
        }
    if(cont==1)
        sol++;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);
    cin >> n >> l >> s;
    string arr[n];
    for(int i=0;i<n;i++)
        cin >> arr[i];

    for(int i=0;i<n;i++)
        for(int j=i+1;j<n;j++)
            similar(arr[i],arr[j]);

    cout << sol << endl;
    return 0;
}
