#include <bits/stdc++.h>
#define endl '\n'
using namespace std;
unsigned long long n,m,s,done,mi,add,vals[2*1000-1][2*1000-1],e=0;
long long p,q,dis;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    freopen("HEXAGONO.IN","r",stdin);
    freopen("HEXAGONO.OUT","w",stdout);
    cin >> n >> m >> s >> p >> q ;
    int val=s;
    int pp=1,qq=1;
    for(int k=n-1;k>0;k--)
    {
    if(pp==p && qq==q)
        cout << val << endl;
    int arr[6]={k,k,k,k,k,k-1};
    for(int i=0;i<6;i++)
    {
        for(int j=0;j<arr[i];j++)
        {
            if(i==0)
            {
                qq++;
                val++;
                if(val-s>m-1)
                {   e = 1;
                    break;
                }
                vals[pp][qq]=val;
                if(pp==p && qq==q)
                    cout << val << endl;
            }
            else if(i==1)
            {
                qq++;
                pp++;
                val++;
                if(val-s>m-1)
                {   e = 1;
                    break;
                }
                vals[pp][qq]=val;
                if(pp==p && qq==q)
                    cout << val << endl;
            }
            else if(i==2)
            {
                qq--;
                pp++;
                val++;
                if(val-s>m-1)
                {   e = 1;
                    break;
                }
                vals[pp][qq]=val;
                if(pp==p && qq==q)
                    cout << val << endl;
            }
            else if(i==3)
            {
                qq--;
                val++;
                if(val-s>m-1)
                {   e = 1;
                    break;
                }
                vals[pp][qq]=val;
                if(pp==p && qq==q)
                    cout << val << endl;
            }
            else if(i==4)
            {
                pp--;
                val++;
                if(val-s>m-1)
                {   e = 1;
                    break;
                }
                vals[pp][qq]=val;
                if(pp==p && qq==q)
                    cout << val << endl;
            }
            else if(i==5)
            {
                pp--;
                val++;
                if(val-s>m-1)
                {   e = 1;
                    break;
                }
                vals[pp][qq]=val;
                if(pp==p && qq==q)
                    cout << val << endl;
            }
        }
        if(e)
            break;
    }
    qq++;
    val++;
    vals[pp][qq]=val;
    if(e)
        break;
    }
    int ma=0,ii;
    for(int i=0;i<2*n-1;i++)
    {
        if(ma<vals[i][q])
        {
            ma=vals[i][q];
            ii=i;
            qq=q;
        }
    }

    cout << ii << " " << qq << endl;
    return 0;
}
