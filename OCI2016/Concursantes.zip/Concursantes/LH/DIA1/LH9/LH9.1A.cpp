#include <bits/stdc++.h>

using namespace std;

int main()
{ //freopen(pares.in) "r" stdin)
  //freopen(pares.out) "w" stdout)

   int arre [1000],a , b , c , d ;

   for (int i = 0 ; i < 4 ; i++ )
   {
       cin >> arre[i];
   }

   for (int i = 0 ; i < 4 ; i ++)
   cin >> a >> b >> c >> d;
   if (a == b);
   if (b == a);
   if (b == c);
   if (c == b);
   if (c == d);
   if (d == c);
   cout << " 4 " << endl;



    return 0;
}
