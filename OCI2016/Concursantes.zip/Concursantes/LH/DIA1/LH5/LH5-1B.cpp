#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);
    int n,l,s;
    scanf("%d%d%d",&n,&l,&s);
    char x[l];
    for(int i=0;i<l;i++){
    scanf("%c",&x[i]);
    }
    printf("%d",n);
}
