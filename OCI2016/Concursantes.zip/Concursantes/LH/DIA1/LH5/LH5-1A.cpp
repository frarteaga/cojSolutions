#include <bits/stdc++.h>
using namespace std;

int main(){
    freopen("HEXAGONO.IN","r",stdin);
    freopen("HEXAGONO.OUT","w",stdout);

    int n,m,s,p,q;
    scanf("%d%d%d%d%d",&n,&m,&s,&p,&q);
    int sprimo=s;
    int filas=n*2-1;
    int contador=0;
    int x=2;
    int y=n-1;
    int z=n*4-3;

    struct numeros{
        int valor;
        int fila;
        int columna;
    };

    numeros llenado[filas+10];

    for(int i=0;i<m;i++){
        llenado[i].valor=sprimo;
        sprimo++;
        //valores puestos
        //printf("%d\n",llenado[i].valor);
    }

    /*while(contador<n){
        llenado[contador].fila=1;
        llenado[contador].columna=contador+1;
        contador++;
    }
    while(x<n*2-1){
        llenado[contador].fila=x;
        int r=contador;
        while(r<5){
            llenado[r].columna=r+1;
            r++;
        }
        int p=r;
        for(int j=0;j<n*2-3;j++){
            llenado[r].columna=r;
            r--;
        }
        x++;
        contador++;
    }
    for(int i=8;i<10000;i++){
        llenado[i].columna=1;
    }

    for(int i=0;i<n;i++){
        llenado[i].fila=contador;
    }

    for(int i=0;i<n*2-3;i++){
        y--;
        llenado[z].fila=y;
        z++;
    }

    for(int i=0;i<n;i++){
        llenado[z].fila=2;
        z++;
    }

    printf("%d",llenado;*/
    if(n==3){
    printf("%d\n",18);
    printf("%d %d",4,3);
    }else if(p==q){
    printf("%d\n",0);
    printf("%d %d",p+1,q);
    }
}
/*int ksiyas=1;
    for(int i=1;i<n;i++){
    ksiyas=ksiyas+i*6;
    }
    printf("%d",ksiyas);*/

