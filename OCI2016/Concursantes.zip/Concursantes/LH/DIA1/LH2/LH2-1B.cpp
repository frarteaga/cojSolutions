#include <bits/stdc++.h>
#define endl '\n'
using namespace std;

int N, L, S;
string *strs;

bool similar(string a, string b) {
    int counter=0;
    for (int j=0; j < L; j++) {
        if (a[j]!=b[j])
            counter++;
        if (counter > 1) {
            return false;
        }
    }
    return (counter==1)? true : false;
}

int similars() {
    int scounter=0;
    for (int g=0; g < N; g++) {
        for (int h=g+1;h < N; h++) {
            if (similar(strs[g],strs[h]))
                scounter++;
        }
    }
    return scounter;
}

int main()
{
    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);
    ios_base::sync_with_stdio(0);

    cin >> N >> L >> S;
    strs=new string[N];
    int i=N;
    while (i--) {
        cin >> strs[i];
    }
    cout << similars() << endl;
}
