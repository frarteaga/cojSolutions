#include<stdio.h>

int main(){
    FILE* entrada = fopen("ROBOT.IN", "r");
    FILE* salida = fopen("ROBOT.OUT", "w");
    fclose(entrada);
    fprintf(salida, "DRR");
    fclose(salida);

    return 0;
}
