#include<stdio.h>

int matriz[1000][1000];

int main(){
    int n, m, s, p, q, h = 0, j, mitad, col, total, x, y;

    FILE* entrada = fopen("HEXAGONO.IN", "r");
    FILE* salida = fopen("HEXAGONO.OUT", "w");

    fscanf(entrada, "%d%d%d&d%d", &n, &m, &s, &p, &q);
    fclose(entrada);
    col = n * 2 - 1;
    mitad = (col + 1) / 2;
    total = m + s - 1;
    while(s < total){
    for(int i = h; i < n; ++i){\
        if(s == total){
            x = h; y = i;
            break;
        }
        matriz[h][i] = s;
        s++;
    }
    j = n;
    if(s != total)
    for(int i = (h + 1); i < n; ++i){
        if(s == total){
            x = i; y = j;
            break;
        }
        matriz[i][j] = s;
        s++;j++;
    }
    j -= 2;
    if(s != total)
    for(int i = mitad; i < col; ++i){
        if(s == total){
            x = i; y = j;
            break;
        }
        matriz[i][j] = s;
        s++;j--;
    }
    if(s != total)
    for(int i = (n - 2); i >= h; ++i){
        if(s == total){
            x = (col - 1); y = i;
            break;
        }
        matriz[col - 1][i] = s;
        s++;
    }
    if(s != total)
    for(int i = (col - 2); i > (h + 1); ++i){
        if(s == total){
            x = i; y = h;
            break;
        }
        matriz[i][h] = s;
        s++;
    }
    h++;
    n--;
    col--;
    }
    fprintf(salida, "%d\n", matriz[p][q]);
    fprintf(salida, "%d %d", x, y);
    fclose(salida);

    return 0;
}
