/*
-----------CONCURSO NACIONAL DE COMPUTACIO'N 2015_2016--------------
ESCUELA: IPVCE: VLADIMIR ILICH LENIN.
PROBLEMA: C-ROBOT. DIA: 1
*/
#include <bits/stdc++.h>

using namespace std;

int N, M;
unsigned int K;
char mapa[201][201];
string func(); //FUNCIO'N QUE DEVUELVE EL COMANDO CORRECTO
map <string, bool> comandos;
bool dfs(string comand); //FUNCIO'N QUE COMPRUEBA EL COMANDO
int movX[] = {0, 1};
int movY[] = {1, 0};
//            R, D

int main()
{
    cin.tie(0);
    ios_base::sync_with_stdio(0);
    freopen("ROBOT.IN", "r", stdin);
    freopen("ROBOT.OUT", "w", stdout);
    cin >> N >> M >> K;
    for (int i = 0; i < N; i ++)
        cin >> mapa[i];

    cout << func();
    return 0;
}

bool dfs(string comand)
{
    int fila = 0, col = 0;
    while (1)
    {
        for (unsigned int b = 0; b < comand.size(); b ++)
        {
            if (mapa[fila][col] == '#')
                return false;

            if (fila >= N || col >= M)
                return true;

            if (comand[b] == 'R')
                col ++;

            else
                fila ++;
        }
    }
    return false;
}

string func()
{
    string c = "";
    int temp = 0, fila = 0, col = 0;
    while (1)
    {
        if (mapa[fila + movX[temp]][col + movY[temp]] == '#')
        {
            temp ++;
            if (temp == 2)
                temp = 0;
        }
        else
        {
            if (temp == 0)
                c += 'R';

            else
                c += 'D';

            fila += movX[temp];
            col += movY[temp];
        }

        if (c.size() == K)
        {
            if (!comandos[c] && dfs(c))
                return c;

            if (!comandos[c] && !dfs(c))
            {
                comandos[c] = true;
                c = "";
                fila = col = temp = 0;
            }
        }
    }
}
