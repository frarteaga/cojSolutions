/*
-----------CONCURSO NACIONAL DE COMPUTACIO'N 2015_2016--------------
ESCUELA: IPVCE: VLADIMIR ILICH LENIN.
PROBLEMA: B-CUENTAS. DIA: 1
*/
#include <bits/stdc++.h>

using namespace std;

int N, L, S;
string *cuentas;
int func();
bool similar(string cad, string cad2);

int main()
{
    cin.tie(0);
    ios_base::sync_with_stdio(0);

    freopen("CUENTAS.IN", "r", stdin);
    freopen("CUENTAS.OUT", "w", stdout);

    cin >> N >> L >> S;
    cuentas = new string [N];
    for (int i = 0; i < N; i ++)
        cin >> cuentas[i];

    cout << func();

    delete [] cuentas;
    return 0;
}

int func()
{
    int cont = 0;
    for (int j = 0; j < N; j ++)
    {
        for (int k = j + 1; k < N; k ++)
        {
            if (similar(cuentas[j], cuentas[k]))
                cont ++;
        }
    }
    return cont;
}

bool similar(string cad, string cad2)
{
    int carac = 0;
    for (int h = 0; h < L; h ++)
    {
        if (cad[h] != cad2[h])
            carac ++;

        if (carac > 1)
            return false;
    }
    return true;
}
