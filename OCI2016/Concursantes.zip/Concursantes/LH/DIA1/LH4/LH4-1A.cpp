/*
-----------CONCURSO NACIONAL DE COMPUTACIO'N 2015_2016--------------
ESCUELA: IPVCE: VLADIMIR ILICH LENIN.
PROBLEMA: A-HEXAGONO. DIA: 1
*/
#include <bits/stdc++.h>
#define ull unsigned long long

using namespace std;

ull hexa[10000][10000];
bool visit[10000][10000];
ull N, M, S, P, Q;
ull mayorFil, mayorCol;
ull limit;
void crear();
int sentX[] = {0, 1, 1, 0, -1};
int sentY[] = {1, 1, -1, -1, 0};

int main()
{
    cin.tie(0);
    ios_base::sync_with_stdio(0);

    freopen("HEXAGONO.IN", "r", stdin);
    freopen("HEXAGONO.OUT", "w", stdout);
    cin >> N >> M >> S >> P >> Q;
    limit = (N - 1) * 2;
    crear();
    cout << hexa[P - 1][Q - 1] << '\n' << mayorFil << " " << mayorCol;

    return 0;
}

void crear()
{
    ull fila = 0, colum = 0, temp = 0;
    visit[0][N] = true;
    visit[N][limit] = true;

    for (ull num = S; num < S + M; num ++)
    {
        hexa[fila][colum] = num;
        if (num == S + M - 1)
        {
            mayorFil = fila + 1;
            mayorCol = colum + 1;
        }
        visit[fila][colum] = true;
        if (visit[fila + sentX[temp]][colum + sentY[temp]] || fila + sentX[temp] > limit || colum + sentY[temp] > limit || fila + sentX[temp] < 0 || colum + sentY[temp] < 0)
            temp ++;

        if (temp == 5)
            temp = 0;

        fila += sentX[temp];
        colum += sentY[temp];
    }
}
