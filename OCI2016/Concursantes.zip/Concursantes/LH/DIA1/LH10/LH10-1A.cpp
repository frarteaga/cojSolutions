/*LH10-1A.cpp C++
LH10 Jos� Gabriel Navarro Comabella 12 grado IPVC Vladimir Ilich Lenin
*/
#include <bits/stdc++.h>
using namespace std;
unsigned long long N, M, S, P, Q, x, y, fix;
unsigned long long cont=1;
bool v;
int main()
{
    freopen("HEXAGONO.IN", "R", stdin);
    freopen("HEXAGONO.OUT", "W", stdout);
    cin>>N>>M>>S>>P>>Q;
    fix=N;
    if(M==1)
    {
        cout<<S<<endl;
        v=0;
        goto theend;
    }
    for(unsigned long long e=0; e<fix-1; e++)
    {
    for(unsigned long long i=0; i<N-1; i++)
    {
        x=x+1;
        S=S+1;
        if(x+1==Q&&y+1==P)
        {
        cout<<S<<endl;
        v=0;
        }
        cont++;
        if(cont>=M)
            goto theend;
    }
    for(unsigned long long i=0; i<N-1; i++)
    {
        y=y+1;
        x=x+1;
        S=S+1;
        if(x+1==Q&&y+1==P)
        {
        cout<<S<<endl;
        v=0;
        }
        cont++;
        if(cont>=M)
            goto theend;
    }
        for(unsigned long long i=0; i<N-1; i++)
    {
        y=y+1;
        x=x-1;
        S=S+1;
        if(x+1==Q&&y+1==P)
        {
        cout<<S<<endl;
        v=0;
        }
        cont++;
        if(cont>=M)
            goto theend;
    }
        for(unsigned long long i=0; i<N-1; i++)
    {
        x=x-1;
        S=S+1;
        if(x+1==Q&&y+1==P)
        {
        cout<<S<<endl;
        v=0;
        }
        cont++;
        if(cont>=M)
            goto theend;
    }
        for(unsigned long long i=0; i<2*(N-1); i++)
    {
        y=y-1;
        S=S+1;
        if(i==2*(N-1)-1)
        {
            y=y+1;
            x=x+1;
        }
        if(x+1==Q&&y+1==P)
        {
        cout<<S<<endl;
        v=0;
        }
        cont++;
        if(cont>=M)
            goto theend;
    }
    if(cont>=M)
    {
            goto theend;
    }
    N=N-1;
    }
    theend:
        if(v==0)
          cout<<"0"<<endl;
        cout<<y+1<<" "<<x+1;
    return 0;
}
