/*LH10-1B.cpp
LH10 Jos� Gabriel Navarro Comabella 12 grado IPVC Vladimir Ilich Lenin
*/
#include <bits/stdc++.h>
using namespace std;
int c, d, N, L, S;

int main()
{
    freopen("CUENTAS.IN", "r", stdin);
    freopen("CUENTAS.OUT", "w", stdout);
    cin>>N>>L>>S;
    char word[N][L];
    for(int i=0; i<N; i++)
    {
        cin>>word[i];
    }
    for(int am=0; am<N; am++)
    {
        for(int e=am+1; e<N; e++)
        {
            for(int i=0; i<L; i++)
            {
                if(word[am][i]!=word[e][i])
                {
                    d=d+1;
                    if(d>1)
                    {
                        e=e+1;
                        break;
                    }
                }

            }
            if(d==1)c=c+1;
            d=0;
        }
    }
    cout<<c;
    return 0;
}
