#include<iostream>
#include<cstdio>
using namespace std;
int main(){
    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);
    int a,b,c;
    cin>>a>>b>>c;
    char n;
    for(int i=0;i<a;i++){
        cin>>n;
        }
    cout<<a<<endl;
return 0;
}

