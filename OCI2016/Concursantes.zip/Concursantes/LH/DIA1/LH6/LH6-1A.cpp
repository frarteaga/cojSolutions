#include<iostream>
#include<cstdio>
using namespace std;
int main(){
    freopen("HEXAGONO.IN","r",stdin);
    freopen("HEXAGONO.OUT","w",stdout);
    int a,b,c,d,e;
    cin>>a>>b>>c>>d>>e;
    cout<<"18"<<endl;
    cout<<"4"<<" "<<"3"<<endl;
}
