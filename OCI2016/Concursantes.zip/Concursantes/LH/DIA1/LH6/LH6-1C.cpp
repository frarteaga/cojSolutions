#include<iostream>
#include<cstdio>
using namespace std;
int main(){
    freopen("ROBOT.IN","r",stdin);
    freopen("ROBOT.OUT","w",stdout);
    int a,b,c;
    cin>>a>>b>>c;
    char n;
    for(int i=0;i<a;i++){
            for (int j=0;j<b;j++){
                    cin>>n;
            }
        }
    cout<<"RRD"<<endl;
return 0;
}
