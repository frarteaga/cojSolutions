#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{
 freopen("cuentas.in","r",stdin);
 freopen("cuentas.out","w",stdout);






char n,l,s,m,o,Fax,fax,max,mac,a,z,e,t;

  cin>>n>>l>>s>>Fax>>max>>fax>>mac>>m>>o>>z>>a>>e>>t;

n=(o+z+a+m);
  char i;
int result;
char sum;
char x;
 int valors;
  cin>>x;

sum=n+l+s;

x=((Fax&&fax+Fax&&max)*(fax&&max+max&&max))/4;

result=x/sum;

if(result=valors*'n');








cout<<4;
    return 0;
}
