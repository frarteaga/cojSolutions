#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{
freopen("robot.in","r",stdin);
freopen("robot.out","w",stdout);
int casillas;

char n,m,k,x,y,r,d;
cin>>n>>m>>k>>y>>x>>r>>d;
for(int i=0;i<n;i++)
{
for(int j=0;j<m;j++)
{
int casillas;
int cant;
cin>>casillas;
n=x;
m=y;
casillas+=(n*m);
while(casillas/cant);


}


cout<<casillas;



}

    return 0;
}
