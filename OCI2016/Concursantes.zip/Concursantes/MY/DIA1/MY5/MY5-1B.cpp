#include <bits/stdc++.h>

using namespace std;
char save[30000][200];
int contp;
int main()
{
freopen("cuentas.in","r",stdin);
freopen("cuentas.out","w",stdout);

    int n,l,s;
    cin>>s;
    if(s == 2)
    {
        cin >>n>>l;
        for(int i=0; i<n; i++)
        {

            for(int j=0; j<l; j++)
            {

                cin >> save[i][j];
                if(save[i][j] == '0' || save[i][j]=='1')
                    continue;
                else
                    return -1;


            }
        }


        for(int h=0; h<n; h++)
        {

            for(int i=h+1; i<n; i++)
            {
                int contc=0;
                for(int j=0; j<l; j++)
                {

                    if(save[h][j] == save[i][j])
                    {

                        contc ++;
                    }


                }

                if(contc+1 == l || contc == l)
                {
                    contp ++;

                }

            }

        }
        if(contp > 0)
            cout << contp;
    }



        else if(s == 64)
        {
            cin >>n>>l;
            for(int i=0; i<n; i++)
            {

                for(int j=0; j<l; j++)
                {

                    cin >> save[i][j];

                }
            }


            for(int h=0; h<n; h++)
            {

                for(int i=h+1; i<n; i++)
                {
                    int contc=0;
                    for(int j=0; j<l; j++)
                    {

                        if(save[h][j] == save[i][j])
                        {

                            contc ++;
                        }


                    }

                    if(contc+1 == l || contc == l)
                    {
                        contp ++;

                    }

                }

            }
            if(contp > 0)
                cout << contp;
        }


        else
            cout<< -1;


    return 0;

    }
