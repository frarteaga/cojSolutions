#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("CUENTA.IN","r",stdin);
    freopen("CUENTA.OUT","w",stdout);
//Claudia de la Caridad Rodriguez Leon
//98011605794
// duodecimo grado
//mayabeque
    char n[30000];
    char l[200];
    int s;
    int con1=0,con2=0,con3=0,con4=0;

    cin>>n[30000];
    cin>>l[200];
    cin>>s;

    while(s==2);
        for (int j=0; j<n; j++)
        {
            for(int i=0; i<l; i++)
            {
                if ( n[i]==n[i+1] )
                    con1++;
                if ( n[i]-n[i+1]==1)
                    con2++;
            }
        }
    cout<<con1+con2;

    while (s==64);
        for (int j=0; j<n; j++)
        {
            for(int i=0; i<l; i++)
            {
                if ( n[i]==n[i+1] )
                    con3++;

                if ( n[i]-n[i+1]==1)
                    con4++;
            }
        }
    cout<<con3+con4;

    return 0;
}
