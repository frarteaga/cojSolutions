#include <bits/stdc++.h>

using namespace std;
posicion_n( x(n+1, m));
posicion_m( x(n, m+1));

int main()
{
    freopen("ROBOT.IN","r",stdin);
    freopen("ROBOT.OUT","w",stdout);
//Claudia de la Caridad Rodriguez Leon
// duodecimo grado
//mayabeque
    int m[200];
    int n[200];
    int k;
    float x[n][m];
    int premios;

    cin>>m;
    cin>>n;
    cin>>k;

    for (int i=0 ; i<n; i++)
    {
        if ( n[i]==# )
            return n[i+1];
        do premios += (n[i]);
        while (premios<=k);
        return x[n+1][m];


    }



}


















cout << d<< endl;
return 0;
}
