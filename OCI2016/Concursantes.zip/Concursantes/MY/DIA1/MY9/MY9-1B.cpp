#include<iostream>
#include<fstream>
using std :: ios;
 main()
 {
  using namespace std;
  ifstream("celdas.in",ios::in);
  ifstream("celdas.out",ios::out);
  using namespace std;
  int n = 3,
      m = 16,
      char(64);
      cout<<" 4  3  64\n",ios::in;
      cout<<"  email\n",ios::in;
      cout<<"  Email\n",ios::in;
      cout<<"  gmail\n",ios::in;
      cout<<"  gmails\n",ios::in;
      cout<<"   4  ",ios::out;

return 0;








    }
