#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen ("robot.in","r",stdin);
freopen ("robot.out","w",stdout);
    int n,m,k;
    int tam;
    char p[40000];
    char r[100];
    cin>>n>>m>>k;
    tam=n*m;
    for (int i=0; i<tam; i++)
    {
        cin>>p[i];
    }
    for (int i=0;i<n; i++)
    {
        if (p[i+1]!= '#' && p[i+1]!='0')
            p[i]=p[i+1];
            r[i-1]='R';

        for(int j=0; j<m; j++)
        {
            if (p[j+1]!='#' && p[j+1] != '0')
            p[j]=p[j+1];
            r[j-1]='D';

            if (r[i,j]>k)
                break;

        }

    }
   cout<<r<<endl;

    system("pause>nul");




    return 0;
}
