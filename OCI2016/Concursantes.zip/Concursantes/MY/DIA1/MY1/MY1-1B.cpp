#include <bits/stdc++.h>

using namespace std;

bool igual(int i, int j){
if(i==j)
   return true;

else
    return false;

}

int main()
{

freopen("CUENTAS.in", "r", stdin);
freopen("CUENTAS.out", "w", stdout);


    char a[200][200];
    int cant, lon;
    int coin=0;

    cin>>cant>>lon;

    for(int i=0; i<cant; i++)
    {

        for(int j=0; j<lon; j++)
        {
            cin>>a[i][j];

            if(igual(a[i][j], a[i+1][j]))
            {
                coin+=1;
            }
            else
                coin=0;

            if(igual(a[i][j+1], a[i+1][j+1]))
            {
                coin+=1;
            }
            else
                coin=0;

        }

     }

cout<<coin;




    return 0;
}
