#include <bits/stdc++.h>

using namespace std;

int main()

{
    freopen("ROBOT.IN","r",stdin);
    freopen("ROBOT.OUT","w",stdout);
    int a,b,c;
    string d,e,f;
    cin>>a>>b>>c;
    cin>>d>>e>>f;
    cout << "RRD" << endl;
    return 0;
}
