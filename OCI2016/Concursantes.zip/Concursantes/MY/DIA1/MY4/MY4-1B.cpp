#include<bits/stdc++.h>

using namespace std;

int main()
{
    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);
    int a,b,c;
    string d,e,f,g;
    cin>>a>>b>>c>>d>>e>>f>>g;
    cout<<4;
    return 0;
}
