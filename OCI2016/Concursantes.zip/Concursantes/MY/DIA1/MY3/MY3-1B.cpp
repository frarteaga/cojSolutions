#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen ("CUENTAS.IN","r",stdin);
    freopen ("CUENTAS.OUT","w",stdout);
    int n,l,s;
    cin >> n>>l>>s;
    char cuen[n][l];
    char res [l];
    for(int i=0; i<n; i++)
    {
        for (int j=0; j<l; j++)
        {
            cin>>cuen[i][j];
        }
    }
    int cont = 0;
    int cont1 = 0;
    for(int i=0; i<n; i++)
    {
        for (int j=0; j<l; j++)
        {


            res[j] = cuen[i][j];
            for (int k= i+1; k<n; k++)
            {
                if(res[j] != cuen[k][j])
                  {
                     cont++;
                      if (cont > 1)
                        cont = 0;
                  }

            }

        }
        cont1 += cont;
    }

    cout <<n;
    return 0;
}




