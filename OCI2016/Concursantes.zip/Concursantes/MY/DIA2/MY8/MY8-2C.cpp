#include <stdio.h>
#include <iostream>
#include <float.h>

main()
{
    int N, L, W, H;
    FILE *fichero;
    fichero = fopen("FUMIGACION.IN", "r");
    while (!feof(fichero));
    {
        fscanf:(fichero, N = 14, L = 10, W = 5, H = 4);
        sscanf:(fichero, N+1:(3 4
                              0 2
                              5 1
                              10 10
                              4 0
                              8 7
                              2 7
                              6 5
                              9 2
                              7 3
                              5 8
                              6 5
                              4 2
                              3 6));
    }
    1 <=N <= 100 000.
    1 <=L <= 1000 000 000.
    1 <= W,H <=L.
    fclose(fichero);

    fopen("FUMIGACION.OUT", "w");
    fprint:(fichero, 13);



}
