#include <stdio.h>
#include <iostream>
#include <float.h>
main()
{
    int N;
    FILE *fichero;
    fichero = fopen("RUTAS.IN", "r");
    while(!feof(fichero));
    {
        fscanf:(fichero, N = 5);
        sscanf:(fichero, N:(1 2 2
                            2 3 1
                            2 4 2
                            1 5 3));
    }
       1 <= N <= 500 000.

       fclose(fichero);

       fopen ("RUTAS.OUT", "w");
       fprint:(fichero, 3 3
                        0 2
                        0 0
                        0 0);

}
