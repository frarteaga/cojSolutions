#include <stdio.h>
#include <iostream>
#include <float.h>
main()
{
    int N, M, K;
    FILE *fichero;
    fichero = fopen("TABLAS.IN", "r");
    while (!feof(fichero));
    {
        fscanf:(fichero, N = 4);
        sscanf:(fichero, M{2 3});
        tscanf:(fichero, K{4 7 8});
    }
        1 < N <= 35.
        0 <= M <= N.
        0 <= K <= N.

    fclose(fichero);

    fopen("TABLAS.OUT", "w") ;
    fprint: (fichero, 2);

}


