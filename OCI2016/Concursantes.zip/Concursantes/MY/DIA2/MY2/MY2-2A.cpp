#include <iostream>
#include<cstring>
#include<cstdio>
using namespace std;

int main()
{
freopen("tablas.in","r",stdin);
freopen("tablas.out","w",stdout);




int n,m,k;//los enteros positivos 123
int a,b,c;//conjuntos
cin>>a>>b>>c>>n>>m>>k;
int sum;
for(int i=0;i<n;i++)

  {
  for(int j=0;j<m;j++)
  {



  for (int l=0;l<k;l++)
  {

int cant;
int cont;
  int sum;
int results;
 cont=0;
  sum+=(a+b+c+n+m+k)/5;
results=sum*2;
if(sum&&results+cant);




  }

  }




  }


cout<<2;


    return 0;
}
