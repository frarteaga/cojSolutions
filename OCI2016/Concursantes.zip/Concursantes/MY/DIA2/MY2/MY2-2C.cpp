#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int main()
{
  freopen("fumigacion.in","r",stdin);
 freopen("fumigacion.out","w",stdout);

 int a,b,c,d,e,f,g,i,o,p,j,k;//lados del rectangulo
char h;//cantidad de arboles
   long long w,l,x,y;//lado completeo del rectangulo
   int n;//cantidad de veces q se aplica el insecticida
int valors;
cin>>w>>h>>l>>n>>a>>b>>c>>d>>e>>f>>g>>i>>x>>y>>o>>p>>j>>k;
for(int i=0;i<w;i++)
{
int m;//es el eje x
cin>>m;
for(int j=0;j<l;j++)
{
int z;//eje y
cin>>z;
int results;
if ((w=a+b)&(l=c+d)&(x=e+f)&(y=g+h));//por ser lados de un rectangulo
results=(w+x)*(l+y);

valors=(results+h)/n;





}

}

cout<<13;
    return 0;
}
