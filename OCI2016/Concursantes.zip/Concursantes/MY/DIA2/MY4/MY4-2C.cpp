#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("FUMIGACION","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);
    int a,b,c,d,e;
    cin >>a>>b>>c>>d;
    int j[10000];
     e=a*2;
     for (int w=0;w<e;w++)
     {
         cin>>j[w];
     }
      cout << a-1 << endl;
    return 0;
}
