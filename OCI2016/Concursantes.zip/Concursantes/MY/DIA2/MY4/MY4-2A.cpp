#include <bits/stdc++.h>

using namespace std;


int main()
{
    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);
    int n,m,k,l,w,z;
    int c1[35];
    int c2[35];
    int c3[35];
    int cont1=0;
    int cont2=0;
    cin>>n;
    cin>>m;
    for (int i=0;i<m;i++)
    {
        cin>>c1[i];
        if(c1[i]==1)
        {
            cont1++;
        }
    }
    cin>>k;
    for (int j=0;j<k;j++)
    {
        cin>>c2[j];
        if(c2[j]==n)
        {
            cont2++;
        }
    }
     w=n*2;
     z=m+k;
     l=w-z;

    if(cont1==0&&cont2==0)
    {
        cout<<l-2<< endl;
    }
    if(cont1==1&&cont2==0)
    {
        cout<<l-1<< endl;
    }
     if(cont1==0&&cont2==1)
    {
        cout<<l-1<< endl;
    }
   if(cont1==1&&cont2==1)
    {
        cout<<l<< endl;
    }
return 0;
}
