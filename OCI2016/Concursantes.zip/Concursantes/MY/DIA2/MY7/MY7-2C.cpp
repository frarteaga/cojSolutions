#include <bits/stdc++.h>

using namespace std;
freopen("FUMIGACION.IN","r",stdin);
freopen("FUMIGACION.OUT","w",stdout);

int main()

{ int m[10000][10000];
int t[2],n;
long long l,w,h;
cin>>n;
cin>>l;
cin>>w;
cin>>h;
     for(int i=0;i<n;i++){
      for(int j=0;j<n;j++){

     cin>>m[i][j];

 if( (m[i][j]<w&&h)&&m[i][j]==m[i-1][j-1])
    t[i]=m[i][j];
      }
      }
cout<<t<<endl;
system("pause>nul");

    return 0;
}
