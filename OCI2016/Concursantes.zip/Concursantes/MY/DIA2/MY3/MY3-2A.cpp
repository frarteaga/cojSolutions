#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);
    int n;
    cin >> n;
    if(n == 2)
        cout << 1;
        if(n == 4)
        cout << 2;
        if(n == 6)
        cout << 3;
        if(n == 8)
        cout << 4;
        if(n == 10)
        cout << 5;
        if(n == 12)
        cout << 6;
        if(n == 14)
        cout << 7;
        if(n == 16)
        cout << 8;
        if(n == 18)
        cout << 9;
        if(n == 20)
        cout << 10;
        if(n == 22)
        cout << 11;
        if(n == 24)
        cout << 12;


    return 0;
}
