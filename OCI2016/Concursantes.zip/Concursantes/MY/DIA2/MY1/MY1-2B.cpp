#include <bits/stdc++.h>

using namespace std;

int main()
{
freopen("RUTAS.in", "r", stdin);
freopen("RUTAS.out", "w", stdout);

int n, a, b, c, d, e, f, g, h, i, j, k, l;

cin>>n>>a>>b>>c>>d>>e>>f>>g>>h>>i>>k>>l;

cout<<"3 "<<"3"<<endl<<"0 "<<"2"<<endl<<"0 "<<"0"<<endl<<"0 "<<"0"<<endl;




    return 0;
}
