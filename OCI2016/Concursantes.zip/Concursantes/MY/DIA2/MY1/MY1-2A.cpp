#include <bits/stdc++.h>

using namespace std;

int main()
{
freopen("TABLAS.in", "r", stdin);
freopen("TABLAS.out", "w", stdout);

    int a, b, c, d, e, f, g, h;
    cin>>a>>b>>c>>d>>e>>f>>g>>h;



    if(b==2)
    {

        cout<<b;

        if(b==49)
        {
            cout<<"-1";
        }
        if(b==12)
        {
            cout<<b;
        }

        if(b==3)
        {
            cout<<b;
        }
        if(b==8)
        {
            cout<<b;
        }
        if(b==6)
        {
            cout<<b;
        }
        if(b==1)
        {
            cout<<b;
        }

    }
    else

        cout<<"-1";



    return 0;
}

