#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
using namespace std;
int main()
{
    freopen("ROBOT.IN","r",stdin);
    freopen("ROBOT.OUT","w",stdout);

queue <char> kkf;
int n,m,b,p=1,c=1,i,j;
char tru;
cin>>n>>m>>b;
char a[n][m];


for( i=1;i<=n;i++){for( j=1;j<=m;j++){ cin>>a[i][j];


           }


}
for( i=1;i<=n;i++){for( j=1;j<=m;j++){


if(a[i][j]=='#'){a[i][j]=0; }

if(a[c+1][p]>a[c][p+1]){  c++;  tru='D'; kkf.push(tru);     }
        else
            if(a[c+1][p]<a[c][p+1]){p++;  tru='R'; kkf.push(tru);     }
            else
                break;
}


}

for(int i=1;i<=b;i++){ cout<<kkf.front(); kkf.pop();   }

}
