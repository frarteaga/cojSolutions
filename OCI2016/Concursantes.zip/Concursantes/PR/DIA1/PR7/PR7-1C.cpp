#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
using namespace std;
int main()
{
    freopen("ROBOT.IN","r",stdin);
    freopen("ROBOT.OUT","w",stdout);

queue <char> AHH;
int n, m, k, d=1, c=1, i, j;
char tru;
cin>>n>>m>>k;
char a[n][m];


for( i=1;i<=n;i++){
for( j=1;j<=m;j++){ 
    cin>>a[i][j];
}
}
for( i=1;i<=n;i++){
    for( j=1;j<=m;j++){

if(a[i][j]=='#'){
    a[i][j]=0; }

if(a[c+1][d]>a[c][d+1]){ 
     c++;  tru='D'; AHH.push(tru);     }
        else
            if(a[c+1][d]<a[c][d+1]){d++;  tru='R'; AHH.push(tru);     }
            else
                break;
}
}

for(int i=1;i<=k;i++){
    cout<<AHH.front(); AHH.pop();   }

}
