#include<iostream>
#include<cstdio>
#include<string>
#include<cstdlib>
using namespace std;

int n, b=0,c=0;
short l,s;
string a[1000];

main(){
freopen("CUENTAS.IN","r",stdin);
freopen("CUENTAS.OUT","w",stdout);


cin>>n>>l>>s;

for(int i=1; i<=n; i++){
    cin>>a[i];
}
for(int i=1; i<=n-1; i++)
for(int j=i+1; j<=n; j++){
     
    if(a[i].size()==a[j].size()){
        
        for(int m=0; m<=a[i].size()-1; m++){
            
          if(a[i][m]!= a[j][m])
          b++;
        }
    }
    if(b==1){c++;}
    b=0;
}
cout<<c;
}
