#include<iostream>
#include<cstdio>
#include<queue>
#include<cstring>
using namespace std;
int main()
{
  freopen("ROBOT.IN","r",stdin);
  freopen("ROBOT.OUT","w",stdout);
int N,M,K,Gas=1,Has=1;
char direc;
cin>>N>>M>>K;
char cad[N][M];
queue <char> cola;
for(int i=1;i<=N;i++){
    for(int j=1;j<=M;j++){
        cin>>cad[i][j];}}
for(int i=1;i<=N;i++){
    for(int j=1;j<=M;j++){
if(cad[i][j]=='#'){
    cad[i][j]=0; }
if(cad[Gas+1][Has]>cad[Gas][Has+1]){
     Gas++;  direc='D';
     cola.push(direc);}
     else
        if(cad[Gas+1][Has]<cad[Gas][Has+1]){
           Has++;
           direc='R';
           cola.push(direc);     }
           else
            break;}}
for(int i=1;i<=K;i++){
    cout<<cola.front();
          cola.pop();   }
}
