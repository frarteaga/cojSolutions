#include<cstdio>
#include<iostream>
using namespace std;
main()
{
 freopen("CUENTAS.IN","r",stdin);
 freopen("CUENTAS.OUT","w",stdout);
 string arr[30001];
 int n,l,s,cant=0,cont=0;
 bool arr1[1000][1000];
 cin>>n>>l>>s;
 for(int i=0;i<n;i++){
    cin>>arr[i];

 }
for(long long i=0;i<n;i++){
    for(long long j=0;j<n;j++){
     cont=0;
    for(int k=0;k<l;k++){
       if(i==j){j++;
       }
       if(j>=n){continue;}
       if(arr[i][k]!=arr[j][k]){
        cont++;
       }

       if(k==l-1){
       if(arr1[i][j]!=true and arr1[j][i]!=true){
       if(cont==1){cant++;
        arr1[i][j]=true;
        arr1[j][i]=true;
       }}

      }

       }

}}
cout<<cant;
}
