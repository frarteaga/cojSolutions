#include<bits/stdc++.h>
using namespace std;
int main()
{
  freopen("ROBOT.in","r",stdin);
  freopen("ROBOT.out","w",stdout);
int N,M,K,G=1,H=1;
char direc;
cin>>N>>M>>K;
char cad[N][M];
queue <char> cola;
for(int i=1;i<=N;i++){
    for(int j=1;j<=M;j++){
        cin>>cad[i][j];}}
for(int i=1;i<=N;i++){
    for(int j=1;j<=M;j++){
if(cad[i][j]=='#'){
    cad[i][j]=0; }
if(cad[G+1][H]>cad[G][H+1]){
     G++;  direc='D';
     cola.push(direc);}
     else
if(cad[G+1][H]<cad[G][H+1]){
           H++;
           direc='R';
           cola.push(direc);     }
           else
            break;}}
for(int i=1;i<=K;i++){
    cout<<cola.front();
          cola.pop();   }
}
