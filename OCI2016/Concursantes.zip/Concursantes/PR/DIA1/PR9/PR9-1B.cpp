#include<bits/stdc++.h>
using namespace std;
main()
{
 freopen("CUENTAS.in","r",stdin);
 freopen("CUENTAS.out","w",stdout);
 string arr[30001];
 int n,l,s,ci=0,c=0;
 bool arr1[1000][1000];
 cin>>n>>l>>s;
 for(int i=0;i<n;i++){
    cin>>arr[i];
}
for(long long i=0;i<n;i++){
for(long long j=0;j<n;j++){
    c=0;
for(int k=0;k<l;k++){
    if(i==j){j++;
    }
    if(j>=n){continue;}
    if(arr[i][k]!=arr[j][k]){
    c++;
    }
    if(k==l-1){
    if(arr1[i][j]!=true and arr1[j][i]!=true){
    if(c==1){ci++;
    arr1[i][j]=true;
    arr1[j][i]=true;
    }}
}
}
}}
cout<<ci;
}

