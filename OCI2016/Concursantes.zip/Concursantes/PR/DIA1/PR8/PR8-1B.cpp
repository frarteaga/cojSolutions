#include<iostream>
#include<cstdio>
#include<string>
#include<cstdlib>
using namespace std;
main(){
freopen("cuentas.in","r",stdin);
freopen("cuentas.out","w",stdout);
int n,contd=0,contc=0;
short l,s;
cin>>n>>l>>s;
string a[n];
for(int i=1;i<=n;i++){
    cin>>a[i];
}
for(int i=1;i<=n-1;i++)
for(int j=i+1;j<=n;j++){
    if(a[i].size()==a[j].size()){
        for(int k=0;k<=a[i].size()-1;k++){
          if(a[i][k]!=a[j][k])contd++;
        }

    }
    if(contd==1){contc++;}
   contd=0;
}
cout<<contc;
}









