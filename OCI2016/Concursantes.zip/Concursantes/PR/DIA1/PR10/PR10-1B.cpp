#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int N, L, d=0, e=0;
short S;
char caracter1[201][201], caracter2[201][201];

main(){
    freopen("CUENTAS.in","r",stdin);
    freopen("CUENTAS.out","w",stdout);
    cin>>N>>L>>S;
   for(int i=1; i<=N; i++){
    for(int j=1; j<=L; j++){
        cin>>caracter1[i][j];
    }
     for(int j=1; j<=L; j++){
        cin>>caracter2[i][j];
    }
    if(caracter1!=caracter2)
        d++;
    if(d=1) e++;
   }
    cout<<e;
}
