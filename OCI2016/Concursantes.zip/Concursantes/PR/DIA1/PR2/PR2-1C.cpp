#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>

using namespace std;

int main()
{   freopen("ROBOT.IN","r",stdin);
    freopen("ROBOT.OUT","w",stdout);

queue <char> KILL;
int N,M,K,P=1,C=1;
char ok;
cin>>N>>M>>K;
char chain[N][M];


for(int i=1;i<=N;i++){
    for(int j=1;j<=M;j++){
        cin>>chain[i][j];
        }
    }
for(int i=1;i<=N;i++){
    for(int j=1;j<=M;j++){

if(chain[i][j]=='#'){
    chain[i][j]=0; }

if(chain[C+1][P]>chain[C][P+1]){
     C++;  ok='D';
     KILL.push(ok);     }
    else
        if(chain[C+1][P]<chain[C][P+1]){
           P++;
           ok='R';
           KILL.push(ok);     }
        else
            break;
        }
    }

for(int i=1;i<=K;i++){
    cout<<KILL.front();
          KILL.pop();   }

}
