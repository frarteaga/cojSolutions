#include <iostream>
#include <cstdio>
#include <string>
#include <cstdlib>

using namespace std;

main(){
  freopen("CUENTAS.IN","r",stdin);
  freopen("CUENTAS.OUT","w",stdout);

int N,L,S,Errors=0,cont=0;

cin>>N>>L>>S;

string chain[N];
for(int i=1;i<=N;i++){
    cin>>chain[i];

}
for(int i=1;i<=N-1;i++)
    for(int j=i+1;j<=N;j++){
        for(int k=0;k<=chain[i].size()-1;k++){
            if(chain[i][k]!=chain[j][k])Errors++;
            }

    if(Errors==1){
          cont++;}
    Errors=0;
         }
cout<<cont<<endl;
}
