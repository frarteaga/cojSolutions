#include<iostream>
#include<cstdio>
#include<string>
#include<cstdlib>
using namespace std;
main(){
freopen("CUENTAS.IN","r",stdin);
freopen("CUENTAS.OUT","w",stdout);
int n,d=0,c=0;
short l,s;
cin>>n>>l>>s;
string a[n];
for(int i=1;i<=n;i++){
    cin>>a[i];
}
for(int i=1;i<=n-1;i++)
for(int j=i+1;j<=n;j++){
    if(a[i].size()==a[j].size()){
        for(int k=0;k<=a[i].size()-1;k++){
          if(a[i][k]!=a[j][k])d++;
         }
         if(d==1){c++;}
         d=0;
}
}
cout<<c;
}
