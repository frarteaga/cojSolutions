#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
main()
{freopen("CUENTAS.IN","r",stdin);
 freopen("CUENTAS.OUT","w",stdout);
    string x,y;
    bool a;
    int p,l,n;
while(cin>>x){
for(int i=1;i<=n;i++);}
while(cin>>y){
for(int j=1;j<=n;j++);
if(x==y){a=true;}
else
{l=4;}
cout<<l<<" ";}
}
