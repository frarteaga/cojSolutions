#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{


   int n,m,k,aux;
  cin>>n>>m;
  int m1[m];
  for(int i=1;i<=m;i++){cin>>m1[i];}
   for(int i=1;i<=m-1;i++){
for(int j=i+1;j<=m;j++){  if(m1[i]>m1[j]){ swap(m1[i],m1[j]);} }
    }
 for(int i=1;i<=1;i++){  aux=m1[i]-1;}
cin>>k;
int k1[k];
 for(int a=1;a<=k;a++){cin>>k1[a];}
   for(int a=1;a<=k-1;a++){
for(int b=a+1;b<=k;b++){  if(k1[a]>k1[b]){ swap(k1[a],k1[b]);} }
}

int ttru=(n*2)-(m+k);

int aux2=n-m-aux;
int aux3=k1[1]-m1[m];
int aux4=(n*2)-k1[k];

if(n-m1[m]==((n*2)-1)-k1[k]){cout<<((n*2)-1)-k1[k];}
else
if(aux3==aux2){
cout<<ttru-aux;}
else
cout<<aux3-aux;












}
