#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m,k,s;
 main()
{

  freopen("TABLAS.IN","r", stdin);
  freopen("TABLAS.OUT","w", stdout);


  cin>>n>>m;
  int ad[m];
  for(int i=1;i<=m;i++){
      cin>>ad[i];
      }
   for(int i=1;i<=m-1;i++){

for(int j=i+1;j<=m;j++){
     if(ad[i]>ad[j]){
         swap(ad[i],ad[j]);} }
    }
 for(int i=1;i<=1;i++){
     s=ad[i]-1;}

cin>>k;
int kk[k];

 for(int a=1;a<=k;a++){
     cin>>kk[a];}

   for(int a=1;a<=k-1;a++){

for(int b=a+1;b<=k;b++){
    if(kk[a]>kk[b]){
        swap(kk[a],kk[b]);} }
}

int ka=(n*2)-(m+k);

int g=n-m-s;

int c=kk[1]-ad[m];




if(c==g){
cout<<ka-s;
}
else
cout<<c-s;

}
