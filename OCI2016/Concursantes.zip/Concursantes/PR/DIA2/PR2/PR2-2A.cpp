#include<iostream>
#include<cstdio>
#include<cstring>

using namespace std;
int main()
{ ios::sync_with_stdio(false);
  cin.tie(0);

  freopen("TABLAS.IN","r",stdin);
  freopen("TABLAS.OUT","w",stdout);

   int N, M, K, KILL;

  cin>>N>>M;

  int M1[M];

  for(int intel=1;intel<=M;intel++){
        cin>>M1[intel];
  }
  for(int intel=1;intel<=M-1;intel++){
     for(int joker=intel+1;joker<=M;joker++){
        if(M1[intel]>M1[joker]){
            swap(M1[intel],M1[joker]);
        }
      }
    }
  for(int intel=1;intel<=1;intel++){
    KILL=M1[intel]-1;
  }
    cin>>K;
  int K1[K];

  for(int asus=1;asus<=K;asus++){
        cin>>K1[asus];
 }
   for(int asus=1;asus<=K-1;asus++){
      for(int broken=asus+1;broken<=K;broken++){
          if(K1[asus]>K1[broken]){
            swap(K1[asus],K1[broken]);
         }
    }
}
int PRO=(N*2)-(M+K);
int KILL2=N-M-KILL;
int KILL3=K1[1]-M1[M];


if(KILL3==KILL2){
cout<<PRO-KILL;
}
else
cout<<KILL3-KILL;
}
