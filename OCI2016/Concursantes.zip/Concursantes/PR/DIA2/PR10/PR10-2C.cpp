#include<iostream>
#include<cstdio>
#include<stack>

using namespace std;
int N, L, W, H, cant=0, cA, cB;
stack<int> pila;
int main(){
freopen("FUMIGACION.in","r",stdin);
freopen("FUMIGACION.out","w",stdout);
cin>>N>>L>>W>>H;
for(int i=1; i<=N; i++){
    cant++;
    pila.push(cant);
}
for(int i=1; i<=N; i++){
    cin>>cA>>cB;
    pila.pop();
}
if(pila.empty()==true)
    cout<<cant-1;
else cout<<"-1";
}
