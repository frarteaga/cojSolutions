#include<iostream>
#include<cstdio>
#include<stack>

using namespace std;
short N, M, K, A[64], B[64], auxA, auxB;
int form=0;
stack<int> conA, conB;
int main(){
freopen("TABLAS.in","r",stdin);
freopen("TABLAS.out","w",stdout);
cin>>N;
cin>>M;
for(int i=1; i<=M; i++){
    cin>>A[i];
}
for(int i=0; i<M; i++){
   for(int j=1; j<=M; j++){
    if(A[i]>A[j])
       A[i]=auxA;
       A[i]=A[j];
       A[j]=auxA;
       conA.push(auxA);
   }
form++;
}
cin>>K;
for(int i=1; i<=K; i++){
    cin>>B[i];
}
for(int i=0; i<K; i++){
   for(int j=1; j<=K; j++){
    if(B[i]>B[j])
       B[i]=auxB;
       B[i]=B[j];
       B[j]=auxB;
       conB.push(auxB);
   }
}
cout<<form;
}
