#include<bits/stdc++.h>
using namespace std;
int n,m,k,c;
int main(){
  freopen("TABLAS.in","r",stdin);
  freopen("TABLAS.out","w",stdout);
  ios::sync_with_stdio(false);
  cin.tie(0);
  cin>>n>>m;
  int m1[m];
  for(int i=1;i<=m;i++){
  cin>>m1[i];
  }
  for(int i=1;i<=m-1;i++){
  for(int j=i+1;j<=m;j++){
  if(m1[i]>m1[j]){
  swap(m1[i],m1[j]);
  }
  }}
  for(int i=1;i<=1;i++){
  c=m1[i]-1;}
  cin>>k;
  int k1[k];
  for(int a=1;a<=k;a++){
  cin>>k1[a];
  }
  for(int a=1;a<=k-1;a++){
  for(int b=a+1;b<=k;b++){
  if(k1[a]>k1[b]){
  swap(k1[a],k1[b]);
  }}
  }
  int tt=(n*2)-(m+k);
  int c2=n-m-c;
  int c3=k1[1]-m1[m];
  if(c3==c2){
  cout<<tt-c;
  }
  else
  cout<<c3-c;
}
