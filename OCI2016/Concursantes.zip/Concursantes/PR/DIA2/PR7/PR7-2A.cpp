#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m,k,aux;
 main()
{

  freopen("TABLAS.IN","r", stdin);
  freopen("TABLAS.OUT","w", stdout);


  cin>>n>>m;
  int m1[m];
  for(int i=1;i<=m;i++){
      cin>>m1[i];
      }
   for(int i=1;i<=m-1;i++){

for(int j=i+1;j<=m;j++){
     if(m1[i]>m1[j]){
         swap(m1[i],m1[j]);} }
    }
 for(int i=1;i<=1;i++){
     aux=m1[i]-1;}

cin>>k;
int k1[k];

 for(int a=1;a<=k;a++){
     cin>>k1[a];}

   for(int a=1;a<=k-1;a++){

for(int b=a+1;b<=k;b++){
    if(k1[a]>k1[b]){
        swap(k1[a],k1[b]);} }
}

int fuck=(n*2)-(m+k);

int lol1=n-m-aux;

int lol2=k1[1]-m1[m];




if(lol2==lol1){
cout<<fuck-aux;
}
else
cout<<lol2-aux;



}
