#include <iostream>
#include <cstdio>
using namespace std;

int main()
int L,W,H,N;
{
   freopen("Fumigacion.in","r",stdin);
   freopen("Fumigacion.out","w",stdout);
   scanf("%d",&);

   cout<<"longitud del lado d la arboleda"<<endl;
   cin>>L;
   cout<<"Numero de fumigaciones hechas"<<endl;
   cin>>N;
   cout<<"Lado del rectangulo q interesa verificar"<<endl;
   cin>>W;
   cout<<"Ancho del rectangulo q interesa verificar"<<endl;
   for(int i=N,i>=1,i++);
   {

   }











    return 0;
}
