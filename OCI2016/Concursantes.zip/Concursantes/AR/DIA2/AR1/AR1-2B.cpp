#include <iostream>
#include <stdio.h>
using namespace std;

int main()
int
{
   freopen("Rutas.in","r",stdin);
   freopen("Rutas.out","w",stdout);
   scanf("%d",&);
   X=N-1;
   cout<<"Cantidad de ciudades"<<endl;
   cin>>N;
   cout<<"Red de carreteras"<<;
   cin>>X;







    return 0;
}
