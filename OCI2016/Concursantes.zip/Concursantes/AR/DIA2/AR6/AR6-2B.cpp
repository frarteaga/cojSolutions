#include <iostream>
#include <cstdlib>
#include <cmath>
#include <stdio.h>
using namespace std;
int N;
int main (){

  freopen ("RUTAS.IN","r",stdin);
  freopen ("RUTAS.OUT","w", stdout);
  scanf ("%d", &N);
}
long Rut(long n) {
if (n == 0 || n == 1)
    return n;
  else
    return Rut(n-1) + Rut(n-2);
}
int main (){
  long N;
  cout << "N�mero: ";
  cin >> N;
  cout << "La i-esimo Ruta es " << Rut(N);

 fprintf (fout, "%d\n",N);

  system ("pause > nul");
  return 0;
}
