#include <iostream>
#include <stdio.h>
#include <cmath>
using namespace std;
int n,m,t,x,k;
int a[1000];
int b[1000];
int w=2;
int main()
{int d=1;
freopen("TABLAS.in","r",stdin);
freopen("TABLAS.out","w",stdout);
scanf("%d",&n);
t=(2*n)+1;
for(int j=0;j<2;j++){
for(;d<t;d++){
    cout<<d;
}
printf("%d",d);
   }

}
