#include <iostream>

using namespace std;
int N,L;
char S,y,ar[100];
int c=0;
int main()
{
    freopen("cuentas.in","r",stdin);
    freopen("cuentas.out","w",stdout);
    scanf(%d,%d,&N,&L);
    scanf(%s,&S);
    if(S=='64'){
    for(int i=0; i<N; i++)
        scanf(%s,&ar[i]);
        for(int i=0; i<N; i++)
        for(int j=0; j<N; j--)
        if((ar[i]==ar[i+1])||(ar[j]==ar[j-1]))
        c++;
        printf(%d,"&c");
    }
    else if(S==2){
    for(int i=0; i<N; i++)
        scanf(%s,&ar[i]);
        for(int i=0; i<N; i++)
        for(int j=0; j<N; j--)
        if((ar[i]==ar[i+1])||(ar[j]==ar[j-1]))
        c++;
        printf(%d,"&c");
    }
    else
        printf("incorrect");


    return 0;
}
