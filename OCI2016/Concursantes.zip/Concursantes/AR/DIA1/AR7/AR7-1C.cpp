//Yandi Vargas Dominguez  11no Grado
//IPVCE Martires de Humboldt 7
//Prov Artemisa
#include <iostream>
#include <cstdlib>
#include <bits/stdc++.h>

using namespace std;
//int ar[100][100];
int N, M,K;
char ar[100][100];
char a1[100], a2[100];
int main()
{
    freopen("ROBOT.in","r",stdin);
    freopen("ROBOT.out","w",stdout);

    scanf(%d,%d,%d,&N,&M,&K);



    for(int i=0;i<N;i++)
        for(int j=0;j<M;j++)
    scanf(%s, &ar[i][j]);

    for(int x=0;x<N;x++)
        scanf(%s, &a1[x];
        for(int x=0;x<N;x++)
            if(x=='*')
            printf(" ");
        else
        printf("R");


        for(int y=0;y<M;y++)
        cin>>a2[y];
        for(int y=0;y<M;y++)
            if(y=='*')
            printf(" ");
        else
            printf("D");

            system("pause>nul");


 return 0;
}
