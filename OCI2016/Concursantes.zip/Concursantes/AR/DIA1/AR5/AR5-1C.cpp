#include <iostream>
#include <stdio.h>
#include <cmath>
#include <stdlib.h>
using namespace std;
int n;
int j=0;
int i=0;
int k=0;
int dim[200][200];
int ayuda[1000];
int m;
int main()
{freopen("ROBOT.IN","r",stdin);
freopen("ROBOT.OUT","w",stdout);
scanf("%d%d",&n,&m);
cin >>n>>m;
for(;i=m;i++){
    for (;j=n;j++)
        cout <<dim[i][j]<<endl;}
printf("%d",dim[i][j]);
}
