#include <iostream>

using namespace std;

int main()
{
    int n,m,k;
    cin>>n; /* n-cantidad de filas*/
    cin>>m; /* m-cantidad de columnas*/
    cin>>k; /* k-cantidad de caracteres-comandos*/
    for(int x=1;x<=m;x++)
    {
        for(int y=1;y<=n;y++)
        {
            cout<<"0";
        }
    }
    return 0;
}
