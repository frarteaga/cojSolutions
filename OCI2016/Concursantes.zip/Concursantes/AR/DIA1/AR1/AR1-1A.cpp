#include <iostream>
#include <stdio.h>
#include <cstdlib>

using namespace std;

int main()
int N,M,S,P,Q;
{
     freopen("Hexagono.in","r",cstin);
     freopen("Hexagono.out","w",cstout);
     scanf("%d","%d","%d",&);


    cout<<"Cant de celdas"<<endl;
    cin>>N;
    cout<<"Cant de celdas x las q pasa"<<endl;
    cin>>M;
    cout<<"Primer numero x dond comenzar la secuencia"<<endl;
    cin>>S;















    return 0;
}
