#include <iostream>

using namespace std;

int main()
int
{
    freopen("Cuentas.in","r",cstin);
    freopen("Cuentas.out","w",cstout);
    scanf("%d",&)




    cout << "Hello world!" << endl;
    return 0;
}
