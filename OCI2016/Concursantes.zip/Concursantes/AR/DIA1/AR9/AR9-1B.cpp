#include <iostream>

using namespace std;
//Shadir Sanchez Hernandez
//Martires de humboldt 76
int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
