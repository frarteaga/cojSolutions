//Adrian Rodas Cueto
//Martires  de Hunvoldt7
//10mo grado
#include <iostream>
#include <stdio.h>

using namespace std;


int main()
{

    int n,m,s;
    //n=cantidad de celdas
    //m=celdas moviendoce
    //s=secuencia de #enteros cunsecutivos
    int A[100];
    if(n=3)
        cout<<n=3<<endl;
    else(n=n+1)

    return 0;
}
