//Adrian Rodas Cueto
//Martires  de Hunvoldt7
//10mo grado
#include <iostream>
#include <ssp/stdio.h>
using namespace std;
freopen("problema B.in","stdin")
freopen("problema B.out","stdout")


int main()
{
    bool
    return 0;
}
