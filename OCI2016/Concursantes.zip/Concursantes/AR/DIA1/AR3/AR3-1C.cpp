#include <iostream>
#include <stdion>
using namespace std;
freopen("problema B.in","stdin")
freopen("problema B.out","stdout")

int main()
{

    return 0;
}
