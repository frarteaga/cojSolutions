//Alejandro Ramon Rodriguez Guerra


#include <iostream>
#include <stdio.h>
using namespace std;

int main()
cin>>n>>m>>k;




printf("d%\n",c);



}
