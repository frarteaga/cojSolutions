#include <iostream>

using namespace std;

int main()
{int z,x,k,i;
cout<<"insrte la cantidad de filas"<<endl;
cin>>z;
cout<<"insrte la cantidad de columnas"<<endl;
cin>>x;
 int(filas)[z],(columnas)[x];
 cout<<"inserte la cantidad de caracteres comando"<<endl;
 cin>>k;
  cout<<"inserte las posiciones en las que estan las casillas de perdidas"<<endl;
  cin>>i;

for(int i=1;i=i,i++)









          return 0;
}
