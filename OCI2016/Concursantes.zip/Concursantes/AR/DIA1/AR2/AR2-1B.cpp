#include <iostream>
#include <stdio.h>
using namespace std;
int juego [23] , [32];
int main()
{freopen("hexagono.in","r",stdin);
freopen("hexagono.out","w",stdout);











    return 0;
}
