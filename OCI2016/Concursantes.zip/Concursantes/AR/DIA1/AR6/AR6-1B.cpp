#include <stdio.h>
#include <iostream>

using namespace std;
int N, L;
float Notas[64][2];
float S, O;
int main() {
   freopen("CUENTAS.IN","r",stdin);
   freopen("CUENTAS.OUT","w",stdout);
  scanf ("%d%d", &N, &L);

   for (int i = 0; i < N; i++) {
       for (int j = 0; j < L; j++){
         scanf ("%d", &Notas[i][j]);
       }
    }

    for (int i = 0; i < N; i++) {

       for (int j = 0; j < L; j++)
          O += Notas[i][j];
       S = O / L;
       printf ("d%\n", S);
    }


    return 0;
    }




