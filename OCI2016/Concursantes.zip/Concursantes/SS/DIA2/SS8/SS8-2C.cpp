#include <iostream>
#include <cstdio>
using namespace std;

int main()
{ freopen("fumigacion.in","r",stdin);
   freopen("fumigacion.out","w",stdout);
    int N, L, W, H, j, datos[100][3];
     cin >>N;
      cin >>L;
       cin >>W;
        cin >>H;
         for (int i=0 ;i<N; i++){
          cout << endl;
           for (int j=1;j<=2;j++){
           cin >> datos[i][j];
            cout<< datos[i][j];}
}
    cout << j << endl;
    return 0;
}
