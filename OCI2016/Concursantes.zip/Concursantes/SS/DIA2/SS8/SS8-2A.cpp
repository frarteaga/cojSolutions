#include <iostream>
#include <cstdio>
#define max 100
using namespace std;

int main()
{ freopen("TABLAS.IN","r",stdin);
   freopen("TABLAS.OUT","w",stdout);
    bool  l;
     int N, M, K, entra1[max],  entra2[max];
      cin>>N;
       cin>>M;
       for(int j=1; j<=M; j++){
        cin >> entra1[j];
         if(entra1[j]== N)
          l= true;
}
           cin >>K;
            for(int f=1; f<=K; f++){
             cin>> emtra2[f];
              if(entra2[f]== N)
               l=false;
}
                for (int j; j<)

                 cout << j << endl;
    return 0;
