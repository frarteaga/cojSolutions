//Rolando Torrecilla Venegas Sancti Sp�ritus IPVCE Eusebio Olivera Rodr�guez
#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int n,l,w,h;
 int x[10000000],y[10000000];
void coord(int n,int x[1000000],int y[1000000]){

for(int i=0; i<n; i++){
 scanf("%d %d\n",&x[i], &y[i]);
}
}
int main()
{
freopen("FUMIGACION.IN", "r", stdin);
freopen("FUMIGACION.OUT", "w", stdout);
scanf("%d %d %d %d\n",&n,&l,&w,&h);
coord(n,x,y);
if(n<=100000)
    cout<<"-1";
    return 0;
}
