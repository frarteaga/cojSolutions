//Rolando Torrecilla Venegas Sancti Sp�ritus IPVCE Eusebio Olivera Rodr�guez
#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
void valor(int m, int m1[36])
{
  for(int i=0; i<m; i++){
     scanf("%d", &m1[i]);
  }
}
int i,j,n,m,k, m1[36], m2[36],m3[36],r;
int main()
{
freopen("TABLAS.IN", "r", stdin);
freopen("TABLAS.OUT", "w", stdout);
scanf("%d \n%d ",&n,&m);
scanf("%d\n ", &k);
valor(m,m1);
valor(k,m2);
scanf("%d", &r);
if (2*n!=(m+k+r)&&r!=0){
cout<<endl<<"0";
}
else
    cout<<n/2;
    return 0;
}

