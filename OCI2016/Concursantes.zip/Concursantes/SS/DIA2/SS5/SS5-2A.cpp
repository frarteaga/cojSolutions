//Rixon Riverol Ar�valo 11�3 IPVCE SS5-2A
#include <iostream>
#include <cstdlib>
#include <cstdio>

using namespace std;

int main()
{
    freopen("TABLAS.in","r",stdin);
    freopen("TABLAS.OUT","w",stdout);
    int N,M,A[35],B[35],K,C[35];

    cin>>N>>M;
    for(int a=1;a<=M;a++) {cin>>A[a];}
    cin>>K;
    for(int a=1;a<=K;a++) {cin>>B[a];}

    int posMen,men;
    for (int b=1;b<M;b++){
        if(A[b]<A[b+1]){posMen=A[b];}else posMen=A[b+1];
    }
    for (int b=1;b<K;b++){
        if(B[b]<B[b+1]){men=B[b];}else men=B[b+1];
    }
    if (men>posMen){men=posMen;}

    int posMaj,maj;
    for (int b=1;b<M;b++){
        if(A[b]>A[b+1]){posMaj=A[b];}else posMaj=A[b+1];
    }
    for (int b=1;b<K;b++){
        if(B[b]>B[b+1]){maj=B[b];}else maj=B[b+1];
    }
    if (maj<posMaj){maj=posMaj;}

    int y=0,z=0,q=0,conteo=0;
    for(int l=1;l<=maj;l++){
    conteo=0;

        for(int m=1;m<=M;m++){
            if(l!=A[m]){conteo++;}
        }
        for(int n=1;n<=K;n++){
            if(l!=B[n]){conteo++;}
        }

        if(conteo==K+M){q++;C[q]=l;}
    }

    int fila1[35],fila2[35],form=0,camb;

    for (int b=1;b<M;b++){
        if(A[b]>A[b+1]){
        camb=A[b];
        A[b]=A[b+1];
        A[b+1]=camb;
        }
    }
    for (int b=1;b<K;b++){
        if(B[b]>B[b+1]){
        camb=B[b];
        B[b]=B[b+1];
        B[b+1]=camb;
        }
    }
    int p;
    for(int fin;fin<=N;fin++){
    for(int a=1;a<=N;a++){
            for(int yy=1;yy<K;yy++){
                if (A[yy]<=B[yy] && A[yy]<=A[yy+1]){p++;}
            }
        }
    if(p==N){form++;}
    }
    cout<<form;
    return 0;
}
