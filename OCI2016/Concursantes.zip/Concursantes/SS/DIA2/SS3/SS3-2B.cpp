#include <iostream>//Ian Josue Reina Solis IPVCE Sancti Spiritus
#include <cstdio>
using namespace std;

int main()
{
    int N;
    int car=N-1;
    freopen ("RUTAS.IN","r",stdin);
    freopen ("RUTAS.OUT","w",stdout);



    return 0;
}
