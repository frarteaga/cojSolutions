#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;

int main()
{
    int N,L,W,H;
    freopen("FUMIGACION.IN","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);

    return 0;
}
