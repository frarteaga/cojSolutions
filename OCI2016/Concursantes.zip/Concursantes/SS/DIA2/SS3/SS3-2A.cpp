#include <iostream>//Ian  Josue Reina Solis Sancti Spiritus
#include <cstdio>
using namespace std;

int main()
{
    int N,M,K,X;
    int A[M],B[K],C[X];
    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);
    cin>>N;
    cin>>M,A;
    cin>>K,B;
    cin>>X,C;
    if (M=2)
        cout<<A<<endl;
    for ()
    return 0;




}
