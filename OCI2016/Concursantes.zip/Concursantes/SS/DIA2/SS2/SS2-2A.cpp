//Kevin Quintana Garcia 10mo grado IPVCE Eusebio Olivera Rodr�guez Sancti Spiritus
#include <iostream>
#include <cstdio>

using namespace std;
int N,M,K,a,b,D,x,y;
int main()

{   freopen ("Tablas.in","r",stdin);
    freopen ("Tablas.out","w",stdout);
    cin>>N>>M;
    int  A[M];
    for (int i=1;i<=M;i++){
    cin >>A[i];
    }
    cin>>K;
    int B[K];
    for (int o=1;o<=K;o++){
    cin>>B[o];
    }
    for (int e=1;e<=M;e++){
    if(A[e]>A[e+1]){
    a=A[e+1];
    A[e+1]=A[e];
    A[e]=a;}
    }
    for (int u=1;u<=K;u++){
    if(B[u]>B[u+1]){
    b=B[u+1];
    B[u+1]=B[u];
    B[u]=b;}
    }
    for (int c=1;c<=N;c++){
    if(B[c]>A[c])
    D++;

    }
    if (K>M)
    cout<<D-K+M;
    if (M>K)
    cout<<D-M+K;
    return 0;
}
