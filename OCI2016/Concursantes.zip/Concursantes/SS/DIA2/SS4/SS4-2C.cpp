#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    freopen("fumigacion.in","r",stdin);
    freopen("fumigacion.out","w",stdout);
int n, l, w, h, arry1[100][3];

cin>>n>>l>>w>>h;
for (int i=0;i<n;i++){
    cout<< endl;
    for (int j=1;j<=2;j++){
        cin >> arry1[i][j];
        cout<< arry1[i][j];
    }
}
    cout <<n << endl;
    return 0;
}
