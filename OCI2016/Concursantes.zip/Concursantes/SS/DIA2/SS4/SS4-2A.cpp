#include <iostream>
#include <cstdio>
using namespace std;

int main()
{freopen("tablas.in", "r", stdin);
freopen("tablas.out", "w", stdout);

int n,m,l,k, a, b, c,s, orden[10];
if (1<n<=35)
 for (int m=0;m<=n;a++)
for (int k=0;k<=n;b++)

if (a)
 bool  l;
int arry1[36],  arry2[36];

for(int i=1; i<=m; i++){
cin>> arry1[i];
if(arry1[i]== n)
    l= true;
}
cin >>k;
for(int i=1; i<=k; i++){
cin>> arry2[i];
if(arry2[i]== n)
    l=false;
}
    cout << l << endl;
    return 0;
}
