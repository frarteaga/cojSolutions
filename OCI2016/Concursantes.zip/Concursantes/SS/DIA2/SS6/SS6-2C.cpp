#include <iostream>
#include <cstdio>
using namespace std;

int main()
{ freopen("fumigacion.in","r",stdin);
freopen("fumigacion.out","w",stdout);
int n, l, w, h, arry1[100][3];
bool j;
cin>>n>>l>>w>>h;
for (int i=0;i<n;i++){
    for (int j=1;j<=2;j++){
        cin >> arry1[i][j];
    }
}
int i=0, c;
while(i<n){
    for (int x=w;x<=l;x+=w){
   for(int y=h;y<=l; y+=h){
       c=0;
    if((arry1[i][1]<=x) && (arry1[i][2]<=y) && (arry1[i][1]>=x-w) && (arry1[i][2]>=y-h))

    c++;
}}
    i++;
}
    cout << "-1";
    return 0;
}
