#include <iostream>
#include <cstdio>
using namespace std;

int main()
{ freopen("tablas.in","r",stdin);
freopen("tablas.out","w",stdout);
bool  l;
int n, m, k, arry1[36],  arry2[36];
cin>>n>>m;
for(int i=1; i<=m; i++){
cin>> arry1[i];
if(arry1[i]== n)
    l= true;
}
cin >>k;
for(int i=1; i<=k; i++){
cin>> arry2[i];
if(arry2[i]== n)
    l=false;
}
for (int i; i<)

    cout << "Hello world!" << endl;
    return 0;
}
