#include <iostream>
#include <cstring>
#include <cstdio>
#define max=10
using namespace std;

int main()
{
    int N,L,S;
    int Resp;
    string cuent[10];
    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);
    cin>>N,L,S;
    cin>>cuent;
    return 0;
}
