#include <iostream>
#include <cstdio>
using namespace std;

int main()
{int N, M, S, P, Q, T;
   freopen("HEXAGONO.IN", "r", stdin);
   freopen("HEXAGONO.OUT", "w", stdout);
    cin >> N;
     cin >> M;
      cin >> S;
       cin >> P;
        cin >> Q;
         T=S+M-1;
          T-M-1;
       cout << "18" << endl;
       cout <<  "4 3"<< endl;

    return 0;
}
