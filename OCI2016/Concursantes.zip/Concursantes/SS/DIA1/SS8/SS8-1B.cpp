#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;

int main()
{int N, L, S;
   freopen("CUENTAS.IN", "r", stdin);
   freopen("CUENTAS.OUT", "w", stdout);
    cin >> N;
     cin >> L;
      cin >> S;
       cout << "4" << endl;


    return 0;
}
