#include <iostream>
#include <cstdio>
using namespace std;

int main()
{int N, M, K;
   freopen("ROBOT.IN", "r", stdin);
   freopen("ROBOT.OUT", "w", stdout);
    cin >> N;
     cin >> M;
      cin >> K;
       cout << "RRD" << endl;


    return 0;
}
