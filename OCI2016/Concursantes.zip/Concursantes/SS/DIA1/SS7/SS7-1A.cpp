//Alejandro Merino Zayas SS7
#include <iostream>
#include <cstdio>
using namespace std;

int main()
{ freopen("hexagono.in","r",stdin);
freopen("hexagono.out","w",stdout);
int a, b, c, d, e, f[100][100];
cin >>a>>b>>c>>d>>e;
for(int i=c, j=0, h=1;j<a;i++){
   j++;
    f[h][j]=i;
    cout <<  f[h][j];
}
    return 0;
}
