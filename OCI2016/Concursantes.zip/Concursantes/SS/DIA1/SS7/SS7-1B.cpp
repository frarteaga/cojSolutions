//Alejandro Merino Zayas  SS7
#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{   int N,L,S;
    freopen("cuentas.in", "r" ,stdin);
    freopen("cuentas.out", "w" ,stdout);
     cin >>N;
     if (1<= N <=30000) cout <<"N";
     cin >>L;
     if (1<= L <=200)   cout <<"L";
     cin >>S;
     (S==2 && S==64);
    return 0;
}
