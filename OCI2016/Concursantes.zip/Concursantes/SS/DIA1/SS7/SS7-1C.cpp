//Alejandro Merino Zayas SS7
#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{freopen("robot.in","r",stdin);
freopen("robot.out","w",stdout);
    int p,q, r, jue[200][200];
    cin>>p>>q>>r;
    for (int i=1;1<=q;i++){
        for (int j=1;1<=p;j++){
            cin >> jue[i][j];
          if(jue[i][j]>=0)
            cout << jue[i][j];
            else
                cout << "#";
        }
    }

    cout << "Hello world!" << endl;
    return 0;
}
