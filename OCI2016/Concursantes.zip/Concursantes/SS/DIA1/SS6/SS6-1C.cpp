#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{freopen("ROBOT.IN","r",stdin);
freopen("ROBOT.IN","w",stdout);
    int N, M, K;

    cout << "Hello world!" << endl;
    return 0;
}
