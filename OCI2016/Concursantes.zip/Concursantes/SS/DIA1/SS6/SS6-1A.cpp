#include <iostream>
#include <cstdio>
using namespace std;

int main()
{ freopen("HEXAGONO.IN","r",stdin);
freopen("HEXAGONO.OUT","w",stdout);
int n, m, s, p, q, ra[100][100];
cin >>n>>m>>s>>p>>q;
for(int i=s, j=0, h=1;h<n;i++, h++){
   j++;
    ra[h][j]=i;
}
cout<<ra[p][q];
    return 0;
}
