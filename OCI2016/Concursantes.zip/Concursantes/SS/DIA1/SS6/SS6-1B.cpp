#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>
using namespace std;

int main()
{freopen("cuenta.in","r",stdin);
freopen("cuenta.out","w",stdout);
int n, l, s, c=0, p=0,o=0, m[200][200];
cin >>n>>l>>s;
if ( s==2){
for (int i=1; i<n;i++){
for(int j=1;j<l;j++){
         cin>>m[i][j];
        cout<<m[i][j];
    }
        }
while(c<=n){
    c++;
for (int i=1;i<=n;i++){
for (int j=1;j<=l;j++){
     if(m[c][j]==m[i][j])
        p++;
    }
    if(p==l-1)
        o++;
}
}
    cout <<o<< endl;}
    return 0;
}
