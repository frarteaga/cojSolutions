#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
char cad[201][201];
int n,m,k;
int main()
{
   freopen("ROBOT.IN", "r", stdin);
   freopen("ROBOT.OUT", "w", stdout);
     scanf("%d %d %d \n", &n, &m, &k);
for(int i=0; i<n; i++){
       scanf("%s \n", &cad[i]);

      for(int j=0; j<m; j++){
if (cad[i][j]=='0')   cout<<"R";
else if (cad[i][j]!='#'&& j!=m)
    cout<<"D";
else if (cad[i][j]=='#'&& j!=m)
cout<<"R";
  else (j==m);break;
  }
  }
    return 0;
}
