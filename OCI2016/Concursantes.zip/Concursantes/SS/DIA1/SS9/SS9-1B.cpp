#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
char cad[30000][201],cad2[30000][201];
int n,l,s,r;
int main()
{
   freopen("CUENTAS.IN", "r", stdin);
   freopen("CUENTAS.OUT", "w", stdout);
   scanf("%d %d %d \n", &n, &l, &s);
  for(int i=0; i<=n; i++){
      for(int j=n; j>=0; j--){
            for ( int k=0; k<=l; k++){
    scanf("%s \n ", &cad[i]);
    strcpy(cad2[j],cad[i]);
 if(cad[i][k]!=cad2[j][k]){
   r++;
 }
  }}
  }

  cout<<n<<endl;
    return 0;
}
