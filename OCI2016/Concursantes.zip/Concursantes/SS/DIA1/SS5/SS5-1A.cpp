//Rixon Riverol Ar�valo IPVCE SS5
#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    freopen("HEXAGONO.IN","r",stdin);
    freopen("HEXAGONO.OUT","w",stdout);

    int N,M,S,P,Q,espir[100][100],big,bigX,bigY;
    cin>>N>>M>>S>>P>>Q;

    int x=1,cxl,s=S;
    cxl=5+6*((S*2-1)/2);
    big= S+N+1;

for (;x<=2*S-1;x++){
  if(x==1){
        for(int b=1; b<=N;b++){
        espir[x][b]=s;
        s++;}}

  if(x==2){
        for(int b=0; b<=N;b++){
        espir[x][b]=S+cxl+b;
        if (b==N){espir[x][b]=s++;}
    }s++;}
}
cout <<espir[P][Q]<<"\n";
cout<<bigX<<" "<<bigY;

return 0;  //this it's so hard teacher, we are not pro
}
