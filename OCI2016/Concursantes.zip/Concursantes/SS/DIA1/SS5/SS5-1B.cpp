//Rixon Riverol Ar�valo IPVCE SS5
#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

int main()
{
    freopen("CUENTA.IN","r",stdin);
    freopen("CUENTA.OUT","w",stdout);
    int N,L,S,fin=0;
    char siml[30000];
    cin >>N>>L>>S;
    for(int a=1; a<=N; a++){
        for(int b=1; b<=L; b++){
            cin >>siml[L];
        }
    }
    int dif='a'-'A';
    if(S==64){
    int l=L;

        for(int x=1; x<=N-1; x++){
            if((siml[x]==siml[x+l]) || (siml[x]==siml[x+l]+dif) || (siml[x]==siml[x+l]-dif)){

            int same=1;

               for(int y=x+1; y<=L; y++){

                if((siml[x]!=siml[x+l]) || (siml[x]!=siml[x+l]+dif) || (siml[x]!=siml[x+l]-dif))
                {break;}
                else {same++;l+=L;}
               }

            if(same==L-1){fin++;}
            }
           else continue;
        }
    cout<<fin;
    }
    if (S==2){
    int l=L;

        for(int x=1; x<=N-1; x++){
            if(siml[x]==siml[x+l]){

            int same=1;

               for(int y=x+1; y<=L; y++){

                if(siml[x]==siml[x+l])
                {break;}
                else {same++;l+=L;}
               }

            if(same==L-1){fin++;}
            }
           else continue;
        }
    cout<<fin;
    }
    return 0;   //this it's so hard teacher, we need test more normal
}
