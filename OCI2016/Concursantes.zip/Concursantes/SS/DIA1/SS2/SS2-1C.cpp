//Kevin Quintana Garcia
#include <iostream>
#include <cstdio>
#define max 200
using namespace std;
int N,M,K,a,b,o;
int main()
{

    freopen("ROBOT.in","r",stdin);
    freopen("ROBOT.out","w",stdout);
    cin >>N>>M>>K;
    int z[max][max];
    for (a=1;a<=M;a++){
    for (b=1;b<=N;b++){
    for (o=K;o>0;o--){
    if (z[a+1][b]>z[a][b])
    cout<<"D";
    if (z[a][b+1]>z[a][b])
    cout<<"R";
    if(z[a+1][b]!='#')
    cout<<"R";
    if(z[a+1][b]!='#')
    cout<<"D";
    }
    }
    }
    return 0;

}
