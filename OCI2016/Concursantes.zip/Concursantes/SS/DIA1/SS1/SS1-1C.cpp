//Usiel Garc�a Bormey 10mo IPVCE: Eusebio Olivera Rodr�guez.
#include <iostream>
#include <cstdio>
using namespace std;
int N,M,K;
int c=0,c1=0;
int arreglo[200][200],arreglos[200],arregloi[200];
int main()
{
    freopen("ROBOT.in"," r",stdin);
    freopen("ROBOT.out","w",stdout);
    cin>>N>>M>>K;
   for(int s=1;s<=N;s++){
        cin>>arreglos[s];
        }
   for(int i=1;i<=M;i++){
        cin>>arregloi[i];
        }
    for(int s=1;s<=N;s++){
        for(int i=1;i<=M;i++){
    if(arreglo[s][i+1]>arreglo[s+1][i]){
        c=c+arreglo[s][i+1];
        }
    else{
        c1=c1+arreglo[s+1][i];
        }
       }
           if(c>c1){
        cout<<"R";
    }
    else{
        cout<<"D";
    }
    }
    return 0;
}
