#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{char cuet[200][30000], n, l, s;
    freopen("cuenta.in","r",stdin);
freopen("cuenta.out","w",stdout);
cin>>
strcmp()

    cout << "x" << endl;
    return 0;
}
