#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{
freopen("ROBOT.in","r",stdin);
freopen("ROBOT.out","w",stdout);
    int n, m, k, game[200][200];
    cin>>n>>m>>k;
    for (int i=1;1<=m;i++){
        for (int j=1;1<=n;j++){
            cin >> game[i][j];
          if(game[i][j]>=0)
            cout << game[i][j];
                if (game[i][j+1])
                    cout<<"R";
                if (game[i+1][j])
                    cout<<"D";
                        }
    }

    return 0;
}
