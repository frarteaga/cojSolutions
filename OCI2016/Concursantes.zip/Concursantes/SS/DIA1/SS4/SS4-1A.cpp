#include <iostream>
#include <cstdio>
using namespace std;

int main()
{ freopen("HEXAGONO.IN","r",stdin);
freopen("HEXAGONO.OUT","w",stdout);
int n, m, s, p, q, ra[100][100];
cin >>n>>m>>s>>p>>q;
for(int i=s, j=0, h=1;j<n;i++){
   j++;
    ra[h][j]=i;
    cout <<  ra[h][j];
}
if (p,q=0)


    return 0;
}
