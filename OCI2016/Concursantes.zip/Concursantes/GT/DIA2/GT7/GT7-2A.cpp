//Nombre y Apellidos: Rolff Ramos Duran
//Grado: 10mo
//Escuela: Jose Marcelino Maceo Grajales

#include <bits/stdc++.h>

using namespace std;

int M,N,K,mat;
int m[999999],k[99999],A[999999];

int main()
{
    freopen ( "TABLAS.IN","r",stdin );
    freopen ( "TABLAS.OUT","w",stdout );

    scanf ( "%d",&N );
    scanf ( "%d",&M );
    for ( int i=1;i<=M;i++ ){
        scanf ( "%d",&m[i] );
    }
    scanf ( "%d",&K );
    for ( int j=1;j<=K;j++ ){
        scanf ( "%d",&k[j] );
    }
    int res=2;
    for ( int l=1;l<=M+K;l++ ){mat[i-1][j]+mat[i-1][j-1]
        if ( m[l]<m[l+1] && m[l]!=0 || m[l]<m[l-1]  ){
            if ( m[l]==0 ){break; }
            //printf ( "%d%d",m[l],m[l-1] );
        }
        if ( k[l]<k[l+1] || k[l]<k[l-1] ){
            if ( k[l]==0 ){break; }
            //printf ( "%d%d\n",k[l],k[l+1] );
        }

    }
    printf ( "%d",res );
   /** for ( int s=1;s<=N;s++ ){
        for ( int q=1;q<=s;q++ ){
            mat[i-1][j]+mat[i-1][j-1]
        }
    }
    printf ( "%d",comb );
*/
    return 0;
}
