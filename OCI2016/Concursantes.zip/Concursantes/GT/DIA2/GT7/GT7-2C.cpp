//Nombre y Apellidos:Rolff Ramos Duran
//Grado: 10mo
//Escuela: Jose Marcelino Maceo Grajales

#include <bits/stdc++.h>

using namespace std;

int N,L,W,H,mal=-1;
int XY[9999][9999];

int main()
{
    freopen ( "FUMIGACION.IN","r",stdin );
    freopen ( "FUMIGACION.OUT","w",stdout );

    scanf ( "%d%d%d%d",&N,&L,&W,&H );
    for ( int i=1;i<=N;i++ ){
        for ( int j=1;j<=i;j++ ){
           scanf ( "%d",&XY[i][j] );


    }

    }
    printf ("%d", mal);

    return 0;
}
