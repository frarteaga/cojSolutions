/**Karla D�az Gurri
D�cimo grado
IPVCE Jos� Marcelino Maceo Grajales**/

#include <bits/stdc++.h>

using namespace std;

int M,N,K;
int A[35],B[35],C[35],S[100][100];

int main()
{
    freopen ( "TABLAS.IN","r",stdin );
    freopen ( "TABLAS.OUT","w",stdout );

    scanf ( "%d%d",&N,&M );

    for ( int i=1;i<=M;i++ ){
        scanf ( "%d",&A[i] );
    }
    scanf ( "%d",&K );
    for ( int i=1;i<=K;i++ ){
        scanf ( "%d",&B[i] );
    }

        for (int j=1;j<=N;j++){
            S[1][j]=A[j];
            S[2][j]=B[j];

        }
   printf("%d",S[1][2]);

    return 0;
}
