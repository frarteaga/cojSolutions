/**Karla D�az Gurri
D�cimo grado
IPVCE Jos� Marcelino Maceo Grajales**/

#include <bits/stdc++.h>

using namespace std;
int N,W,L,H,n,s,d,S[11111][1111];
int main()
{
    freopen("FUMIGACION.IN","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);

   cin>>N>>L>>W>>H;
    for(int k=1;k<=L;k++){
        for(int j=1;j<=L;j++){
            S[k][j]=0;
        }
      }

      for(int i=1;i<=N;i++){
        scanf("%d%d",&s,&d);
        S[s][d]=1;
      }


   n=-1;
   cout<<n;

    return 0;
}
