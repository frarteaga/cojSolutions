/**
Joel Daniel Matos D�az GT2
12mo Grado
IPVCE Jose Marcelino Maceo Grajales
*/

#include <bits/stdc++.h>

using namespace std;
long long T,N,W,H,x,y,det,cont;
typedef pair<long long ,long long >par;
map <par , long long>M;

int main()
{
    freopen("FUMIGACION.IN"  , "r" ,stdin);
    freopen("FUMIGACION.OUT" , "w" ,stdout);

    scanf( "%lld%lld%lld%lld",&T , &N , &W  , &H);
    long long lf = N - W +1 ;

    long long lc = N - H +1 ;
    long long l = T;
    while(T--){
        scanf("%lld%lld" ,&x ,&y );
        int rrf = x- H+1;
        int rrc = y- W+1;
        rrc =(rrc >=0 )? rrc : 0;
        rrf =(rrf >=0 )? rrf : 0;

        for(long long i= rrf; i<= x ;i++ ){
            for(long long j = rrc ; j<= y ;j++){
/**
0 0 1 2 3 4 5 6 7 8 9 10
0 x x x x x x x x 0 0 0
1 x x x x x x x x 0 0 0
2 x x x x x x x x 0 0 0
3 x x x x x x x x 0 0 0
4 x x x x x x x x 0 0 0
5 x x x x x x x x 0 0 0
6 x x x x x x x x 0 0 0
7 0 0 0 0 0 0 0 0 0 0 0
8 0 0 0 0 0 0 0 0 0 0 0
9 0 0 0 0 0 0 0 0 0 0 0
100 0 0 0 0 0 0 0 0 0 0

*/
                if(M[par(i ,j)])continue;
                if(i  > lf || j  > lc){
                   /// det = true;
                    break;
                }
                M[par(i ,j )]= true;
                cont++;

                if(cont == (lf+1)*(lc+1)){

                    printf("%lld" , l -T);
                    return 0;
                }

            }

        }


    }
    printf("-1");
    return 0;
}

