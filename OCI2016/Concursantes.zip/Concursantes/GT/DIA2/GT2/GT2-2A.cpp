/**
Joel Daniel Matos D�az GT2
12mo Grado
IPVCE Jose Marcelino Maceo Grajales
*/


#include <bits/stdc++.h>

using namespace std;


vector <int >V[10];
long long Sol,A,B,C,N,x,mk[1010],T[1010];
long long AD[110];

int DFS(int pos , int num){



        if(pos <= N){
            for(int i=0;i< V[1].size();i++){
                int nn = V[1][i];
                if(mk[nn] || T[pos-1] > nn || nn == num)continue;
                    mk[nn] =true;
                    T[pos] = nn;
                    DFS(pos +1 , nn);
                    mk[nn] = false;
                    T[pos] = 0;


            }
            for(int i =0 ;i<V[3].size() ; i++){
                 int nn = V[3][i];
                if(mk[nn] || T[pos-1]> nn || nn == num)continue;
                    mk[nn] =true;
                    T[pos] = nn;
                    DFS(pos +1 , nn);
                    mk[nn] = false;
                    T[pos] = 0;


            }

        }
        else {
            if(pos == (2*N)+1){
                Sol++;
                return 0;
            }
            for(int i=0 ;i< V[2].size() ;i++){
                int nn = V[2][i];
                if(T[pos%N]> nn || mk[nn] || T[(pos == N+1) ?1000 : pos -1]> nn || nn == num)continue;
                    mk[nn] =true;
                    T[pos] = nn;
                    DFS(pos +1 , nn);
                    mk[nn] = false;
                    T[pos] = 0;


            }
             for(int i=0 ;i< V[3].size() ;i++){
                int nn = V[3][i];
                if(T[pos%N]> nn || mk[nn] || T[pos-1]> nn || nn == num)continue;
                    mk[nn] =true;
                    T[pos] = nn;
                    DFS(pos +1 , nn);
                    mk[nn] = false;
                    T[pos] = 0;


            }







        }








}

int main()
{
    freopen("TABLAS.IN"  , "r " ,stdin);
    freopen("TABLAS.OUT" , "w " ,stdout);

    scanf("%d%d" ,&N , &A);
    for(int i=1 ;i<= A;i++){
        scanf("%d" , &x);
        AD[x]=true;
        V[1].push_back(x);
    }
    scanf("%d" , &B);
    for(int i=1 ;i<= B;i++){
        scanf("%d" , &x);
        AD[x]=true;
        V[2].push_back(x);
    }
    int C;
    for(int i=1 ;i<=N+N;i++){
        if(!AD[i]){
            V[3].push_back(i);
            C=i;
        }
    }
    sort(V[1].begin() , V[1].end());
    sort(V[2].begin() , V[2].end());
    sort(V[3].begin() , V[3].end());

    DFS(1 , 0);
    printf("%d" , Sol);
    return 0;
}
