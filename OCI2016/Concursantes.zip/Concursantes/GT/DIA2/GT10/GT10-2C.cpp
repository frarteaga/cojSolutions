/** Joel Alejandro Valdespino Matos
    11no
    IPU Ruben Batista Rubio**/


#include <bits/stdc++.h>

using namespace std;
int a,b,c,d,n;

int main()
{


   freopen ("FUMIGACION.IN","r",stdin);
   freopen ("FUMIGACION.OUT","w",stdout);

    scanf ("%d%d%d%d",&a,&b,&c,&d);

    for ( int i=1;i<=a*2;i++ )
    {
        scanf ("%d",&n);
        }

    printf ("%d",-1);

    return 0;
}
