/** Joel Alejandro Valdespino Matos
    11no
    IPU Ruben Batista Rubio**/

#include <bits/stdc++.h>

using namespace std;

int x,y,num,pri[1002],seg[1002],sol[35][35];

int main()
{

    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);


   scanf ("%d%d",&num,&x);
    for (int i=1;i<=x;i++){
        scanf ("%d",&pri[i]);
    }
     for (int i=1;i<=x;i++){
        scanf ("%d",&seg[i]);
    }
   for (int i=1;i<=1;i++){

    for (int j=1;j<=x;j++){

        sol[i][j]=pri[j];}}

printf("%d",(sol[1][1])-1);

    return 0;
}
