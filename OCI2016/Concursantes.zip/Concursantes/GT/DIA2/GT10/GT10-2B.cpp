/** Joel Alejandro Valdespino Matos
    11no
    IPU Ruben Batista Rubio**/


#include <bits/stdc++.h>

using namespace std;
int a,b,c,d,e,f,q,h,i,j,k,l,m;
int main()
{
    freopen ("RUTAS.IN","r",stdin);
   freopen ("RUTAS.OUT","w",stdout);

scanf ("%d%d%d%d%d%d%d%d%d%d%d%d%d",&a,&b,&c,&d,&e,&f,&q,&h,&i,&j,&k,&l,&m);

printf ("%d %d\n",f,c+b);

printf ("%d %d\n",d-c,c);

printf ("%d %d\n",d-c,0);

printf ("%d %d\n",0,0);







    return 0;
}
/*
5
1 2 2
2 3 1
2 4 2
1 5 3*/



