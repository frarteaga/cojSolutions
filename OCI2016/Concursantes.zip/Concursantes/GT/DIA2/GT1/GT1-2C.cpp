#include <bits/stdc++.h>

using namespace std;

const int MAXN = 1002;

struct point {
   int x, y;
}P[MAXN];

int n, L, A, B;

bool check1(int i, int j){
    if ( P[i].x - A <= P[j].x && P[i].y - B <= P[j].y )
        return true;
    return false;
}

bool check2(int i, int j){
    if ( P[i].x + A >= P[j].x && P[i].y - B <= P[j].y )
        return true;
    return false;
}

bool check3(int i, int j){
    if ( P[i].x - A <= P[j].x && P[i].y + B >= P[j].y )
        return true;
    return false;
}

bool check4(int i, int j){
    if ( P[i].x + A >= P[j].x && P[i].y + B >= P[j].y )
        return true;
    return false;
}

int main()
{
    freopen("FUMIGACION.in","r",stdin);
    freopen("FUMIGACION.out","w",stdout);

    scanf ( "%d%d%d%d", &n, &L, &A, &B );

    for ( int i = 1; i <= n; i ++ ){
        scanf ( "%d%d", &P[i].x, &P[i].y );
    }

    int Sol = n;

    for ( int i = 1; i <= n; i ++ ){

        bool band1 = false, band2 = false, band3 = false, band4 = false;

        for ( int j = 1; j <= n; j ++ ){
            if ( i == j )
                continue;

            if ( check1(i,j) )
                band1 = true;

             if ( check2(i,j) )
                band2 = true;

              if ( check3(i,j) )
                band3 = true;

              if ( check4(i,j) )
                band4 = true;
        }

        if ( band1 && band2 && band3 && band4 )
            Sol --;
    }
    return 0;
}
