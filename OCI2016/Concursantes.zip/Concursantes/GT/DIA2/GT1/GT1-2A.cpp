#include <bits/stdc++.h>

using namespace std;

const int MAXN = 102;

int mk1[MAXN], P1[MAXN], Na[MAXN];
int mk2[MAXN], P2[MAXN], Nb[MAXN];
int Sol, P, Q, n, ca, cb, val;

void comb2(){

     if ( P1[cb] > P2[cb] )
         return;

     if ( cb == n ){
        Sol ++;
        return;
     }

     for ( int i = 1; i <= 2*n; i ++ ){
          if ( Na[i] || mk1[i] )
            continue;

          if ( !mk2[i] ){

             if ( P2[cb] > i )
                continue;

             P2[++cb] = i;



             mk2[i] = 1;

             comb2();

             mk2[i] = 0;
             cb --;
          }

     }
}

void comb1(){

     if ( ca == n ){
        comb2();
        return;
     }

     for ( int i = 1; i <= 2*n; i ++ ){
          if ( Nb[i] )
            continue;

          if ( !mk1[i] ){

             if ( P1[ca] > i )
                continue;

             P1[++ca] = i;
             mk1[i] = 1;

             comb1();

             mk1[i] = 0;
             ca --;
          }

     }
}

int main()
{
    freopen ( "TABLAS.in", "r", stdin );
    freopen ( "TABLAS.out", "w", stdout );

    scanf ( "%d", &n );

    scanf ( "%d", &P );

    for ( int i = 1; i <= P; i ++ ){
        scanf ( "%d", &val );
        Na[val] = 1;
    }

     scanf ( "%d", &Q );

    for ( int i = 1; i <= Q; i ++ ){
        scanf ( "%d", &val );
        Nb[val] = 1;
    }

    comb1();

    printf ( "%d", Sol );
    return 0;
}
