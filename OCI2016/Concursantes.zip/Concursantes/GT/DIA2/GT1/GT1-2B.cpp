#include <bits/stdc++.h>

using namespace std;

const int MAXN = 500002;

int M1[MAXN], M2[MAXN], mk[MAXN], grad[MAXN];

struct arist {
    int n1, n2;
}conx[MAXN];

typedef pair<int,int>two;
typedef pair<int,two>tri;

vector<tri>V[MAXN];

int n, root, a, b, c;

void Dfs1 ( int nod, int pad ){
     M1[nod] = M2[nod] = 0;

     if ( grad[nod] > 1 )
        root = nod;

     int sz = V[nod].size();

     for ( int i = 0; i < sz; i ++ ){

          int newn = V[nod][i].second.first;
          int cost = V[nod][i].second.second;
          int id = V[nod][i].first;

          if ( newn == pad )
            continue;

          if ( mk[id] )
            continue;

          Dfs1 (newn,nod);

     }
}

void Dfs ( int nod, int pad ){

     int sz = V[nod].size();

     for ( int i = 0; i < sz; i ++ ){

          int newn = V[nod][i].second.first;
          int cost = V[nod][i].second.second;
          int id = V[nod][i].first;

          if ( mk[id] )
            continue;

          if ( newn == pad )
            continue;

          Dfs (newn,nod);

          if ( M1[newn] + cost > M1[nod] ){
              M2[nod] = M1[nod];
              M1[nod] = M1[newn] + cost;
          } else if ( M1[newn] + cost > M2[nod] ){
              M2[nod] = M1[newn] + cost;
          }
     }
}

int main()
{
    freopen ("RUTAS.in","r",stdin);
    freopen ("RUTAS.out","w",stdout);

    scanf ( "%d", &n );

    for ( int i = 1; i < n; i ++ ){
        scanf ( "%d%d%d", &a, &b, &c );

        conx[i].n1 = a;
        conx[i].n2 = b;

        V[a].push_back(tri(i,two(b,c)));
        V[b].push_back(tri(i,two(a,c)));

        grad[a] ++;
        grad[b] ++;
    }

    for ( int i = 1; i < n; i ++ ){

        int Sol1, Sol2;

        mk[i] = 1;

        int a = conx[i].n1;
        int b = conx[i].n2;

        grad[a] --;
        grad[b] --;

        root = 0;

        Dfs1(a,-1);

        if ( !root )root = a;

        Dfs (root,-1);

        Sol1 = M1[root] + M2[root];

        // second seccion
        root = 0;

        Dfs1(b,-1);

        if ( !root )root = b;

        Dfs (root,-1);

        Sol2 = M1[root] + M2[root];

        if ( Sol1 < Sol2 )
            printf ( "%d %d\n", Sol1, Sol2 );
        else
            printf ( "%d %d\n", Sol2, Sol1 );
    }
    return 0;
}
