#include <bits/stdc++.h>

using namespace std;

int N,M,W,H;
int a,b;
int mat[5000][5000];

int main()
{
    freopen("FUMIGACION.in","r",stdin);
    freopen("FUMIGACION.out","w",stdout);

      scanf("%d%d%d%d",&N,&M,&W,&H);
      for(int i=1;i<=M;i++){
        for(int j=1;j<=M;j++){
            mat[i][j]=0;
        }
      }

      for(int i=1;i<=N;i++){
        scanf("%d%d",&a,&b);
        mat[a][b]=1;
      }

     printf("-1");
    return 0;
}
