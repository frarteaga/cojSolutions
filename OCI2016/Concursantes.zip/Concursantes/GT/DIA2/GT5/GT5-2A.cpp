#include <bits/stdc++.h>

using namespace std;

int Ar[70];
int T[70];
int N,M,K,sol,cont;
int l;
int main()
{
    freopen("TABLAS.in","r",stdin);
    freopen("TABLAS.out","w",stdout);

      scanf("%d%d",&N,&M);

    for (int i=1;i<=M;i++){
      scanf("%d",&Ar[i]);
 cont+=Ar[i];
 }
   scanf("%d",&K);
  for (int i=1;i<=K;i++){
      scanf("%d",&T[i]);
 cont+=T[i];
 }
 l=N+M+K;
sol=cont/l;
printf("%d",sol);


    return 0;
}
