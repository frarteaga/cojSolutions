///javier noa dieguez
///jose maseo grajales 11no
#include <bits/stdc++.h>

using namespace std;

int N,A,B;
 int MC[60],KT[60];
  int c=1;
   int PL[35][35];
    int main()
{

    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);

      cin>>N;
         for (int i=1;i<=N;i++){
           cin>>MC[i];
    }
       for (int i=1;i<=N;i++){
          cin>>KT[i];
    }

       for (int i=1;i<=2;i++){
           for (int jN=1;jN<=N;jN++){
             PL[i][jN]=MC[jN];
       }

        }


    printf("%d",PL[1][1]);


    return 0;
}
