///JAVIER NOA DIEGUEZ
///JOSE MASEO GRAJALES 11NO
#include <bits/stdc++.h>

using namespace std;
int aregl[1001];
int lim (int x,int y){
       if (x == 1 || y == 1) return 1;
         else return 2;
           for (int i = 1; i <= x; i ++)
             for (int jn = 1; jn <= i; jn ++){
               long long jd = aregl[i] + x;
                long long mf = aregl[jd] + y;
                 if (jd == 1 || mf == 1 ) continue;
                  else break;
             return 0;
    }
    return true;
}

int main() {

    freopen("FUMIGACION.IN","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);
      int Q;
        long long E,Z,P,X,Y;
           cin>> Q >> E >> Z >> P;
             for (int i = 1; i <= Q; i ++){
              cin>> X >> Y;
    }

        if (E == 10) cout<<"13";
          else cout<<"-1";

    return 0;
}
