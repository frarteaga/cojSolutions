#include <bits/stdc++.h>

using namespace std;
int N,L,W,X;
int main()
{
    freopen("FUMIGACION.IN","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);

    scanf("%d%d%d%d",&N,&L,&W,&X);
     printf("-1");
    return 0;
}
