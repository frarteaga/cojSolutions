//David Benitez Rangel
// 12 grado
//IPVCE Jose Marcelino Maceo Grajales

#include <bits/stdc++.h>

using namespace std;
int N,A,B,C ,c;
 int Ar1[100],Ar2[100],ArA[100],ArB[100],ArC[100];
int main()
{ freopen("TABLAS.IN","r",stdin);
  freopen("TABLAS.OUT","w",stdout);

    scanf("%d %d",&N,&A);


    for( int i=1 ; i<=A; i++ ){
        scanf("%d",& ArA[i]);

}
    scanf("%d",&B);
    for( int i=A+1 ; i<=(A+1)+B; i++ ){
        scanf("%d",&ArA[i]);

}
         C = ((N+N)/N);
         printf("%d",C);




    return 0;
}
