/** Emanuel Cateura Fernandez   11no
   IPVCE Jose Maceo Grajales  Guant�namo  */
#include <bits/stdc++.h>

using namespace std;

int main() {

    freopen("RUTAS.IN","r",stdin);
    freopen("RUTAS.OUT","w",stdout);
    int N,x,y,z;
    scanf("%d",&N);
    while(cin>>x>>y>>z){
       printf("%d %d\n",0,x);
    }


    return 0;
}
