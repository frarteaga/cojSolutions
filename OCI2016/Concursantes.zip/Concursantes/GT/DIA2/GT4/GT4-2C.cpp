/** Emanuel Cateura Fernandez   11no
   IPVCE Jose Maceo Grajales  Guant�namo  */
#include <bits/stdc++.h>

using namespace std;
int ar[1001];
int fum (int x,int y){
    if (x == 1 || y == 1) return 1;
    else return 2;
    for (int i = 1; i <= x; i ++)
    for (int j = 1; j <= i; j ++){
        long long mk = ar[i] + x;
        long long mg = ar[j] + y;
        if (mk == 1 || mg == 1 ) continue;
        else break;
        return 0;
    }
    return true;
}

int main() {

    freopen("FUMIGACION.IN","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);
    int N;
    long long L,W,H,X,Y;
    cin>> N >> L >> W >> H;
    for (int i = 1; i <= N; i ++){
        cin>> X >> Y;
    }
    /*if (mat[i+1][j] + mat[i+1][j-1] + mat[i][j-1] - mat[j][i+1] == 1) return true;
    fum(x,y);
    printf("%d",sol);
    */
    printf("-1");

    return 0;
}
