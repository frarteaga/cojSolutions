 /**Karla D�az Gurri
 D�cimo grado
 IPVCE Jos� Marcelino Maceo Grajales**/

 #include <bits\stdc++.h>

using namespace std;
int K[30000],sol;
int N,L,S;
int main()
{     freopen("CUENTAS.IN","r",stdin);
      freopen("CUENTAS.OUT","w",stdout);

       scanf ( "%d%d%d",&N,&L,&S );
    for ( int j=N;j>=1;j-- ){
        scanf ( "%s",&K[j] );

        if ( K[j]!=K[j+L] ){
            sol++;
        }
    }
    printf ( "%d",sol );

    return 0;
 }
