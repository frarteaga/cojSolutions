///javier noa dieguez
///IPVCE Jose Maceo Grajales  11no
#include <bits/stdc++.h>

using namespace std;

int mvx[]={1,0};
 int mvy[]={0,-1};
  int L,M,K;
   char rob[100001];
    char mat[1001][1001];
      int mk[1001][1001];

void dfs(int x, int y){
     if (x > L && y > M){
        return;
     }
          for (int i = 0; i < 2; i ++){
             int mx = x + mvx[i];
               int my = y + mvy[i];
                 if (mat[mx][my] == '#' || mk[mx][my] == 1 ) continue;
                   if (mvx[i] == 1){
                     rob[i] = 'R';
        }
                        else rob[i] = 'D';
     }

}

int main() {

    freopen ("ROBOT.IN","w",stdin);
    freopen ("ROBOT.OUT","w",stdout);

     scanf("%d%d%d",&L,&M,&K);
      for (int i = 1; i <= L; i ++)
        for (int j = 1; j <= M; j ++){
            cin>> mat[i][j];
    }
    dfs(0,0);
    cout<< rob;

    return 0;
}
