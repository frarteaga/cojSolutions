///javier noa dieguez
///IPVCE Jose Maceo Grajales  11no Guant�namo
#include <bits/stdc++.h>

using namespace std;
int B,Z,M,cont;
string tip;
int main() {

    freopen ("CUENTAS.IN","r",stdin);
    freopen ("CUENTAS.OUT","w",stdout);

               scanf("%d%d%d",&B,&Z,&M);
                  for (int i = 1; i <= B; i ++){
                     cin>> tip;
                        if (tip.substr(0,Z) == tip.substr(0,Z+Z)) cont ++;
        }

                         cout<<cont;
    return 0;
}
