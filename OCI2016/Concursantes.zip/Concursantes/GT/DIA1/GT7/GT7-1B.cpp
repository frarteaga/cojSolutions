//Nombre y Apellidos: Rolff Ramos Duaran
//Grado: 10mo
//Escuela: Jose Marcelino Maceo Grajales
//como puedo tomar un valor de la cadena???rolff.
#include <bits/stdc++.h>

using namespace std;

int C[200];
int N,L,S,cont=-1;
string A,B;

int main(){

    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);

    scanf ( "%d%d%d",&N,&L,&S );
    for ( int i=1;i<=N/2;i++ ){
        cin>>A>>B;
    for ( int j=1;j<=L;j++ ){
        if ( A[j]==B[j] ){
            cont++;
        }
    }
    }

       printf ( "%d",cont );

    return 0;
 }
