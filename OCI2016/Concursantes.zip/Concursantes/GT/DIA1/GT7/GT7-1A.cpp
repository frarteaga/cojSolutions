#include <bits/stdc++.h>

using namespace std;
long long N,M,S,P,Q, Mat[10001][10001];



int main()
{
    freopen ("HEXAGONO.IN" , "r" , stdin);
    freopen ("HEXAGONO.OUT" , "w" , stdout);
    scanf("%lld%lld%lld%lld%lld" ,&N ,&M ,&S, &P, &Q);
    long long X = N, Y = 1, W =1, Z = S ;
    long long i = 1, j = 1, k=1, c=0;
    long long sol1=0;


    while (X!=1){
        for (i=Y, j=W, k=1; k<=X; k++, j++) {
                Mat[i][j] = Z;
                Z++;
                if (i==P && j==Q) sol1 = Mat[i][j];
                c++;
                if (c==M) goto fin;

        }
        for (  i++, k=1; k<X; k++, j++, i++) {
                Mat[i][j] = Z;
                Z++;
                if (i==P && j==Q) sol1 = Mat[i][j];
                c++;
                if (c==M) goto fin;

        }
        for ( j-=2, k=1; k<X; k++, j--, i++) {
            Mat[i][j] = Z;
            Z++;
            if (i==P && j==Q) sol1 = Mat[i][j];
            c++;
            if (c==M) goto fin;
        }
        for ( i-=1, k=1; k<X; k++,j--) {
            Mat[i][j] = Z;
            Z++;
            if (i==P && j==Q) sol1 = Mat[i][j];
            c++;
            if (c==M) goto fin;
        }
        for ( i-=1, j++, k=1; k<=2*X-3; k++, i--) {
            Mat[i][j] = Z;
            Z++;
            if (i==P && j==Q) sol1 = Mat[i][j];
            c++;
            if (c==M) goto fin;
        }
        X--;
        Y++;
        W++;
    }
    Mat[Y++][W++]=Z;

fin:

    printf("%lld\n%lld %lld", sol1, i, j);

    return 0;
}
