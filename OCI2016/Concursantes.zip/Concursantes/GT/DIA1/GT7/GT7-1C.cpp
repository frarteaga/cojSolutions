//Nombre y Apellidos: Rolff Ramos Duran
//Grado:10mo
//Escuela:Jose Marcelino Maceo Grajales

#include <bits/stdc++.h>

using namespace std;

char A[200][200], cont[200];
int N,M,K,Ex,Ey;
int mox[2]={0,1}, moy[2]={1,0}, mk[200][200];
void Premios ( int x,int y ){
    if ( x==N && y==M ){
        return;
}
for( int i=0;i<K;i++ ){
  Ex=x+mox[i];
  Ey=y+moy[i];
  if( A[Ex][Ey]=='#'||mk[Ex][Ey]==1 )
  continue;
  mk[Ex][Ey]=1;
    if(mox[i]==0){
    cont[i]='R';
}
    else if (mox[i]==1){
    cont[i]='D';
}
}
}
int main()
{
  freopen( "ROBOT.IN","r",stdin );
  freopen( "ROBOT.OUT","w",stdout );
    scanf("%d%d%d",&N,&M,&K);
    for( int i=1;i<=N;i++ ){
        for( int j=1;j<=M;j++ ){
            scanf( "%c",&A[i][j] );
}
}
    Premios(1,1);

for(int i=0;i<K;i++){
    printf("%c",cont[i]);
}
    return 0;

}
