/***************************************
   luis david gomez jimenez

   IPVCE "Jose Marcelino Maceo Grajales"
          12mo

****************************************/
#include <bits/stdc++.h>

using namespace std;

typedef pair<int,int>two;
typedef pair<int,two>tri;

const int MAXN = 202;

int Dp[MAXN][MAXN];

queue<tri>Q;

int Sol, n, m, k;
int idx, idy;

char mat[MAXN][MAXN];
int memo[MAXN][MAXN];

int mox[] = {0,1,0};
int moy[] = {0,0,1};

char M[] = {'*','D','R'};
char mov[MAXN];

void ptr(){
     int ptr = 0;

     while ( memo[idx][idy] ){
          int m = memo[idx][idy];

          mov[++ptr] = M[m];
          idx -= mox[m];
          idy -= moy[m];
     }

     for ( int i = ptr; i >= 1; i -- )
       printf ( "%c", mov[i] );
}

void Bfs (){

    Q.push(tri(0,two(1,0)));

    for (;!Q.empty();Q.pop()){

        tri pp = Q.front();

        int x = pp.second.first;
        int y = pp.second.second;
        int cost = pp.first;

        for ( int i = 1; i <= 2; i ++ ){

             int mx = x + mox[i];
             int my = y + moy[i];
             int newc = cost + 1;

             if ( mx > n || my > m || mat[mx][my] == '#' || Dp[x][y] + (mat[mx][my] - '0') < Dp[mx][my] )
                 continue;

             if ( newc > k )
                continue;

             if ( Dp[x][y] + (mat[mx][my] - '0') > Dp[mx][my] ){

                Dp[mx][my] = Dp[x][y] + (mat[mx][my] - '0');
                memo[mx][my] = i;
             }

             if ( Sol < Dp[mx][my] )
             {
                 Sol = Dp[mx][my];
                 idx = mx;
                 idy = my;
             }

             Q.push(tri(newc,two(mx,my)));
        }
    }
}

int main()
{
    freopen ( "ROBOT.in", "r", stdin );
    freopen ( "ROBOT.out", "w", stdout );

    scanf ( "%d%d%d", &n, &m, &k );

    for ( int i = 1; i <= n; i ++ ){
        scanf("%s", &mat[i]);
    }

    m --;

    if ( mat[1][0] == '#' )
        return 0;

    Bfs();

    ptr();

    return 0;
}
