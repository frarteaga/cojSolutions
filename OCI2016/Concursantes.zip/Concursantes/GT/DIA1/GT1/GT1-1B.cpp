/***************************************
   luis david gomez jimenez

   IPVCE "Jose Marcelino Maceo Grajales"
          12mo

****************************************/
#include <bits/stdc++.h>

using namespace std;

const int MAXN = 30002;

char S[MAXN][202];
int tmp, Sol;
int n, m, k;

int main()
{
    freopen ( "CUENTAS.in", "r", stdin );
    freopen ( "CUENTAS.out", "w", stdout );

    scanf ( "%d%d%d", &n, &m, &k );

    for ( int i = 1; i <= n; i ++ )
        scanf ( "%s", &S[i]);

   for ( int k = 2; k <= n; k ++ ){
    for ( int i = 1; i < k; i ++ ){
      for ( int j = 0; j < m; j ++ ){

           if ( S[k][j] != S[i][j] ){
                tmp ++;
           }
       }

       if ( tmp == 1 )
           Sol ++;

       tmp = 0;
     }
   }

    printf ( "%d", Sol );
    return 0;
}
