/***************************************
   luis david gomez jimenez

   IPVCE "Jose Marcelino Maceo Grajales"
          12mo

****************************************/

#include <bits/stdc++.h>

using namespace std;

int mat[10002][10002];
long long n, val, m, x, y;
int Sol;

long long zumat( long long x ){
   return (x*(x + 1))/ 2;
}

void simulate (){

    int idx = 1, idy = 1, in = (int)n, c = (int)val;

        while ( c <= m+val ){

            for ( int j = 1; j <= in; j ++ ){
                mat[idx][idy] = c++;
                if ( j != in )
                   idy ++;
            }

            for ( int j = 1; j < in; j ++ ){

                 mat[idx][idy] = ++c;
                 idx ++;
                 idy ++;
            }

            for ( int j = 1; j < in ; j ++ ){

                 mat[idx][idy] = ++c;
                 idx ++;
                 idy --;
            }

            for ( int j = 1; j < in; j ++ ){

                 mat[idx][idy] = ++c;
                 idy --;
            }

            for ( int j = 1; j < in ; j ++ ){


                 mat[idx][idy] = ++ c;
                 idy --;
                 idx --;
            }

            for ( int j = 1; j < in ; j ++ ){

                 mat[idx][idy] = ++ c;
                 idy ++;
            }
            in --;
        }
        if ( mat[x][y] )
          printf ( "%d\n", mat[x][y] );
         else printf ( "0\n" );
        printf ( "%d %d", idx, idy );

}

int main()
{
    freopen ( "HEXAGONO.in", "r", stdin );
    freopen ( "HEXAGONO.out", "w", stdout );

    scanf ( "%lld%lld%lld%lld%lld", &n, &m, &val, &x, &y );

    if ( m < 10002 ){
        simulate();

    }else {

       /*long long fil = busfil(m);

       long long col = buscol(m);

       printf ( "%lld", buscar(x,y) );
       printf ( "%lld", fil, col );*/
    }
    return 0;
}
