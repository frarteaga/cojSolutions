//Liber Estevan Granado
//10mo
//IPVCE Jos� Marcelino Maceo Grajales
#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <string>
#include <cstring>

using namespace std;
string C;
int N ,L ,S ,i, cont;
int main() {

    freopen ("CUENTAS.IN","r",stdin);
    freopen ("CUENTAS.OUT","w",stdout);

    scanf(" %d %d %d ",&N,&L,&S);

    for ( i = 1 ; i <= N ; i++ ){
scanf ( "%d", &C );
    if (C.substr(0 ,L + L ) == C.substr(0 ,L))
            cont ++;
        }

        printf ("%d ", cont );

    return 0;
}
