/** Emanuel Cateura Fern�ndez
IPVCE Jose Maceo Grajales  11no Guant�namo */
#include <bits/stdc++.h>

using namespace std;
int N,L,S,cont;
string cad;
int main() {

    freopen ("CUENTAS.IN","r",stdin);
    freopen ("CUENTAS.OUT","w",stdout);

    scanf("%d%d%d",&N,&L,&S);
    for (int i = 1; i <= N; i ++){
        cin>> cad;
        if (cad.substr(0,L) == cad.substr(0,L+L)) cont ++;
        }

        printf("%d",cont);
    return 0;
}
