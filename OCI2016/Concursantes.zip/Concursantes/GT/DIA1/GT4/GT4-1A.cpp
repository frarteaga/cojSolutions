/** Emanuel Cateura Fern�ndez
IPVCE Jose Maceo Grajales  11no Guant�namo */
#include <bits/stdc++.h>

using namespace std;
long long N,M,S,P,Q;
int main() {

    freopen ("HEXAGONO.IN","r",stdin);
    freopen ("HEXAGONO.OUT","w",stdout);

    cin>> N >> M >> S >> P >> Q;
   /* for (int i = N; i <= N*N; i ++)
    for (int j = 1; j <= M*M; j ++){
        if (j == 1) return true;
        else return false;
    }*/
    long long sol = M + P;
    long long xi = P * 2;
    long long yi = S - P;
    if (P == 1 && Q == 1) sol = S;
    cout<< sol <<endl << xi << " "<< yi;


    return 0;
}
