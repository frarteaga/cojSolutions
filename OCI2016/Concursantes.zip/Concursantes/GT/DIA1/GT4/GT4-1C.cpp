/** Emanuel Cateura Fern�ndez
IPVCE Jose Maceo Grajales  11no Guant�namo */
#include <bits/stdc++.h>

using namespace std;

int mox[]={1,0};
int moy[]={0,-1};
int N,M,K;
char sol[1001];
char mat[201][201];
int mk[1001][1001];

void dfs(int x, int y){
     if (x > N && y > M){
        return;
     }
     for (int i = 0; i < K; i ++){
        int mx = x + mox[i];
        int my = y + moy[i];
        if (mat[mx][my] == '#' || mk[mx][my] == 1) continue;
        if (mox[i] == '#') continue;
        else if (mox[i] == 1){
            sol[i] += 'R';
        }
        else if (mox[i] == 0) sol[i] += 'D';
        else sol[i] += 'R';
     }

}

int main() {

    freopen ("ROBOT.IN","r",stdin);
    freopen ("ROBOT.OUT","w",stdout);

    scanf("%d%d%d",&N,&M,&K);
    for (int i = 1; i <= N; i ++)
        for (int j = 1; j <= M; j ++){
            cin>> mat[i][j];
    }
    dfs(0,0);
    cout<< sol;

    return 0;
}
