/**
Alexis Jos� Lobaina D�az
11no grado
GT5
IPVCE:Jos� Marcelino Maceo Grajales
*/

#include <bits/stdc++.h>

using namespace std;
char A[200][200];
int N,M,K;
int movx,movy;
char cont[200];
int mk[200][200];
int mox[2]={0,1};
int moy[2]={1,0};

void premio(int f,int g){

for(int i=0;i<K;i++){
    movx=f+mox[i];
    movy=g+moy[i];

  if(A[movx][movy]=='#'||mk[movx][movy]==1)continue;
   mk[movx][movy]=1;
           if(mox[i]==0){
            cont[i]='R';
           }
           else if (mox[i]==1){
            cont[i]='D';
           }
}
}

int main()
{
  freopen("ROBOT.in","r",stdin);
  freopen("ROBOT.out","w",stdout);

    scanf("%d%d%d",&N,&M,&K);


    for(int i=1;i<=N;i++){
        for(int j=1;j<=M;j++){
            scanf("%c",&A[i][j]);

        }
    }
    premio(1,1);

for(int i=0;i<K;i++){
    printf("%c",cont[i]);
}
    return 0;

}
