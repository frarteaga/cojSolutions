/**
Alexis Jos� Lobaina D�az
Guant�namo
11no grado
GT5
IPVCE:Jos� Marcelino Maceo Grajales
*/

#include <bits/stdc++.h>

using namespace std;

int N,M,S,cont,sol;
string A[30000];
int Ar[5000][5000];



int main()
{
    freopen("CUENTAS.in","r",stdin);
    freopen("CUENTAS.out","w",stdout);

    scanf("%d%d%d",&N,&M,&S);

    for(int i=1;i<=N;i++){
        cin>>A[i];
    }
    for(int i=1;i<=M;i++){
        for (int j=1;j<=M;j++){
         if(A[i][i] == A[i][j] ){
            cont++;
        }
        }
            }


   printf("%d",cont);


    return 0;
}
