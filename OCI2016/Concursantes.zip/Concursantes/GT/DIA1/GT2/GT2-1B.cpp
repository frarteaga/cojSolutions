#include <bits/stdc++.h>

using namespace std;
long long N,A,L,Sol;
string cad[1011000];
    bool comp (int x , int y){

    int cont = 0;
    for(int i = 0 ;i< L ;i++){

        if(cad[x][i] != cad[y][i] && !cont )cont = true;
        else if(cad[x][i] != cad[y][i] && cont)return false;
    }

        return (cont) ? true : false;

    }

int main()
{
    freopen ("CUENTAS.IN" , "r" , stdin);
    freopen ("CUENTAS.OUT" , "w" , stdout);
    scanf("%lld%lld%lld" ,&N ,&L ,&A);

    for(int i=1 ;i<= N;i++){
        cin >> cad[i];
    }
    for(int i=1 ;i<= N ;i++){
        for(int j=i+1 ;j<= N ;j++){
            if(comp(i , j))Sol++;

        }
    }
    printf("%lld" , Sol);
    return 0;
}
