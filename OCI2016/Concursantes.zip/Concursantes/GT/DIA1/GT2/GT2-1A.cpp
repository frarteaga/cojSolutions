#include <bits/stdc++.h>

using namespace std;
typedef pair<int ,int>par;
long long N  , M ,E ,F ,C;
long long BUSKF(long long  x , long long num){
    if(x == 1LL )return 1;
    if(num % (6*(x-1LL)) != num ){
        long long g =num % (6*(x-1)) ;
        long long k =1 + BUSKF(x-1 , g );
        return k;
    }

    int mn  =num % 6LL *(x-1LL) ;
    if(mn >= 1 && mn < x){
        return 1;
    }
    else if(mn >= x && mn < (2LL*x -1)){

        return ((mn - x) +1 );

    }
    else if(mn >= 2LL*x-1 && mn < 3*x -2 ){
        long long t =(x + (mn - (2*x-1) ));
        return t;
    }
    else if( mn >= 3*x - 2 && mn < 4*x -3  ){
        return (2*x -1);
    }
    else if( mn >= 4*x -3  && mn < 5*x - 4){
        return (x + (5*x-4) - mn);
    }
    else return (x - (mn - 5*x - 4));


}
long long BUSKC(long long  x , long long  num){
    if(x == 1 )return 1LL;
    if(num % (6 * (x-1)) == 0 )return 1;
    if(num % (6 * (x-1)) != num )
        return (1 + BUSKC(x-1 , num % (6*(x-1))  ));

    long long  mn  =num % 6*(x-1) ;
    if(mn >= 1 && mn < x){
        return mn;
    }
    else if(mn >= x && mn < (2*x -1)){

        return mn;

    }
    else if(mn >= 2*x-1 && mn < 3*x -2 ){
        return (4*x-2)-mn;
    }
    else if( mn >= 3*x - 2 && mn < 4*x -3  ){
        return ((4*x-3) - mn +1);
    }
    else if( mn >= 4*x -3  && mn < 5*x - 4){
        return 1;
    }
    else return 1;


}

int main()
{   freopen("HEXAGONO.IN"  , "r" , stdin);
    freopen("HEXAGONO.OUT" , "w" , stdout);

    scanf("%lld%lld%lld%lld%lld", &N , &M , &E , &F , &C);

    int l=BUSKF(N,M);
    printf("%lld" ,l);
    printf(" %lld" ,BUSKC(N,M));

    return 0;
}
