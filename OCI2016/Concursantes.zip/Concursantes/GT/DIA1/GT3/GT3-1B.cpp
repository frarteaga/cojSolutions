//David Benitez Rangel
//12 grado
// IPVCE Jose Marcelino Maceo Grajales

#include <bits/stdc++.h>

 int CantC, LargC ,CodC,cont,sol;
 int inNt, inR, finT,finR,resTi,resRi,resTf,resRf;
using namespace std;
string c[30000] ;
 int N[30000],ArT[30000],ArR[30000];

int main()
{  freopen("CUENTAS.IN","r",stdin);
   freopen("CUENTAS.OUT","w",stdout);

       scanf("%d%d%d",&CantC,&LargC,&CodC);
        if(CodC == 2){
   for( int i = 1; i<=CantC; i ++) {
     scanf("%d",&N[i]);

   }
     for (int i= 1 ; i < CantC;i++){
       for( int j = CantC; j>i; j--){
            int  x= pow(10,LargC), y = x/10 ;
        finT=N[i]%10;
        finR=N[j]%10;
        resTi =N[i] /10;
        resRi =N[j] /10 ;
        inNt  =N[i] / y;
        inR   =N[j] / y;
        resTf =N[i] % y;
        resRf =N[j] % y;
        sol ++;
      if(finT != finR && resTi == resRi) cont ++;
     else if(inNt!=inR && resTf == resRf) cont ++;




       }
 }
   printf("%d",cont);
   }



    return 0;
}
