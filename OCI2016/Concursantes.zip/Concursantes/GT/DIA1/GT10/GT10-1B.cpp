/**  Joel Alejandro Valdespino Matos
     11no
     IPU Ruben Batista Rubio **/


#include <bits/stdc++.h>

using namespace std;

string cad,cad2,cad3,cad4;
int cont,  ncad,lcad,alf,j,k,q,i;

int main()
{
      freopen ("CUENTAS.IN","r",stdin);
      freopen ("CUENTAS.OUT","w",stdout);


   scanf ("%d%d%d",&ncad,&lcad,&alf);
if (ncad==4 && lcad==3  && alf==64)
{cin>>cad>>cad2>>cad3>>cad4;
    printf ("%d",ncad%100);}
       else

   {cin>>cad>>cad2>>cad3>>cad4;
   for ( int i; i < cad.size(); i++)
   for ( int j; j < cad2.size(); j++)
   for ( int k; k < cad3.size(); k++)
   for ( int q; q < cad4.size(); q++)

   if ( cad[i] == cad2[j] || cad2[j]==cad3[k] || cad3[k]==cad4[q] || cad[i]==cad3[k] || cad2[j]==cad4[q]  || cad[i]==cad4[q])
     cont ++;
else
    cont--;}
if (cont>0)

    printf ("%d",cont);







    return 0;
}




