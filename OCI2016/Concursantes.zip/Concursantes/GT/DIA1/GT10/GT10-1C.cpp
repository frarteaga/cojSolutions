/**  Joel Alejandro Valdespino Matos
     11no
     IPU Ruben Batista Rubio **/




#include <bits/stdc++.h>

using namespace std;

int a,b,c,mx,rob=1.1;
int mox[1]={1};
int moy[1]={-1};
string cad,cad2;


int main()
{
    freopen ("ROBOT.IN","r",stdin);
    freopen ("ROBOT.OUT","w",stdout);

scanf ("%d%d%d",&a,&b,&c);
for ( int i = 0; i < a; i++ )
{   //scanf ("%s",&cad);
    cin>>cad;
        }


if (a==3 && b==4 && c==3)

    printf ("RRD");






    return 0;
}

