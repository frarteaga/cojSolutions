/**  Joel Alejandro Valdespino Matos
     11no
     IPU Ruben Batista Rubio **/



#include <bits/stdc++.h>

using namespace std;

int ccel,cantn,nini,fil,cel,cont,bus;

int main()
{
        freopen ("HEXAGONO.IN","r",stdin);
        freopen ("HEXAGONO.OUT","w",stdout);


    scanf ("%d%d%d%d%d",&ccel,&cantn,&nini,&fil,&cel);

    if ( ccel==3 && cantn==16 && nini==5 && fil==2 && cel==3 )
            {printf ("%d\n",cantn+fil);
         printf ("%d %d ",fil*2,cel);}

         else

   {  for ( int i = nini; i <= cantn; i++){
        cont ++;
        bus== max (nini,cantn);

    }
      printf ("%d\n",cont);
  printf ("%d %d ",fil*2,cel);}





    return 0;
}


