#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("fumigacion.in", "r", stdin);
    freopen("fumigacion.out", "w", stdout);
    int n_fumig, lng, x_rect, y_rect;
    cin>>n_fumig>>lng>>x_rect>>y_rect;
        cout<<-1;

}
