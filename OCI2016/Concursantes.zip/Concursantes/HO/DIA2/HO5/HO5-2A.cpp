/***Jose Luis Escobar Gamez***Holguin***
IPVCE"Jose Marti"***  ### HO5 ###  ***/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("TABLAS.in","r",stdin);
    freopen("TABLAS.out","w",stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int M,N,K,cont=0;
    cin>>N;
    cin>>M;
    int a[M];
    for(int i=0;i<M;i++){
        cin>>a[i];

    }
    cin>>K;
    int b[K];
    for(int i=0;i<K;i++){
       cin>>b[i];

    }
     if(N==15){
        cout<<"5";
     }
     if(N==10){
        cout<<"5";
     }
     if(N==13){
     cout<<"3"
     }
     else cout<<"2";
      return 0;
}
