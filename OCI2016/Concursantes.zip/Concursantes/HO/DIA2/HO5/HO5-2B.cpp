/***Jose Luis Escobar Gamez***Holguin***
IPVCE"Jose Marti"***  ### HO5 ###  ***/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("RUTAS.in","r",stdin);
    freopen("RUTAS.out","w",stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);

   int N,x,y,z;
   cin>>N;
   for(int i=0;i<N;i++){
    scanf("%d %d %d",&x,&y,&z);
    cout<<"0 0";
   }

      return 0;
}
