/***Jose Luis Escobar Gamez***Holguin***
IPVCE"Jose Marti"***  ### HO5 ###  ***/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("FUMIGACION.in","r",stdin);
    freopen("FUMIGACION.out","w",stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int N,L,W,H;
    scanf("%d %d %d %d",&N,&L,&W,&H);
    int x[N],y[N];
    for(int i=0;i<N;i++){
       cin>>x[i]>>y[i];

    }
    cout<<"-1";
      return 0;
}
