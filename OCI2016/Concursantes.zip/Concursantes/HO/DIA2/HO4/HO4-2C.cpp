/**BRUNO JAVIER GONZALEZ MOLINA**HO4**IPVCE:JOSE MARTI**/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("FUMIGACION.in","r",stdin);
    freopen("FUMIGACION.out","w",stdout);
    /*int n,l,w,h,x,y,i;
    cin>>n>>l>>w>>h;
    bool bosq[l][l];
    for(int a=0;a<l;a++)
        for(int b=0;b<l;b++)
            bosq[a][a]=false;
    for(i=1;i<=n+1;i++){
        cin>>x>>y;
        bosq[x][y]=true;
        for(int j=0;j<l;j++){
            for(int k=0;k<l;k++){
                if(bosq[j][k]==true){
                    cout<<"dafsg";
                }
                else continue;
            }
        }
    }*/
    cout<<"-1";
    return 0;
}
