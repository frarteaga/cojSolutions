/**BRUNO JAVIER GONZALEZ MOLINA**HO4**IPVCE:JOSE MARTI**/

#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("TABLAS.in","r",stdin);
    freopen("TABLAS.out","w",stdout);
    cout<<"5";
    return 0;
}
