/**BRUNO JAVIER GONZALEZ MOLINA**HO4**IPVCE:JOSE MARTI**/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("RUTAS.in","r",stdin);
    freopen("RUTAS.out","w",stdout);
    int cant_ciud,c1=0,c2=0,lo=0;
    cin>>cant_ciud;
    int aux1[cant_ciud-1],aux2[cant_ciud-1],aux3[cant_ciud-1];
    int tabla[cant_ciud][cant_ciud];

    for(int i=1;i<=cant_ciud;i++){
        for(int j=1;j<=cant_ciud;j++){
            tabla[i][j]=0;
        }
    }
    for(int i=1;i<cant_ciud;i++){
        cin>>aux1[i]>>aux2[i]>>aux3[i];
        if(aux1[i]>aux2[i]){
            lo=aux1[i];
            aux1[i]=aux2[i];
            aux2[i]=lo;
        }
        tabla[aux1[i]][aux2[i]]=aux3[i];
    }
    for(int h=1;h<=cant_ciud;h++)
        tabla[cant_ciud][h]=0;
    for(int j=1;j<cant_ciud;j++){
        tabla[aux1[j]][aux2[j]]=0;
        for(int i=1;i<=cant_ciud;i++){
            c1+=tabla[aux1[j]][i];
            c2+=tabla[aux2[j]][i];
        }
        if(c1>c2){
            lo=c1;
            c1=c2;
            c2=lo;
        }
        if(j!=cant_ciud-1){
        cout<<c1<<" "<<c2<<endl;
        c1=0;
        c2=0;
        }
        else{
            cout<<"0 0";
        }
    }
    return 0;
}
