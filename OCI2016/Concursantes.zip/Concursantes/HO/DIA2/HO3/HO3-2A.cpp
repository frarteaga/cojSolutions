/* **************************
Hugo Alberto Valencia Zayas
dia 2 problema A
provincia HOLGUIN
************************** */
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("tablas.in","r",stdin);
    freopen("tablas.out","w",stdout);

    int cant_columnas;
    cin>>cant_columnas;

    int fuck[100];

     for(int i=0 ;i<cant_columnas;i++)
     {
         cin>>fuck[i];
     }

     int auxiliar=0;
     int aux=0;

     for(int i=0;i<cant_columnas;i++)
     {
         auxiliar = (cant_columnas*2)+1;
         aux = auxiliar/cant_columnas;
     }
    cout << aux << endl;

    return 0;
}
