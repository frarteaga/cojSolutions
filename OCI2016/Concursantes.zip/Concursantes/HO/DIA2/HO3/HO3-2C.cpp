/* **************************
Hugo Alberto Valencia Zayas
dia 2 problema C
provincia HOLGUIN
************************** */
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("fumigacion.in","r",stdin);
    freopen("fumigacion.out","w",stdout);

    int cant_arbol;
    int longit;
    int eje_x;
    int eje_y;

    cin>>cant_arbol>>longit>>eje_x>>eje_y;

    int arbol_pos[cant_arbol][cant_arbol];

    for(int i=0; i<cant_arbol ; i++)
    {
        for(int j=0; j<cant_arbol;j++)
        {
          cin>>arbol_pos[i][j];
        }

    }

    int auxiliar=0;
    int auxiliar1=0;

    for(int i=0; i<cant_arbol;i++)
    {
        auxiliar = cant_arbol + eje_y;
        auxiliar1 = auxiliar - eje_x;

        if(auxiliar1 <= cant_arbol)
        {
            cout<<auxiliar1<<"\n";
        }
        else
        {
             cout << "-1" << "\n";
        }
    }

    return 0;
}
