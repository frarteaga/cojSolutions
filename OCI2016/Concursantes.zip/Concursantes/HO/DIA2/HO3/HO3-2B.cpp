/* **************************
Hugo Alberto Valencia Zayas
dia 2 problema B
provincia HOLGUIN
************************** */
#include <bits/stdc++.h>
using namespace std;

struct rutas
{
    int inicio;
    int fin;
    int distancia;
};

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("rutas.in","r",stdin);
    freopen("rutas.out","w",stdout);

    int cant_city;
    cin>>cant_city;

    rutas relation[cant_city-1];

    for(int i=1 ; i <= cant_city-1 ; i++)
    {
        cin>> relation[i].inicio >> relation[i].fin >> relation[i].distancia;
    }

    for(int i=1 ; i <= cant_city-1 ; i++)
    {
        if(relation[i].distancia!=0)
        {
          cout << relation[i].distancia+1 <<"  "<< relation[i].distancia+relation[i].distancia -1<< "\n";
        }
        else
        {
            cout << "0" << "\n";
        }
    }

    cout << "\n";
    return 0;
}
