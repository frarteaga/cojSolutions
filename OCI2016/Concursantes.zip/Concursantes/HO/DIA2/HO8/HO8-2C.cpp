//Manuel Alejandro Miranda Alonso
//Provincia Holguin
//IPVCE Jose Marti Perez

#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    //freopen("tablas.in","r",stdin);
    //freopen("tablas.out","w",stdout);

    int n,m,k;
    cin>>n>>m>>k;
    int tab1[n];
    int tab2[n];
    int a[m],b[k];

    for(int i=0;i<m;i++)
        cin>>a[i];
    for(int i=0;i<k;i++)
        cin>>b[i];

    /*int lista[(n*2)+1];
    for(int i=1;i<=n*2;i++)
        lista[i]=-5;

    for(int i=1;i<=n*2;i++)
        {
            for(int j=0;j<m;j++)
            {
                if(a[j]==i)
                    lista[i]=0;
            }
            for(int j=0;j<k;j++)
            {
                if(b[j]==i)
                    lista[i]==1;
            }
        }

    for(int i=1;i<=n*2;i++)
    {
        if((lista[i]!=0)&&(lista[i]!=1))
            lista[i]=2;
    }

    for(int i=0;i<n;i++)
    {
        tab1[i]=0;
        tab2[i]=0;
    }

    for(int i=0;i<m;i++)
    {
        for(int j=0;i<m;j++)
        {
            if(a[j]>a[j+1])
            {
                int aux=a[j];
                a[j]=a[j+1];
                a[j+1]=aux;
            }
        }
    }
    for(int i=0;i<k;i++)
    {
        for(int j=0;j<k;j++)
        {
            if(b[j]>b[j+1])
            {
                int aux=b[j];
                b[j]=b[j+1];
                b[j+1]=aux;
            }
        }
    }

    int cena=n-m,cenb=n-k,canc=0;
    for(int i=0;i<m;i++)
        tab1[i]=a[i+1];
    for(int i=0;i<k;i++)
        tab2[i]=b[i+1];*/

    cout<<2;

}
