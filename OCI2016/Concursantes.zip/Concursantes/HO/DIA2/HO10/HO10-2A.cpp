#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("Tablas.in","r",stdin);
    freopen("Tablas.out","w",stdout);
  int N,A,B,C;
 cin>>N;

  cin>>A;

 cin>>B;

  cin>>C;

 cout<< 2 <<ends;


   for(int i=N;i<=35;i++)



    return 0;
}
