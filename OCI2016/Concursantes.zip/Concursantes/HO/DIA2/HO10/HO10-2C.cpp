/*Suvarin Cruz Guerrero
IPVCE "Jose Marti Perez"  Holguin*/
#include <bits/stdc++.h>
using namespace std;

int main()
{     freopen("Fumigacion.in","r",stdin);
      freopen("Fumigacion.out","w",stdout);
 int N,L,W,H;
   cin>>N;
  cin>>L;
  cin>>W;
   cin>>H;
 cout<<-1<<endl;
   for(int i=N;i<=L;i++)
{     int arr[i];
     arr[i]=i;
    cin>>arr[i];
}
  for(int j=W;j<H;j++)
   {int arr[j];
   arr[j]=j;

}

 return 0;
}
