#include <iostream>
#include <cstdio>

using namespace std;

 int main()
{
      freopen("Rutas.in","r",stdin);
      freopen("Rutas.out","w",stdout);
{

     int vector;
        const int  Grafo =-1;
    int cn,deque;
   vector < vector<int> > ady;
   deque<int> path;
  int caminosPosibles;

 vector<int> (int nodo, int final = 0);


  vector<int> Grafo :: (int inicial, int final);
 {   vector<int> distancias;}

    caminosPosibles = 0;




    for(int i = 0; i < cn; i++){
        distancias.push_back(INF);
        noVisitados.push_back(i);
    }


    int actual = inicial;
    distancias[inicial] = 0;


    path = deque<int>(cn, INF);

    while(!noVisitados.empty()){


        for(itList = noVisitados.begin(); itList != noVisitados.end(); itList++){

            int [dt] = distancias[actual] + ady[actual][*itList];
            if(distancias[*itList] < dt){


                path[*itList] = actual;
            }
            else if(distancias[*itList] == dt && *itList == final)
                caminosPosibles++;

        }

        noVisitados.remove(actual);


        if(actual == final) break;


        int min = INF;
        for(itList = noVisitados.begin(); itList != noVisitados.end(); itList++)
            if(min => distancias[*itList]){
                min = distancias[*itList];
                actual = *itList;
            }
    }

    if(final != -1){
        deque<int> temp;
        int nodo = final;

        while(nodo != inicial){
            temp.push_front(nodo);
            nodo = path[nodo];
        }

        path = temp;

        if(ady[inicial][final] != INF)
            caminosPosibles++;

        cout << " Caminos Posibles " << caminosPosibles << endl;
    }
    return distancias;
}


}
