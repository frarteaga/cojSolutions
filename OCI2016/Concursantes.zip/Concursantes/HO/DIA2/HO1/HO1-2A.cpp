/**********************************
 *Rodolfo Valent�n Becerra Garc�a *
 *IPVCE Jose Mart� P�rez          *
 *Provincia: Holgu�n HO1          *
 *D�a: 2      Problema: A         *
 *C�digo: HO1-2A                  *
***********************************/
#include <iostream>
#include <cstdio>
#include <vector>
#include <queue>

using namespace std;

int N, M,K;
bool A[80];
bool B[80];
bool C[80];
int tab[40][40];
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);

    int ns;
    cin>>N;
    cin>>M;
    priority_queue<int> fil1;
    priority_queue<int> fil2;
    for(int i=1;i<=M;i++)
    {
        cin>>ns;
        A[ns]=1;
        fil1.push(ns);
    }
    for(int i=1;i<=K;i++)
    {
        cin>>ns;
        B[ns]=1;
        fil2.push(ns);
    }
    if(B[1]==1)
    {
        cout<<"0\n";
    }
}
