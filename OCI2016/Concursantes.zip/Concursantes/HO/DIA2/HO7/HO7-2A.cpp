/*Jose Carlos Sanchez Fernandez. Holguin
IPVCE Jose Marti Perez*/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("TBLAS.in","r",stdin);
    freopen("TBLAS.out","w",stdout);
    int n,m,k,j=1;
    cin>>n;
    int fila[10];
    int filb[10];
    int c[10];
    cin >>m;
    for (int i=0;i<m;i++)
        cin>>fila[i];
        cin >>k;
    for (int i=0;i<k;i++)
        cin>>filb[i];

    cout<<(fila[0]+filb[k])/5;
}
