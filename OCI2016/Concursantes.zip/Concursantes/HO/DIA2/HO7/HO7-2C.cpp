/*Jose Carlos Sanchez Fernandez. Holguin
IPVCE Jose Marti Perez*/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("FUMIGACION.in","r",stdin);
    freopen("FUMIGACION.out","w",stdout);
    int j , p , q , r;
    int arr[9000];
    cin>>j;
     cin>>p;
      cin>>q;
       cin>>r;
    for(int f=0;f<j*2;f++)
        cin>>arr[f];
        cout <<"-1";
}
