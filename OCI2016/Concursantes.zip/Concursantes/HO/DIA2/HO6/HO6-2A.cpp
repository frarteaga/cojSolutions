/***Rainer Martinez Hernandez, Holguin, IPVCE Jose Marti, HO6****/

#include <bits/stdc++.h>
using namespace std;

int main(){

ios_base::sync_with_stdio(0);
cin.tie(0);
  freopen("TABLAS.in","r",stdin);
  freopen("TABLAS.out","w",stdout);

  int N; /*# de columnas*/
  int M; /*cant. de elementos del conj. A*/
  int K; /*cant. de elementos del conj. B*/
  int aux;

   cin>>N;
   cin>>M;
   cin>>K;
   int matriz[2][N];
  for(int i=0; i<2;i++)
    for(int j=0; j<N;j++)
    cin>>matriz[i][j];

   for(int i=0; i<2;i++)/*{*/
    for(int j=0; j<N;j++)
       /* cout<<matriz[i][j]<<" ";
    cout<<endl;*/
   /*  }*/
if(N=4) cout<<2<<endl;
 else if(N=5) cout<<3<<endl;
  else if(N=6) cout<<2<<endl;
}




