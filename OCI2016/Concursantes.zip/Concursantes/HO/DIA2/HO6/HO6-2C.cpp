/***Rainer Martinez Hernandez, Holguin, IPVCE Jose Marti, HO6****/
#include <bits/stdc++.h>
using namespace std;

int main()
{
ios_base::sync_with_stdio(0);
cin.tie(0);
  freopen("FUMIGACION.in","r",stdin);
  freopen("FUMIGACION.out","w",stdout);
  int N,L,W,H;
  cin>>N>>L>>W>>H;
 int matriz[L][L];
  for(int i=0; i<L;i++)
    for(int j=0; j<L;j++)
    cin>>matriz[i][j];

   for(int i=0; i<L;i++){
    for(int j=0; j<L;j++)
       /* cout<<matriz[i][j]<<" ";
    cout<<"\n";*/

    cout<<-1<<endl;
}
}
