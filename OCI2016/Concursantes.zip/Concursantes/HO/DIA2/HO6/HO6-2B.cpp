/***Rainer Martinez Hernandez, Holguin, IPVCE Jose Marti, HO6****/
#include <bits/stdc++.h>
using namespace std;

int main()
{
ios_base::sync_with_stdio(0);
cin.tie(0);
  /*freopen("RUTAS.in","r",stdin);
  freopen("RUTAS.out","w",stdout);*/
   int N;
   cin>>N;
    cout<<"0 0"<< endl;
    cout<<"0 0"<< endl;
    cout<<"0 0"<< endl;
    cout<<"0 0"<< endl;


}
