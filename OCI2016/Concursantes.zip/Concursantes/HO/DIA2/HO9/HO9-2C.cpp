/****************************
*JOSE ALEJANDRO PUPO GONGORA*
*PROVINCIA HLOGUIN          *
*IPVC JOSE MARTI PEREZ      *
*****************************/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("fumigacion.in","r",stdin);
    freopen("fumigacion.out","w",stdout);
    int n,l,w,h;

   cin>>n>>l>>w>>h;
int k=n*2;
   int arr[k];
for(int i=0;i<k;i++)
{
  cin>>arr[i];
}
    cout<<-1;



}
