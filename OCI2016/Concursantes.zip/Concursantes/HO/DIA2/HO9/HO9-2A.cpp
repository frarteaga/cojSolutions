/****************************
*JOSE ALEJANDRO PUPO GONGORA*
*PROVINCIA HLOGUIN          *
*IPVC JOSE MARTI PEREZ      *
*****************************/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("tablas.in","r",stdin);
    freopen("tablas.out","w",stdout);

  int n,m,a,k,b;

  cin>>n>>m>>k;
  int arr[m];
  int ar[k];
  int matris[n][2];

 for(int i=0;i<m;i++)
    cin>>arr[i];
 for(int i=0;i<k;i++)
    cin>>arr[i];
  int con;
 for(int i=0;i<m-1;i++)
 {
     for(int j=0;j<m-1;j++)
     {
         int aux;
         aux=arr[j];
         if(arr[j]>arr[j-1])
         {
             arr[j]=arr[j-1];
             arr[j-1]=aux;
         }
     }
 }
    cout<<n/2;

}
