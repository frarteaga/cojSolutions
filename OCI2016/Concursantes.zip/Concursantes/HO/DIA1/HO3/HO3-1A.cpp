#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("hexagono.in","r",stdin);
    freopen("hexagono.out","w",stdout);

   int a ,b ,c,d,e;

   cin>>a>>b>>c>>d>>e;

   cout<<"0"<<"\n";

    return 0;
}
