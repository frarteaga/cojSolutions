// Hugo Alberto Valencia Zayas
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("cuentas.in","r",stdin);
    freopen("cuentas.out","w",stdout);

    int numero_cuenta,cant_charater,tam_alfab;
    int contador=1;

    cin>>numero_cuenta>>cant_charater>>tam_alfab;

    char cadena[tam_alfab][cant_charater];

    for(int i=0;i<cant_charater;i++)
        for(int j=0;j<numero_cuenta;j++)
        {
            cin>>cadena[i][j];
        }
    for(int i=1;i<=cant_charater;i++){
        for(int j=1;j<=numero_cuenta;j++)
        {

          if(cadena[i][j]==cadena[i][j+1]&&cadena[i+1][j+1]==cadena[i+1][j+1])
          {
              contador ++;
          }
          else
          {
              i++;
                j++;
          }

        }
        cout<<contador+cant_charater;
    }

    return 0;
}
