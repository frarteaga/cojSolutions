/**********************************
 *Rodolfo Valent�n Becerra Garc�a *
 *IPVCE Jose Mart� P�rez          *
 *Provincia: Holgu�n HO1          *
 *Ejercicio: 1B                   *
***********************************/
#include <bits/stdc++.h>

using namespace std;

int N,L,S;
string cuenta[30000];
char si;
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);

    cin>>N>>L>>S;
    int contg=0;
    if(S==64)
    {
        for(int i=1;i<=N;i++)
        {
            cin>>cuenta[i];
            if(i>1)
            {
               for(int j=1; j<i;j++)
               {
                   int cont=0;
                   si=1;
                   for(int h=0;h<L;h++)
                   {
                       if(cuenta[i][h]!=cuenta[j][h])
                       {
                          cont++;
                       }
                       if(cont==2)
                       {
                          si=0;
                          break;
                       }
                   }
                   if(si)
                   {
                      contg++;
                   }
                }
             }
         }
    }
    else if(S==2)
    {
        for(int i=1;i<=N;i++)
        {
            cin>>cuenta[i];
            if(i>1)
            {
                for(int j=1;j<i;j++)
                {
                    int cont=0;
                    si=1;
                    for(int h=0;h<L;h++)
                    {
                        if(cuenta[i][h]=='1'&&cuenta[j][h]=='0')
                        {
                            cont++;
                        }
                        else if(cuenta[i][h]=='0'&&cuenta[j][h]=='1')
                        {
                            cont++;
                        }
                        if(cont==2)
                        {
                            si=0;
                            break;
                        }
                    }
                    if(si)
                    {
                        contg++;
                    }
                }
            }
        }
    }
    cout<<contg<<"\n";
}
