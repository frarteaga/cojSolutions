/**********************************
 *Rodolfo Valent�n Becerra Garc�a *
 *IPVCE Jose Mart� P�rez          *
 *Provincia: Holgu�n HO1          *
 *Ejercicio: 1C                   *
***********************************/
#include <bits/stdc++.h>

using namespace std;

int N,M,K;
char n='#';
char pos[200][200];
int h=1,k=1;
int main()
{
    freopen("ROBOT.IN","r",stdin);
    freopen("ROBOT.OUT","w",stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin>>N>>M>>K;
    for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=M;j++)
        {
            cin>>pos[i][j];
        }
    }
    for(int i=1;i<=K;i++)
    {
        if(h==N&&k==M)
        {
            break;
        }
        if(h==N)//abajo
        {
            cout<<"R";
        }
        if(k==M)//derecha
        {
            cout<<"D";
        }
        else
        {
            if(pos[h][k+1]==n && pos[h+1][k]!=n)
            {
                h++;
                cout<<"D";
            }
            else if(pos[h+1][k]==n && pos[h][k+1]!=n)
            {
                k++;
                cout<<"R";
            }
            else if(pos[h+1][k]!=n && pos[h][k+1]!=n)
            {
                if(pos[h+1][k]>pos[h][k+1])
                {
                    h++;
                    cout<<"D";
                }
                else if(pos[h+1][k]<pos[h][k+1])
                {
                    k++;
                    cout<<"R";
                }
                else if(pos[h+1][k]==pos[h][k+1])
                {
                    if(pos[h][k+2]>pos[h+2][k])
                    {
                        cout<<"R";
                    }
                    else if(pos[h][k+2]<pos[h+2][k])
                    {
                        cout<<"D";
                    }
                }
            }
        }
    }
    cout<<"\n";
}
