/**********************************
 *Rodolfo Valent�n Becerra Garc�a *
 *IPVCE Jose Mart� P�rez          *
 *Provincia: Holgu�n HO1          *
 *Ejercicio: 1A                   *
***********************************/
#include <bits/stdc++.h>

using namespace std;

long long N,M,S,P,Q;
char dir;
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("HEXAGONO.IN","r",stdin);
    freopen("HEXAGONO.OUT","w",stdout);

    cin>>N>>M>>S>>P>>Q;
    long long mat=(N*2)-1;
    cout<<0<<"\n"<<(mat/2)+1<<" "<<(mat/2)+1<<"\n";
}
