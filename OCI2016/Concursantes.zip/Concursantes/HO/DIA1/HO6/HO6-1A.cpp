/***Rainer Martinez Hernandez, Holguin, IPVCE Jose Marti, HO6****/

#include <bits/stdc++.h>
using namespace std;

int main(){

ios_base::sync_with_stdio(0);
cin.tie(0);
  freopen("HEXAGONO.in","r",stdin);
  freopen("HEXAGONO.out","w",stdout);
    int N,M,S,P,Q,aux;
      cin>>N>>M>>S>>P>>Q;
       aux=M*Q;
         cout<<aux<< endl;
           cout<<Q<<P;


   return 0;
}
