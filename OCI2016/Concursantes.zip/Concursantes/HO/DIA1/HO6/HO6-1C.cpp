/***Rainer Martinez Hernandez, Holguin, IPVCE Jose Marti, HO6***/

#include <bits/stdc++.h>
using namespace std;

 int main(){

ios_base::sync_with_stdio(0);
cin.tie(0);
  freopen("Robot.in","r",stdin);
  freopen("Robot.out","w",stdout);
    int N,M,K;
    cin>>N,M,K;
      if(K=3) cout<<"RDR";
       else if(K=4) cout<<"RDDR";
         else if(K=1) cout<<"D";

  }
