/*Suvarin Cruz Guerrero Dia 1-A
IPVCE "Jose Marti Perez"   Holguin*/

#include <bits/stdc++.h>

using namespace std;

int main()
{
  freopen("Hexagono.in","r",stdin);
  freopen("Hexagono.out","w",stdout);

 int N,M,S,P,Q;
    cin>>N;
    cin>>M;
    cin>>S;
    cin>>P;
    cin>>Q;


   for(int i=S;i<=M;i++)
{
   int arr[i];
    arr[i]=i;

}
   for(int j=N;j<=P;j++)
  {
     int arr[j];
       arr[j]=j;

}

  {

   cout<<"18"<<endl;
   cout<<"4"<<ends;
   cout<<"3"<<ends;
   }
return 0;
}
