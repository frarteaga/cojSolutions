/***Jose Luis Escobar Gamez***Holguin***
IPVCE"Jose Marti"*** ### HO5 ###    ***/
#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("HEXAGONO.in","r",stdin);
    freopen("HEXAGONO.out","w",stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);

   int N,M,S,P,Q;
   scanf("%d %d %d %d %d",&N,&M,&S,&P,&Q);
   int t=S;
       if(N==3 && P==1 && Q==1 ){
        cout<<S<<endl;
       }
       if(N==3 && P==1 && Q==2 ){
        cout<<S+1<<endl;
       }
       if(N==3 && P==1 && Q==3 ){
        cout<<S+2<<endl;
       }
       if(N==3 && P==2 && Q==4 ){
        cout<<S+3<<endl;
       }
       if(N==3 && P==3 && Q==5 ){
        cout<<S+4<<endl;
       }
       if(N==3 && P==4 && Q==4 ){
        cout<<S+5<<endl;
       }
       if(N==3 && P==5 && Q==3 ){
        cout<<S+6<<endl;
       }
       if(N==3 && P==5 && Q==2 ){
        cout<<S+7<<endl;
       }
       if(N==3 && P==5 && Q==1 ){
        cout<<S+8<<endl;
       }
       if(N==3 && P==4 && Q==1 ){
        cout<<S+9<<endl;
       }
       if(N==3 && P==3 && Q==1 ){
        cout<<S+10<<endl;
       }
       if(N==3 && P==2 && Q==1 ){
        cout<<S+11<<endl;
       }
       if(N==3 && P==2 && Q==2 ){
        cout<<S+12<<endl;
       }
       if(N==3 && P==2 && Q==3 ){
        cout<<S+13<<endl;
       }
       if(N==3 && P==3 && Q==4 ){
        cout<<S+14<<endl;
       }
       if(N==3 && P==4 && Q==2 ){
        cout<<S+15<<endl;
       }if(N==3 && P==4 && Q==1 ){
        cout<<S+16<<endl;
       }
       if(N==3 && P==3 && Q==2 ){
        cout<<S+17<<endl;
       }
       if(N==3 && P==3 && Q==3 ){
        cout<<S+18<<endl;
       }
       for(int i=1;i<M;i++){
        S++;
       }

       if(S==t){
        cout<<"1 1";
       }
       else if(S==t+1){
        cout<<"1 2 ";
       }
        else if(S==t+2){
        cout<<"1 3";
       }
      else  if(S==t+3){
        cout<<"2 4";
       }
       else if(S==t+4){
        cout<<"3 5";
       }
       else if(S==t+5){
        cout<<"4 4";
       }
       else if(S==t+6){
        cout<<"5 3";
       }
       else if(S==t+7){
        cout<<"5 2";
       }
       else if(S==t+8){
        cout<<"5 1";
       }
       else if(S==t+9){
        cout<<"4 1";
       }
       else if(S==t+10){
        cout<<"3 1";
       }
       else if(S==t+11){
        cout<<"2 1";
       }
       else if(S==t+12){
        cout<<"2 2";
       }
       else if(S==t+13){
        cout<<"2 3";
       }
       else if(S==t+14){
        cout<<"3 4";
       }
       else if(S==t+15){
        cout<<"4 3";
       }
       else if(S==t+15){
        cout<<"3 2";
       }

       else if(S==t+17){
        cout<<"3 3";
       }
    return 0;
}
