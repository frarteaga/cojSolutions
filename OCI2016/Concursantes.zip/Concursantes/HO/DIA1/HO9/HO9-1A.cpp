/*JOSE ALEJANDRO PUPO GONGORA
PROVINCIA HLOGUIN
IPVC JOSE MARTI PEREZ*/
#include <bits/stdc++.h>

using namespace std;

int main()
{
ios_base::sync_with_stdio(0);
cin.tie(0);
freopen("hexagono.in","r",stdin);
freopen("hexagono.out","w",stdout);

int n,m,s,p,q;
cin>>n>>m>>s>>p>>q;
int arr[m];
int can,pue;
 pue=s+m;
 can=m+n;

for(int i=s;i<pue;i++)
{
  arr[i]=i;
}

int d,f;
d=p+1;
f=q+1;
cout<<0<<"\n"<<d<<" "<<f;


}
