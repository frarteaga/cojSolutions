//Manuel Alejandro Miranda Alonso
//Provincia Holguin
//IPVCE Jose Marti Perez

#include <bits/stdc++.h>
using namespace std;

struct hexag
{
    int c;
    int num;

};
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("hexagono.in","r",stdin);
    freopen("hexagono.out","w",stdout);

    int n,m,s,p,q;
    cin>>n>>m>>s>>p>>q;

    /*int maximo=(n*2)-1;


    hexag tabla[maximo+1][(maximo*2)+1];

    for(int i=0;i<maximo;i++)
    {
        for(int j=0;j<(maximo*2)-1;j++)
            tabla.c[i][j]=0;
    }

    int cont=0,cini=0,cfin=maximo*2;
    for(int i=maximo;i<=maximo+n-1;i++)
    {
        for(int j=1;j<cfin;j+=2)
        {
            tabla.c[i][j]=1;
        }
        cini++;
        cfin--;
    }
    for(int i=maximo;i<=maximo+n-1;i++)
    {
        for(int j=1;j<maximo*2;j++)
        {
            if(tabla.c[i][j]==1)
                cout<<"* ";
        }
        cout<<"\n";
    }*/
    /*while(cont<m)
    {


    }*/
    cout<<0;

}
