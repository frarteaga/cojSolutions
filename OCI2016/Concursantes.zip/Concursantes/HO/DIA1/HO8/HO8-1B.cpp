//Manuel Alejandro Miranda Alonso
//Provincia Holguin
//IPVCE Jose Marti Perez

#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("cuentas.in","r",stdin);
    freopen("cuentas.out","w",stdout);

    int n,l,s;
    cin>>n>>l>>s;
    char palabras[n][l];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<l;j++)
            cin>>palabras[i][j];
    }
    int contg=0;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            int contaux=0;
            for(int k=0;k<l;k++)
            {
                if(palabras[i][k]!=palabras[j][k])
                    contaux++;
            }
            if(contaux==1)
                contg++;
        }
    }
    cout<<contg/2;

}
