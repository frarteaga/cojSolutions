/**BRUNO JAVIER GONZALEZ MOLINA**HO4**IPVCE:JOSE MARTI**/
#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("ROBOT.in","r",stdin);
    freopen("ROBOT.out","w",stdout);
    int n,m,k,c=0;
    scanf("%d %d %d",&n,&m,&k);
    string x[n+1],a,b;
    for(int i=1;i<=n;i++){
        cin>>x[i];
    }
    int j=1;
            for(int i=1;i<=n;i++){
                a=x[j];
                if(a[i]=='#') a[i]=0;
                b=x[j+1];
                if(b[i-1]=='#') b[i-1]=0;
                if(a[i]>=b[i-1]){
                    printf("R");
                    c++;
                    if(c==k)
                        break;
                }
                else{
                    printf("D");
                    c++;
                    if(c==k)
                        break;
                    j++;
                    if(j==m)
                        break;
                    i--;
                }
            }
    return 0;
}
