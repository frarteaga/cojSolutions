/*******************************
**BRUNO JAVIER GONZALEZ MOLINA**
**IPVCE:JOSE MARTI     HO4    **
**EJERCICIO: 1B               **
********************************/
#include <bits/stdc++.h>
using namespace std;


int main()
{

    freopen("CUENTAS.in","r",stdin);
    freopen("CUENTAS.out","w",stdout);
    int n,l,s,c=0;
    cin>>n>>l>>s;
    string a,b,x[n];
    for(int i=0;i<n;i++){
        cin>>x[i];
    }
    bool sim=0,dif=0;
    for(int i=0;i<n-1;i++){
        for(int j=i+1;j<n;j++){
            for(int k=0;k<l;k++){
                a=x[i];
                b=x[j];
                if(a[k]==b[k]) continue;
                else {
                    if(sim==1){
                        dif=1;
                    }
                    sim=1;
                }
            }
        if(sim==1 && dif==0)
            c++;
        sim=0;
        dif=0;
        }
    }
    printf("%d",c);
    return 0;
}
