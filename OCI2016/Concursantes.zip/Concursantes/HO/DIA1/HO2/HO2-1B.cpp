/*Jose Angel Garcia Rodriguez
  IPVCE Jose Marti Perez
*/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen ("cuentas.in","r",stdin);
    freopen ("cuentas.out","w",stdout);
    int N, L, S;
    cin>>N>>L>>S;
    for(int i=1;i<=N;i++)
    {
       char cuentas;
       cin>>cuentas;
    }

}
