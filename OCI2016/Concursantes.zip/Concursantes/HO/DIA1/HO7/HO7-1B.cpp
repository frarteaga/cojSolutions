/*Jose Carlos Sanchez Fernandez. Holguin
IPVCE Jose Marti Perez*/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("CUENTAS.in","r",stdin);
    freopen("CUENTAS.out","w",stdout);
    int n,l,s;
     int t;
    cin>> n>>l>>s;
    for(int i=0;i<n;i++)
    cin >>t;
    cout <<n-1;



}

