/*Jose Carlos Sanchez Fernandez. Holguin
IPVCE Jose Marti Perez*/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("HEXAGONO.in","r",stdin);
    freopen("HEXAGONO.out","w",stdout);

     int a,b,c,d,e;
     cin>>a>>b>>c>>d>>e;
     if(d==1)
        cout<<c+(e-1)<<"/n"<<"3"<<" "<<a+1;

    else if(d==2)
        cout<<(6*(a-1))+((a-4)+c)+(e-1)<<"\n"<<"3"<<" "<<a+1;

}
