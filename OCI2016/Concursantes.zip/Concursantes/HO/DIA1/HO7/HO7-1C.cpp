/*Jose Carlos Sanchez Fernandez. Holguin
IPVCE Jose Marti Perez*/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("ROBOT.in","r",stdin);
    freopen("ROBOT.out","w",stdout);

    int a,b,c,d=0,e=1;
    cin>>a>>b>>c;
    int arr[100];
    for (int j=0;j<a;j++)
        cin >>arr[j];
    for (int j=0;j<c;j++)
    if (arr[d]<arr[e])
    {
         cout<<"R";
         d++;
         e++;
    }
    else
    {
        cout<<"D";
        d++;
        e++;
    }



}
