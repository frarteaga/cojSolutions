/**
    Provincia : Santiago de Cuba
    Nombre : Livan Arzuaga Sanchez
    Escuela : IPVCE Antonio Maceo
    Grado : 10mo
    Codigo : SC 8
**/

#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

ll matrix[5000][5000];

bool mark[5000][5000];

int f_ma,c_ma;

ll N,M,S,P,Q;

int const mf[7] = { 0 , 1, 0 , 1,0,-1,1};
int const mc[7] = { 1 , 1, 1 , -1,-1,0,-1};

int rellenar ( int f, int c, int lim )
{
    int n_fila=0,n_col=0;

    for( int i=0; i<lim; i++ )
    {
        n_fila += f;
        n_col  += c;

        if( !mark[n_fila][n_col] )
            matrix[n_fila][n_col] = matrix[n_fila - f][n_col - c]+1;
        else
        {
            break;
            return 0;
        }
    }

    if( matrix[f][c] == M )
    {
        f_ma = n_fila;
        c_ma = n_col;

        return 1;
    }

    return 0;

}

int main()
{
    freopen("HEXAGONO.in","r",stdin);
    freopen("HEXAGONO.out","w",stdout);

    ll m = M ;

    scanf("%I64d%I64d%I64d%I64d%I64d",&N,&M,&S,&P,&Q);

    matrix[0][0] = S;
    mark[0][0] = true;

    while( m--)
    {
       for( int i=0; i<7; i++ )
        {
           rellenar( mf[i], mc[i], N );
        }
    }

    printf("%I64d\n",matrix[P-1][Q-1]);
    printf("%d %d",f_ma,c_ma);



    return 0;
}
