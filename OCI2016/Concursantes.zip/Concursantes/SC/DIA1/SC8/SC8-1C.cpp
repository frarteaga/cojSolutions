/**
    Provincia : Santiago de Cuba
    Nombre : Livan Arzuaga Sanchez
    Escuela : IPVCE Antonio Maceo
    Grado : 10mo
    Codigo : SC 8
**/

#include <bits/stdc++.h>

using namespace std;

char mat[500][500];

char sol[200];

bool mark[500][500];

int const mf[2] = { 1,0 };
int const mc[2] = { 0,1 };

int Ans = 0;

char caminar( int l )
{
    bool b = false;

    int f=0, c=0;

    Ans = 0;

    while( !b )
    for( int i=0; i<l; i++ )
    {
        if( sol[i] == 'D')
        {
            f += mf[0];
            c += mc[0];
        }
        else
        if( sol[i] == 'R')
        {
            f += mf[1];
            c += mc[1];
        }

        if( mat[f][c] == '#' )
            return 'N';
        if( mat[f][c] != '#')
        {
            Ans+=mat[f][c] - '0';

            if(mark[f][c] == true )
                return 'S';
        }

    }

    return 'N';
}

int main()
{
    freopen("ROBOT.in","r",stdin);
    freopen("ROBOT.out","w",stdout);

    int N,M,K;

    char c;

    bool band = false, band2 = false, band2_1 = false;

    scanf("%d%d%d\n",&N,&M,&K);

    for( int i=0; i<N; i++ )
    {
        for( int j=0; j<M; j++ )
        {
            scanf("%c",&mat[i][j]);
            if( i == N-1 && mat[i][j] != '#' )
                mark[i][j] = true;
            if( j == M-1 && mat[i][j] != '#' )
                mark[i][j] = true;
        }
        scanf("\n");
    }

    for( int i=0; i<K; i++ )
        sol[i] = 'R';

    while( !band )
    {
        int i = K-1;
        c = caminar(K);

        if( !band2 )
        {
            if( c =='S' )
                band = true;
            else
            if( c == 'N' )
            {
                    sol[i] = 'D';
                    if( sol[i+1] == 'D')
                        sol[i+1] ='R';

                    if( i == 0 )
                        band2 = true;
                    i--;
            }
        }
        else
        if( band2 )
        {
            if( !band2_1 )
            {
                for( int e=0; e<K; e++ )
                    sol[e] = 'D';

                band2_1 = true;
                continue;
            }

            if( c =='S' )
                band = true;
            else
            if( c == 'N' )
            {
                    sol[i] = 'D';

                    if( sol[i+1] == 'R')
                        sol[i+1] ='D';
            }
        }
    }

    for( int i=0; i<K; i++ )
        printf("%c",sol[i]);

    /// Solamente me piden como salida la cadena pero si piden la
    /// cantidad de premios solo descomentarien las siguientes lineas

/*  printf("\n");
    printf("%d",Ans);*/

    return 0;
}
