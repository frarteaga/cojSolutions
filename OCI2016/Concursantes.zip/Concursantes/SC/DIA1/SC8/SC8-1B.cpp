/**
    Provincia : Santiago de Cuba
    Nombre : Livan Arzuaga Sanchez
    Escuela : IPVCE Antonio Maceo
    Grado : 10mo
    Codigo : SC 8
**/

#include <bits/stdc++.h>

using namespace std;

char cad[50000][200];

int main()
{
    freopen("CUENTAS.in","r",stdin);
    freopen("CUENTAS.out","w",stdout);

    int N,L,S;

    int cuenta=0,pares = 0;

    scanf("%d%d%d",&N,&L,&S);

    for( int i=0; i<N; i++ )
        scanf("%s",cad[i]);

    if( S == 2 )
    {
        for( int e=0; e<N; e++ )
        {
            for( int i=e+1; i<N; i++ )
            {
                for( int j=0; j<L; j++ )
                {
                    if( cad[e][j] == cad[i][j] )
                        continue;
                    else
                    if( cad[e][j] != cad[i][j] )
                          cuenta++;
                    if( cuenta > 1 )
                        break;
                }

                if( cuenta > 1 )
                {
                    cuenta = 0;
                }
                else
                if( cuenta <= 1 )
                {
                    pares++;
                    cuenta = 0;
                }
            }
        }

        printf("%d",pares);

    }
    else
    if( S == 64 )
    {
        for( int e=0; e<N; e++ )
        {
            for( int i=e+1; i<N; i++ )
            {
                for( int j=0; j<L; j++ )
                {
                    if( cad[e][j] == cad[i][j] )
                        continue;
                    else
                    if( cad[e][j] != cad[i][j] )
                          cuenta++;
                    if( cuenta > 1 )
                        break;
                }

                if( cuenta > 1 )
                {
                    cuenta = 0;
                }
                else
                if( cuenta <= 1 )
                {
                    pares++;
                    cuenta = 0;
                }
            }
        }

        printf("%d",pares);
    }


    return 0;
}
