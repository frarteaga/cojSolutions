/**

  Nombre : Jorge Alejandro S�arez G�mez

  Provincia : Santiago de Cuba.

  Escuela : IPVCE " Antonio Maceo Grajales".

  Grado : 11mo.

**/

#include <bits\stdc++.h>

using namespace std;

int N, L, S;
char c;
bool band;
vector <char> V[30500];

int main ( )
{
    freopen("CUENTAS.in", "r", stdin);
    freopen("CUENTAS.out", "w", stdout);

    scanf("%d%d%d\n", &N, &L, &S);

    for( int i = 1; i <= N; i ++ )
    {
       for( int j = 1; j <= L; j ++ )
       {
          scanf("\n%c", &c);
          V[i].push_back(c);
       }
    }

   int dif = 0, similares = 0;

   for( int i = 1; i <= N - 1; i ++ )
   {
       for( int j = i + 1; j <= N; j ++ )
       {
           for( int k = 0; k < L; k ++ )
           {
               if( dif > 1 )
                {
                   band = true;
                   break;
                }

               if( V[i][k] != V[j][k] )
                 dif ++;
           }

           if( dif <= 1 && !band )
           {
               similares ++;
           }
           band = false;
           dif = 0;
       }
   }

   printf("%d", similares);




    return 0;
}
