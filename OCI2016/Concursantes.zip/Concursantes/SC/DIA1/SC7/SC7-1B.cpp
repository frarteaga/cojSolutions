/**
SC7 Jorge Alejandro Jimenez Luna
Grado: 10
Escuela: IPVCE Antonio Maceo
Provincia: Santiago de Cuba
*/


#include <bits/stdc++.h>

using namespace std;

typedef long long int64;

int N, L, A;
char name[30000][200];
bool Mk_1[30005];
bool Mk_2[30005];


bool isSimil (int a, int b){
    int dif = 0;

    for(int i = 0; i < L; i++){
        if(name[a][i] != name[b][i])
            dif++;
    }

    return dif == 1;
}

int main()
{
    freopen("CUENTAS.IN", "r", stdin);
    freopen("CUENTAS.OUT", "w", stdout);

    scanf("%d%d%d", &N, &L, &A);

    for(int i = 0; i < N; i++){
        scanf("%s", name[i]);
    }

    int64 sol = 0;

    for(int i = 0; i < N; i++){
        for(int j = i + 1; j < N; j++){
            if(Mk_1[i] && Mk_2[j] || Mk_1[j] && Mk_2[i])
                continue;

            if(!isSimil(i, j))
                continue;

            Mk_1[i] = true;
            Mk_2[j] = true;

            sol++;
        }
    }

    printf("%I64d", sol);

    return 0;
}

