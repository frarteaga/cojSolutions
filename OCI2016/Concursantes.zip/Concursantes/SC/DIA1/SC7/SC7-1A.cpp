/**
SC7 Jorge Alejandro Jimenez Luna
Grado: 10
Escuela: IPVCE Antonio Maceo
Provincia: Santiago de Cuba
*/


#include <bits/stdc++.h>
#define oo 5000

using namespace std;

typedef long long int64;

int64 N, M, S, P, Q;
bool MA[oo][oo];
int64 F, C = 1;
int64 NOT = 0;
int64 sol = 0;

void Move (char S){
    if(S == 'R')
        C++;
    if(S == 'D')
        F++;
    if(S == 'L')
        C--;
    if(S == 'U')
        F--;
}

int main()
{
    freopen("HEXAGONO.IN", "r", stdin);
    freopen("HEXAGONO.OUT", "w", stdout);

    scanf("%I64d%I64d%I64d%I64d%I64d", &N, &M, &S, &P, &Q);

    int64 total = M + S - 1;
    int64 sol = S;
    int64 filas = (N * 2) - 1;

    NOT = S;

    printf("%I64d\n", total - ((Q-P)*(Q-P)) - 1);
    printf("%I64d %I64d\n", filas - 1, N);


    return 0;
}
