/**
SC7 Jorge Alejandro Jimenez Luna
Grado: 10
Escuela: IPVCE Antonio Maceo
Provincia: Santiago de Cuba
*/


#include <bits/stdc++.h>

using namespace std;

struct two {
    int F, C;
};

int N, M, K;
char Mk[205][205];
queue<two> Q;
int EVERY = 0;
char Solution[1000005];

const int MF[2] = {0, 1};
const int MC[2] = {1, 0};

void BFS () {
    int F, C;
    int TOTAl = 0;
    int NOT = 0;

    Q.push((two) {1, 1});

    while(!Q.empty()){
        F = Q.front().F;
        C = Q.front().C;

        Q.pop();

        int sol = 0, f, c;
        char S;

        for(int i = 0; i < 2; i++){
            int nf = MF[i] + F;
            int nc = MC[i] + C;

            if(Mk[nf][nc] == '#' || nf < 1 || nf > N || nc < 1 || nc > M){
                NOT++;
                continue;
            }

            if(Mk[nf][nc] - '0' >= sol){
                sol = Mk[nf][nc] - '0';
                f = nf;
                c = nc;
                if(MF[i] == 1 && MC[i] == 0)
                    S = 'D';
                else
                    S = 'R';
            }
        }

        if(NOT == 2)
            break;

        NOT = 0;

        Q.push((two) {f, c});
        TOTAl += sol;

        int l1 = strlen(Solution);

        Solution[l1] = S;
    }
}

int main()
{
    freopen("ROBOT.IN", "r", stdin);
    freopen("ROBOT.OUT", "w", stdout);

    scanf("%d%d%d\n", &N, &M, &K);

    for(int i = 1; i <= N; i++){
        for(int j = 1; j <= M; j++){
            scanf("%c", &Mk[i][j]);

            if(Mk[i][j] == '#')
                continue;

            EVERY += Mk[i][j] - '0';
        }
        scanf("\n");
    }

    BFS();

    int l1 = strlen(Solution);

    for(int i = 0; i < l1; i++)
        if(Solution[i] == Solution[l1 - i - 1])
            Solution[l1 - i - 1] = '\0';

    printf("%s", Solution);


    return 0;
}
