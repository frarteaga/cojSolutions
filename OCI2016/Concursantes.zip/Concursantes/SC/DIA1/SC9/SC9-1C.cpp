/**
Cidasmi Ariel Bravo Justiz.
IPU Antonio Santiago Garia
10mo
**/
#include <bits/stdc++.h>
using namespace std;
int N, D, R, A=0;
int main()
{
    freopen("robot.in","r",stdin);
    freopen("robot.out","w",stdout);
     scanf("%d",&N);
    return 0;
}
