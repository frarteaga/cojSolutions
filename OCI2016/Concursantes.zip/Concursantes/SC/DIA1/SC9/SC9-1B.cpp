/**
Cidasmi Ariel Bravo Justiz.
IPU Antonio Santiago.
10mo.
**/
#include <bits/stdc++.h>
using namespace std;Garcia.
 int main(){
    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);

return 0;
}
