/**

 SC2-1B
 Mariano Jason Rodriguez Cisnero
 12 grado
 Santiago de Cuba

**/

#include <bits/stdc++.h>
#define mxn 30005

using namespace std;

int N, L, V, sol;
char C[mxn][210];

bool chec (int a, int b)
{
    int d = 0;
    for (int i = 0; i < L; i++)
      if (C[a][i] != C[b][i]) d++;

    return d == 1;
}


int main()
{
    freopen("CUENTAS.in", "r", stdin);
    freopen("CUENTAS.out", "w", stdout);

    scanf("%d%d%d", &N, &L, &V);
    for (int i = 1; i <= N; i++){
        scanf("%s", C[i]);
        for (int j = i-1; j >= 1; j--)
            sol += chec(i,j);
    }

    printf("%d", sol);

    return 0;
}
