/**

 SC2-1C
 Mariano Jason Rodriguez Cisnero
 12 grado
 Santiago de Cuba

**/


#include <bits/stdc++.h>
#define mxn 210

using namespace std;

int N, M, K, val[mxn][mxn], acc,sol;
string sec[mxn][mxn], resp;
char mat[mxn][mxn];

int dis_man(int i, int j)
{
    return i+j-2;
}

bool puede (int x, int y)
{
    acc = 0;
    int nx=x, ny=y, p = 0,tam = dis_man(x,y);
    if (sec[x][y][p] == 'R') ny++;
    else nx++;
    p++;
    if (p >= tam) p=0;

    while (nx <= N && ny <= M){
        if (mat[nx][ny] == '#') return false;
        acc+= (mat[nx][ny]-'0');
        if (sec[x][y][p] == 'R') ny++;
        else nx++;
        p++;
        if (p >= tam) p=0;
    }
    return true;
}

int main()
{
    freopen("ROBOT.in", "r", stdin);
    freopen("ROBOT.out", "w", stdout);

    scanf("%d%d%d", &N, &M, &K);

    for (int i = 0; i <= M+1; i++) val[0][i] = val[N+1][i] = -(1<<30);
    for (int i = 0; i <= N+1; i++) val[i][0] = val[i][M+1] = -(1<<30);

    for (int i = 1; i <= N; i++){
        scanf("%s", mat[i]+1);
        for (int j = 1; j <= M; j++){
            if (i==j && j==1){
                val[i][j] = (mat[i][j]-'0');
                continue;
            }

            if (mat[i][j] == '#')
               val[i][j] = -(1<<30);
            else{
               if (val[i][j-1] > val[i-1][j]){
                 sec[i][j] = sec[i][j-1]+'R';
                 val[i][j] = val[i][j-1]+(mat[i][j]-'0');
               } else{
                 sec[i][j] = sec[i-1][j]+'D';
                 val[i][j] = val[i-1][j]+(mat[i][j]-'0');
               }
            }
            if (dis_man(i,j) == K && val[i][j] >= 0){
                if (puede(i,j)){
                    if (sol < val[i][j]+acc){
                        sol = val[i][j]+acc;
                        resp = sec[i][j];
                    }
                }
            } else if (dis_man(i,j) < K && val[i][j] >= 0){
               if (i != N && j != M) continue;
               if (sol < val[i][j]){
                    sol = val[i][j];
                    resp = sec[i][j];
               }
            }
        }
    }

    cout << resp;

    return 0;
}
