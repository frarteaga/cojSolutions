/**
    nombre: Adrian Lorenzo Lambert Diego
    grado: 11no
    escuela: IPVCE "Antonio Maceo"
    codigo:SC4.1C
*/
#include <cstdio>

using namespace std;
int N, M, K, map[205][205], Arr[105], sol[105], costo, din;
char a;

void bfs(int f, int c, int num)
{
    if(f>N || c>M)
    {
        if(costo>din)
            for(int i=1; i<=K; i++)
                sol[i]=Arr[i];
        return;
    }

    if(num==K)
    {
        bfs(f,c,0);
        return;
    }
    if(Arr[num+1]==0 && map[f+1][c]!=-1)
    {
        costo+=map[f+1][c];
        bfs(f+1,c,num+1);
        costo-=map[f+1][c];
    }
    if(Arr[num+1]==1 && map[f][c+1]!=-1)
    {
        costo+=map[f][c+1];
        bfs(f,c+1,num+1);
        costo-=map[f][c+1];
    }
}

void dfs(int f, int c, int num)
{
    if(num==K)
    {
        bfs(f,c,0);
        return;
    }
    if(f>N || c>M)
    {
        if(costo>din)
            for(int i=1; i<=K; i++)
                sol[i]=Arr[i];
        return;
    }

    if(map[f+1][c]!=-1)
    {
        costo+=map[f+1][c];
        Arr[num+1]=0;
        dfs(f+1,c,num+1);
        costo-=map[f+1][c];
    }
    if(map[f][c+1]!=-1)
    {
        costo+=map[f][c+1];
        Arr[num+1]=1;
        dfs(f,c+1,num+1);
        costo-=map[f][c+1];
    }
    return;
}

int main()
{
    freopen("ROBOT.IN", "r", stdin);
    freopen("ROBOT.OUT", "w", stdout);

    scanf("%d%d%d\n", &N, &M, &K);

    for(int i=1; i<=N; i++)
    {
        for(int j=1; j<=M; j++)
        {
            scanf("%c", &a);
            if(a=='#')
                map[i][j]=-1;
            else
                map[i][j]=a-'0';
        }
        scanf("\n");
    }

    dfs(1,1,0);

    for(int i=1; i<=K; i++)
        if(sol[i]==0)
        printf("D");
        else
        printf("R");



    return 0;
}
