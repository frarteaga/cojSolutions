/**
    nombre: Adrian Lorenzo Lambert Diego
    grado: 11no
    escuela: IPVCE "Antonio Maceo"
    codigo:SC4.1B
*/
#include <cstdio>
#include <vector>

using namespace std;
vector<int> V[300][205];
int N, M, K, Arr[30005], ca, sol;
char cad[30005][205];

int main()
{
    freopen("CUENTAS.IN", "r", stdin);
    freopen("CUENTAS.OUT", "w", stdout);

    scanf("%d%d%d\n", &N, &M, &K);

    for(int i=1; i<=N; i++)
    {
        for(int j=1; j<=M; j++)
            scanf("%c", &cad[i][j]), V[cad[i][j]][j].push_back(i);
        scanf("\n");
    }
    for(int i=1; i<=N; i++)
    {
        for(int j=1; j<=M; j++)
        {
            int tam=V[cad[i][j]][j].size();
            for(int k=0; k<tam; k++)
            {
                ca=V[cad[i][j]][j][k];
                Arr[ca]++;
                if(Arr[ca]==M-1 && ca>i)
                    sol++;
            }
        }
        fill(Arr+1, Arr+1+N,0);
    }

    printf("%d", sol);

    return 0;
}
