/**
    nombre: Adrian Lorenzo Lambert Diego
    grado: 11no
    escuela: IPVCE "Antonio Maceo"
    codigo:SC4.1A
*/
#include <cstdio>
#include <algorithm>

using namespace std;

int main()
{
    freopen("HEXAGONO.IN", "r", stdin);
    freopen("HEXAGONO.OUT", "w", stdout);

    int N, M, K, F, C, f, c, cuad, cont=N-1, markf, markc;

    scanf("%d%d%d%d%d", &N, &M, &K, &F, &C);

    f=N*2-F;
    if(f<F)
        markf=2;
    else if(f==F)
        markf=1;
    else
        f=F;

    c=N+f-C;

    if(c<C)
        markc=2;
    else if(c==C)
        markc=1
    else
        c=C;

    cuad=f-c+1;
    if(cuad<=0)
        cuad=1;



    return 0;
}
