/***********************************************/
/* Leamdro Morales Naranjo                     */
/* IPU Antonio Santiago Garc�a                 */
/* 10mo                                        */
/***********************************************/

#include <bits/stdc++.h>

using namespace std;
int N ,M ,Sol ;
int main(){

    freopen( "CUENTAS.in", "r", stdin);
    freopen( "CUENTAS.out", "w", stdout);
     bool chec (int a , int b )



    return 0;
}


