      ///********************************///
     ///Nombre:Victor Javier Lopez Roque///
    ///Escuela:Rafael Maria De Mendive ///
   /// Grado:12                       ///
  ///          SC5-1B                ///
 ///********************************///
#include <bits/stdc++.h>

using namespace std;
typedef unsigned long long ll;
long long N, L,S, sol;
char cad[30005][205];
ll H[30005][205], P[205];

bool comp(int i, int j)
{
    int ini = 1 , fin = L, piv;
    while( ini != fin)
    {
        piv = ( ini + fin )/2;
        if(H[i][piv] == H[j][piv])
            ini = piv+1;
        else
            fin = piv;
    }
    piv = ini;
    if(H[i][L] - (H[i][piv] * P[L-piv]) == H[j][L] - (H[j][piv] * P[L-piv]) )
        return 1;
    return 0;
}

int main()
{
    freopen("CUENTAS.IN", "r", stdin);
    freopen("CUENTAS.OUT", "w", stdout);

    scanf("%I64d%I64d%I64d", &N, &L, &S);
    P[0] = 1;
    for(int i = 1 ; i <= L; i++)
        P[i] = P[i-1]*257;
    for(int i = 1 ; i <= N; i++)
    {
        scanf("%s", cad[i]+1);
        for(int j = 1; j <= L ; j++)
            H[i][j] = H[i][j-1]*257 + cad[i][j];
    }
    for(int i = 1; i <= N ; i++)
        for(int j = i+1; j <= N ; j++)
            if(comp(i,j))
                sol++;

    printf("%I64d", sol);

    return 0;
}
