      ///********************************///
     ///Nombre:Victor Javier Lopez Roque///
    ///Escuela:Rafael Maria De Mendive ///
   /// Grado:12                       ///
  ///          SC5-1C                ///
 ///********************************///
#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
ll N, M, K;
char cad[205][205], sol[205];

bool sal(int i, int j )
{
    int f = 0 , c = 0;
    while( f < N  && c < M )
    {
        for(int k = 0 ;  k <= j ; k++)
        {
            if(sol[k] == 'D')
                f++;
            else
                c++;
            if(cad[f][c] == '#')
                return 0;
        }
    }
    return 1;
}

int main()
{
    freopen("ROBOT.IN", "r", stdin);
    freopen("ROBOT.out", "w", stdout);

    scanf("%I64d %I64d%I64d", &N, &M, &K);
    for(ll i = 0 ; i <= N ; i++)
        scanf("%s", cad[i]);

    for(ll i = 0 ; i < (1<<K); i++)
    {
        for(ll j = 0 ; j < K; j++)
        {
            if(i&(1<<j))
                sol[j] = 'D';
            else
                sol[j] = 'R';
            sol[j+1] = '\0';
            if(sal(i, j))
            {
                printf("%s", sol);
                return 0;
            }
        }
    }

    return 0;
}
