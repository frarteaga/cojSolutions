      ///********************************///
     ///Nombre:Victor Javier Lopez Roque///
    ///Escuela:Rafael Maria De Mendive ///
   /// Grado:12                       ///
  ///          SC5-1A                ///
 ///********************************///
#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
ll N, M, S, F, C, sol, ff, cf;

void see(int f, int c, int nf, int nc, int val, int lad, int pas)
{
    if(sol)
        return;
    int ca = abs(C-c);
    int ca1 = abs(nc-c);
    int cb = abs(F-f);
    int cb1 = abs(nf-f);
    if((ca == cb&& ca1 == cb1) ||( ca == 0 && ca1 == 0)|| (cb == 0 && cb1 == 0))
    {
        int d = sqrt( ca*ca+ cb*cb );
        sol = val+d;
        if(d > pas)
            sol=-1;
    }
}

void func1()
{
    int pas = M-1, f, c, nf, nc, cnt = 0, lad = N-1 , val = S;
    nf = 1 , nc = 1;
    while(pas > 0)
    {
        f = nf;
        c = nc;
        cnt%=6;
        if(cnt == 0)
        {
            nf = f;
            nc = c +lad;
            if(pas - lad <= 0)
            {
                ff = f;
                cf = f + (pas);
            }
            see(f, c, nf, nc, val, lad, pas);
            pas-=lad;cnt++;
            val+=lad;
            continue;
        }
        if(cnt == 1)
        {
            nf = f+lad;
            nc = c+lad;
            if(pas- lad <= 0)
            {
                ff = f+pas;
                cf = c+pas;
            }
            see(f, c, nf, nc, val, lad, pas);
            pas-=lad;cnt++;
            val+=lad;
            continue;
        }
        if(cnt == 2)
        {
            nf = f+lad;
            nc = c-lad;
            if(pas - lad <= 0)
            {
                ff = f+pas;
                cf = c-pas;
            }
            see(f, c, nf, nc, val, lad, pas);
            pas-=lad;cnt++;
            val+=lad;
            continue;
        }
        if(cnt == 3)
        {
            nf = f;
            nc = c -lad;
            if(pas - lad <= 0)
            {
                ff = f;
                cf = c -pas;
            }
            see(f, c, nf, nc, val, lad, pas);
            pas-=lad;cnt++;
            val+=lad;
            continue;
        }
        if(cnt == 4)
        {
            nf = f -lad;
            nc = c;
            if(pas-lad <= 0)
            {
                ff = f-pas;
                cf = c;
            }
            see(f, c, nf, nc, val, lad, pas);
            pas-=lad;cnt++;
            val+=lad;
            continue;
        }
        if(cnt == 5)
        {
            nf = f - lad+1;
            nc = c;
            if(pas- lad+1 <= 0)
            {
                ff = f-pas;
                cf = c;
            }
            see(f, c, nf, nc, val, lad, pas);
            pas-=(lad-1);cnt++;
            val+=(lad-1);
            if(pas == 1)
            {
                ff = nf;
                cf = nc+1;
                if(ff == F && cf == C)
                    sol = val;
            }
            pas--;
            lad--;
            val++;
            nc++;
            continue;
        }
    }
}

int main()
{
    freopen("HEXAGONO.IN", "r", stdin);
    freopen("HEXAGONO.OUT", "w", stdout);

    scanf("%I64d %I64d %I64d %I64d %I64d", &N, &M, &S, &F, &C);
    func1();
    if(sol == -1)
        sol = 0;
    printf("%I64d\n", sol);
    printf("%I64d %I64d", ff, cf);

    return 0;
}
