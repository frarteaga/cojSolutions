/**
 Nombre: Ernesto David Pe�a Herrera
 Escuela: IPU Rafael Maria de Mendive
 Grado: 12
 Problema: 1C
*/
#include <bits/stdc++.h>
#define maxn 205

using namespace std;
/**
 0 - R
 1 - D
*/

const int mf[] = { 0, 1 },
          mc[] = { 1, 0 };
int F, C, K, sol, tmp[maxn], iter, broke = 8e7;
char mat[maxn][maxn];

int check ( int cant )
{
 int f = 1, c = 1, nf, nc, ret = 0;
 for ( int step = 0; ; step++ )
 {
  iter ++;
  int p = step%cant;
  nf = f + mf[tmp[p]];
  nc = c + mc[tmp[p]];
  if ( mat[nf][nc] == '#' )
    return 0;
  if ( nf < 1 || nf > F || nc < 1 || nc > C )
   return ret;
  ret += (mat[nf][nc]-'0');
  f = nf, c = nc;
 }
}

int fin[maxn], tam;
void dfs ( int f, int c , int cant )
{
 iter ++;
 if ( cant )
  {
   int x = check ( cant );
   if ( sol < x )
   {
    sol = x;
    tam = cant;
    for ( int i = 0; i < cant; i ++ )
        fin[i] = tmp[i];
   }
  }

 if ( cant == K || iter > broke )
     return;

 int nf, nc;
 for ( int i = 0; i < 2; i ++ )
 {
  nf = f + mf[i];
  nc = c + mc[i];
  if ( nf < 1 || nf > F || nc < 1 || nc > C || mat[nf][nc] == '#' )
    continue;
  tmp[cant] = i;
  dfs ( nf, nc, cant+1 );
 }
}

int main()
{
 freopen ("ROBOT.IN", "r", stdin );
 freopen ("ROBOT.OUT", "w", stdout );

 scanf ("%d%d%d", &F, &C, &K );
 for ( int i = 1; i <= F; i ++ )
  scanf ("%s", mat[i]+1 );

 dfs ( 1, 1, 0 );

 //printf ("%d", sol );
 for ( int i = 0; i < tam; i ++ )
  if ( fin[i] == 0 )
    printf ("R");
  else
    printf ("D");

 //if (iter > 1e8 )
   //     puts("yeha!!!");

 return 0;
}
