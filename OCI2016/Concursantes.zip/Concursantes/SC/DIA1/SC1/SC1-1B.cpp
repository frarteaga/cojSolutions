/**
 Nombre: Ernesto David Peña Herrera
 Escuela: IPU Rafael Maria de Mendive
 Grado: 12
 Problema: 1B
*/
#include <bits/stdc++.h>
#define maxn 30005
#define maxl 205

using namespace std;

typedef unsigned long long ll;
int N, L, A;
ll B = 257LL, tmp[maxn];

struct pals
{
 char cad[maxl];
 ll H[maxl];
}P[maxn];

int sum ( int num )
{
 return num*(num+1)/2;
}

int main()
{
 freopen ("CUENTAS.IN", "r", stdin );
 freopen ("CUENTAS.OUT", "w", stdout );

 scanf ("%d%d%d", &N, &L, &A );
 for ( int i = 1; i <= N; i ++ )
  scanf ("%s", P[i].cad+1 );

 int sol = 0, cont;
 for ( int fix = 1; fix <= L; fix ++ )
 {
  for ( int i = 1; i <= N; i ++ )
   {
    for ( int j = 1; j <= L; j ++ )
     if ( j == fix )
       P[i].H[j] = P[i].H[j-1];
     else
       P[i].H[j] = P[i].H[j-1] * B + P[i].cad[j];
    tmp[i] = P[i].H[L];
   }

  stable_sort ( tmp+1, tmp+1+N );
  cont = 1;
  for ( int i = 1; i <= N; i ++ )
   if ( tmp[i] != tmp[i-1] )
   {
    sol += sum ( cont-1 );
    cont = 1;
   }
   else
    cont ++;

  sol += sum ( cont-1 );
 }

 printf ("%d", sol );

 return 0;
}
