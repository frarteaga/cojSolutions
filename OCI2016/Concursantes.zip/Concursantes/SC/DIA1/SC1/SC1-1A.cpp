/**
 Nombre: Ernesto David Pe�a Herrera
 Escuela: IPU Rafael Maria de Mendive
 Grado: 12
 Problema: 1A
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
ll N, M, S, F, C, iter;
const int mf[] = { 0, 1, 1, 0, -1, -1 },
          mc[] = { 1, 1, -1,-1, 0, 0 };

void encontrar_mayor ( )
{
 ll anilla = N-1, ini = 1,pos = M;
 while ( anilla )
 {
  if ( 6LL*anilla >= pos )
     break;
  pos -= 6LL*anilla;
  anilla --;
  ini ++;
 }

int f = ini, c = ini;
for ( int i = 0; i < 6; i ++ )
{
 for ( int j = 1; j <= anilla; j ++ )
 {
  pos --;
  if ( !pos )
  {
   printf ("%d %d", f, c );
   return;
  }
  f = f + mf[i];
  c = c + mc[i];
 }
}

if ( anilla == 0 )
    printf ("%d %d", f, c );

}

int broke = 5e7;
void encontrar_pos ( )
{
 ll f = 1, c = 1, anilla = N-1, num = S;
 for ( ; num <= S+M-1 && iter <= broke; anilla--)
 {
  for ( int i = 0; i < 6 && num <= S+M-1; i ++ )
  {
   for ( int j = 1; j <= anilla-(i==5) && num <= S+M-1 && iter <= broke; j ++ )
   {

    if ( f == F && c == C )
    {
     printf ("%d\n", num );
     return;
    }

    f = f + mf[i];
    c = c + mc[i];
    num ++;
    iter ++;
   }
  }
  c ++;
  num++;
 }

 printf ("0\n");
}

int main()
{
 freopen ("HEXAGONO.IN", "r", stdin );
 freopen ("HEXAGONO.OUT", "w", stdout );

 scanf ("%I64d%I64d%I64d%I64d%I64d", &N, &M, &S, &F, &C );

encontrar_pos ( );
encontrar_mayor();

 return 0;
}
