/********************************************
 *  Roberto Labadie Tamayo                  *
 *  SC3 - 1C                                *
 *  12mo                                    *
 *  IPVCE "Antonio Maceo Grajales"          *
 *                                          *
 ********************************************/

#include <bits/stdc++.h>

using namespace std;

int Dp[216][216][116];
int N, M, K;
char Mat[216][216];
const int mf[] = {1, 0},
          mc[] = {0, 1};
int sol, tamf;
long long rob;

void bfs()
{
//    for(int i = 1; i <= N; i++)
//     for(int j = 1; j <= M; j++)
//      for(int k = 1; i <= K; k++)
//       Dp[i][j][k] = 0;
    typedef pair<int, int>pos;
    typedef pair<int, long long>cosca;
    typedef pair<cosca, bool>n;
    typedef pair<n, pos>cinc;
    typedef pair<cinc, int>sex;
    priority_queue<sex>qp;
    Dp[1][1][0] = Mat[1][1] - '0';
    int f, c, nf, nc, ya,tam, cost, ncos;
    long long rec;
    qp.push(sex(cinc(n(cosca(Dp[1][1][0], 0), false), pos(1, 1)), 0));
    while(!qp.empty())
    {
        f = qp.top().first.second.first;
        c = qp.top().first.second.second;
        ya = qp.top().first.first.second;
        cost = qp.top().first.first.first.first;
        rec = qp.top().first.first.first.second;
        tam = qp.top().second;
        qp.pop();

        if(ya)
        {
            nf = f;
            nc = c;
            bool bad = false;
            ncos = cost;
            for(int i = 0 ; i < tam; i++)
             {
                 if(rec&(1 << i))
                  nc ++;
                 else nf ++;


                 if(Mat[nf][nc] == '#')
                 {
                     bad = true;
                     break;
                 }
                 else if(nf > N || nc > M || nf < 1 || nc < 1)
                 {
                     if(sol < ncos)
                        sol = ncos, rob = rec, tamf = tam;
                     bad = true;
                     break;
                 }

                 ncos += Mat[nf][nc] - '0';
             }

             if(bad) continue;

             if(Dp[nf][nc][tam] < ncos)
             {
                 Dp[nf][nc][tam] = ncos;
                 qp.push(sex(cinc(n(cosca(ncos, rec), true), pos(nf, nc)), tam));
             }
        }

        else if(tam + 1 > K)
         {
             qp.push(sex(cinc(n(cosca(Dp[f][c][tam], rec), true), pos(f, c)), tam));
             continue;
         }

        else{

            for(int i = 0; i < 2; i++)
            {
                nf = f + mf[i];
                nc = c + mc[i];

                if(Mat[nf][nc] == '#')
                 continue;
                ncos = cost + Mat[nf][nc] - '0';

                if(nf < 1 || nc < 1 || nf > N || nc > M)
                {
                    if(sol < ncos)
                        sol = ncos, rob = rec, tamf = tam;
                    continue;
                }
                int nrec = rec;
                if(i)
                    nrec = rec | (1 << (tam));
                if(Dp[nf][nc][tam + 1] < ncos)
                {
                    Dp[nf][nc][tam + 1] = ncos;
                     qp.push(sex(cinc(n(cosca(ncos, nrec), true), pos(nf, nc)), tam +1));
                }
                qp.push(sex(cinc(n(cosca(ncos, nrec), false), pos(nf, nc)), tam +1));
            }
        }
    }
}

int main()
{
    freopen("ROBOT.in", "r", stdin);
    freopen("ROBOT.out", "w", stdout);
	scanf("%d%d%d", &N, &M, &K);

	for(int i = 1; i <= N; i++)
     scanf("%s", Mat[i]+1);

    bfs();

    for(int i = 0; i < tamf; i++)
     if(rob&(1 << i))
      printf("R");
    else printf("D");
    return 0;
}
