/********************************************
 *  Roberto Labadie Tamayo                  *
 *  SC3-1B                                  *
 *  12mo                                    *
 *  IPVCE "Antonio Maceo Grajales"          *
 *                                          *
 ********************************************/

#include <bits/stdc++.h>

using namespace std;

int N, M, S;
vector<string>num;
int sol;

int main()
{
    freopen("CUENTAS.in", "r", stdin);
    freopen("CUENTAS.out", "w", stdout);
    scanf("%d%d%d", &N, &M, &S);

    string tmp;
    for(int i = 1; i <= N; i++)
    {
        cin >> tmp;
        num.push_back(tmp);
    }

    for(int i = 0; i < N; i++)
     for(int j = i+1; j < N; j++)
     {
         int cont = 0;
        for(int k = 0;cont <= 1 && k < M; k++ )
         cont += (num[i][k] != num[j][k]);

        sol += (cont == 1);
     }

     printf("%d", sol);

    return 0;
}
