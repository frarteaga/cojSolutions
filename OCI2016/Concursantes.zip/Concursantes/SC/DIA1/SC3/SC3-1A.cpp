/********************************************
 *  Roberto Labadie Tamayo                  *
 *  SC3-1A                                  *
 *  12mo                                    *
 *  IPVCE "Antonio Maceo Grajales"          *
 *                                          *
 ********************************************/

#include <bits/stdc++.h>

using namespace std;

int N, M, S, P, Q;
int num, clf, filf;
int sol;
int main()
{
    freopen("HEXAGONO.in", "r", stdin);
    freopen("HEXAGONO.out", "w", stdout);
    scanf("%d%d%d%d%d", &N, &M, &S, &P, &Q);

    int lv = 1;
    num = S - 1;
    for(int o = N, a = 1; o >= 2; o--, a++ )
    {
      int cont = 1;
      int salt = 0, cant = 0;
      int ini = 1;
      int col = a;
      int g;
      int lg = 1;
      for(int i = 1; i <= (o*2 + (o - 2)*4 + 2); i++)
      {
          num ++;
        if(lv == P && col == Q)
            sol = num;

        if(lv == 4 && col == 5)
        {
            int gp;
            gp++;
            gp--;
            gp += 9;
            gp/=4;
        }
        clf = col, filf = lv;

        if(num == M+S-1)
        goto rob;

        if(i == (o*2 + (o - 2)*4 + 2))
            break;

        cont ++;
        if(cont-1 == o)
         salt = 1;
        else  if(cant == o)
        salt = -1;
        else if(cont-1 == o + (o-2)*2 + 2)
        salt = 0;

        lv += salt;
        lg += salt;
        if(lg == o*2 - 1)
         cant++;

        if(lg == ini)
        col++;
        else if(lg== 2*o - 1)
         col--, g = 5;
        else if(salt == 1 && cont <= o*2 - 1)
         col++;
        else if(salt == 1 && lg != o*2 - 1)
        col--;
        else if(salt == -1 && g == 5)
        col = a;
      }

      if(o-1 == 1)
       clf = a+1;


    }

    rob:

        printf("%d\n%d %d", sol, clf, filf);

    return 0;
}
