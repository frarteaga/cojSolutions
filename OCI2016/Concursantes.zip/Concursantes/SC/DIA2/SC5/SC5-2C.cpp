     ///*************************************///
    ///Nombre: Victor Javier Lopez Roque    ///
   ///Escuela: Rafael Maria de Mendive     ///
  ///            SC5-2C                   ///
 ///             Grado:12                ///
///*************************************///
#include <bits/stdc++.h>

using namespace std;
typedef unsigned long long ll;
typedef pair<int, int> par;
int N, W, H;
map<par, bool> T;
long long L;
int main()
{
    freopen("FUMIGACION.IN", "r", stdin);
    freopen("FUMIGACION.OUT", "w", stdout);

    scanf("%d%I64d%d%d", &N, &L, &W, &H);

    int  x, y;
    for(int k = 1 ; k <= N ; k++)
    {
        scanf("%d%d", &x, &y);
        if(L >= 1000)
            break;
        for(int x1 = x ; x1<= x+W-1; x1++)
            for(int y1 = y ; y1 <= y+H-1; y1++)
                T[par(x1,y1)] = 1;
        for(int i = 0 ; i <= L ; i++)
            for(int j = 0 ; j <= L ; j++)
                T[par(i,j)]+= T[par(i-1, j)] + T[par(i, j-1)] -T[par(i-1,j-1)];
        if(T[par(L, L)]> (L-W)*(L-H))
        {
            printf("%d", k);
            return 0;
        }
    }
    printf("-1");

    return 0;
}
