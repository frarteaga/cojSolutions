     ///*************************************///
    ///Nombre: Victor Javier Lopez Roque    ///
   ///Escuela: Rafael Maria de Mendive     ///
  ///            SC5-2A                   ///
 ///             Grado:12                ///
///*************************************///
#include <bits/stdc++.h>

using namespace std;
int N, M, K, sol, P[100], A[100], D[100];
bool B[100];
map < string , bool > Ma;
void comb (int p1,int p2, int m1, int m2)
{
    string s;
    for(int i = 1; i < p1 ; i++)
    {
        if(A[i]>=10)
        {
            s+= A[i]/10+'0';
            s+= A[i]%10+'0';
        }
        else
            s+= A[i]%10+'0';
    }
    for(int i = 1; i < p2 ; i++)
    {
        if(D[i]>=10)
        {
            s+= D[i]/10+'0';
            s+= D[i]%10+'0';
        }
        else
            s+= D[i]%10+'0';
    }
    if(Ma[s])
        return;
    Ma[s] = 1;
    if(p1 == N+1 && p2 == N+1)
    {
        sol++;
        return;
    }
    string cad;
    for(int i = 1 ; i <= 2*N ; i++)
    {
        if(B[i])
            continue;
        B[i] = 1;
        if(P[i] == 1&& p1 <=N  && i > m1 && (i < D[p1] || p2 <= p1))
            {
                A[p1] = i;
                comb(p1+1, p2, i, m2);

            }
        if(P[i] == 2 && p2 <= N && i > m2&& i > A[p2])
            {
                D[p2] = i;
                comb(p1, p2+1, m1, i);
            }
        if(!P[i])
        {
            if(p1 <= N && i > m1 &&(i < D[p1] || p2 <= p1))
            {
                A[p1] = i;
                comb(p1+1, p2, i, m2);
            }
            if(p2<= N && i > m2 && i > A[p2])
            {
                D[p2] = i;
                comb(p1, p2+1, m1, i);
            }
        }
        B[i] = 0;
    }
}
int main()
{
    freopen("TABLAS.IN", "r", stdin);
    freopen("TABLAS.OUT", "w", stdout);
    int a;
    scanf("%d", &N);
    scanf("%d", &M);
    for(int i = 0 ; i < M ; i++)
    {
        scanf("%d", &a);
        P[a] = 1;
    }
    scanf("%d", &K);
    for(int i = 0 ; i < K ; i++)
    {
        scanf("%d", &a);
        P[a] = 2;
    }

    comb(1,1,0,0);

    printf("%d", sol);
    return 0;
}
