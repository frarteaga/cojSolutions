     ///*************************************///
    ///Nombre: Victor Javier Lopez Roque    ///
   ///Escuela: Rafael Maria de Mendive     ///
  ///            SC5-2B                   ///
 ///             Grado:12                ///
///*************************************///

#include <bits/stdc++.h>
#define maxn 500005
using namespace std;
typedef pair <int,int>par;
int N, L[maxn], D[maxn];
bool B[maxn];
vector<par>V[maxn];
struct vic
{
    int  ar[2], ra, ca;
    vector<int>H;
}A[maxn];
par R[maxn];
bool comp(const int &S1, const int &S2)
{
    return A[S1].ar[1] > A[S2].ar[1];
}
bool comp1(const int &S1, const int &S2)
{
    return A[S1].ra + A[S1].ca > A[S2].ra + A[S2].ca;
}
void dfs(int nod)
{
    if( nod != 1 && V[nod].size() == 1)
    {
        A[nod].ar[0] = A[nod].ar[1] = 0;
        return;
    }
    vector<par>::iterator it;
    int ra1 = -1, ra2 = -1;
    for( it = V[nod].begin(); it!= V[nod].end(); it++)
    {
        int nn = it->first;
        int nc = it->second;

        if( L[nn] )
            continue;
        D[nn] = nod;
        L[nn] = L[nod]+1;
        A[nod].H.push_back(nn);
        A[nn].ca = nc;
        dfs(nn);
        A[nod].ar[0] = max(A[nod].ar[0],A[nn].ar[0] );
        if(ra1 < A[nn].ra + A[nn].ca)
        {
            if(ra2 < ra1)
                ra2 = ra1;
            ra1 = A[nn].ra + A[nn].ca;
        }
        else
            if(ra2 < A[nn].ra)
                ra2 = A[nn].ra + A[nn].ca;
    }
    A[nod].ar[0] = max(A[nod].ar[0], ra1+ra2);
    A[nod].ar[1] = A[nod].ar[0];
    A[nod].ra = ra1;
}

void mod(int nod, int nn)
{
    vector<int>::iterator it;
    if(L[nod] > L[nn])
        swap(nod, nn);
    A[nn].ar[1] = 0;
    A[nn].ra = 0;
    A[nn].ca = 0;
    D[nn] = 0;
    do
    {
        int x = 0, y = 0;
        A[nod].ar[0] = 0;
        for(it = A[nod].H.begin(); it != A[nod].H.end(); it++)
        {
            A[nod].ar[0] = max(A[*it].ar[1], A[nod].ar[0]);
            if(A[*it].ra + A[*it].ca > A[x].ra + A[x].ca)
            {
                if(A[x].ra + A[x].ca > A[y].ra + A[y].ca)
                    y = x;
                x = *it;

            }
            else
                if(A[*it].ra + A[*it].ca > A[y].ra + A[y].ca)
                    y = *it;
        }
        A[nod].ar[0] = max(A[nod].ar[0], A[x].ra + A[y].ra + A[x].ca + A[y].ca);
        A[nod].ra = A[x].ra + A[x].ca;
        if(A[nod].ar[1])
            A[nod].ar[1] = A[nod].ar[0];
        nod = D[nod];
    }while(nod);
}

int main()
{
    freopen("RUTAS.IN", "r", stdin);
    freopen("RUTAS.OUT", "w", stdout);

    scanf("%d", &N);
    int a, b, c;
    for(int i = 1 ; i < N ; i++)
    {
        scanf("%d%d%d", &a, &b, &c);
        R[i] = par(a,b);
        V[a].push_back(par(b, c));
        V[b].push_back(par(a, c));
    }
    B[1] = B[0] = 1;
    L[1] = 1;
    dfs(1);

    for(int i = 1; i < N ; i++)
    {
        mod(R[i].first, R[i].second);
        int nod = R[i].first;
        int nn = R[i].second;
        while(D[nod])nod = D[nod];
        while(D[nn])nn = D[nn];

        printf("%d %d", A[nod].ar[0], A[nn].ar[0]);
        if(i != N-1)
            printf("\n");
    }

    return 0;
}
