/**
    Provincia : Santiago de Cuba
    Nombre : Livan Arzuaga Sanchez
    Escuela : IPVCE Antonio Maceo
    Grado : 10mo
    Codigo : SC 8
**/

#include <bits/stdc++.h>

using namespace std;

typedef pair<int,int >par;

par A;
int W,H;

bool mark[5000][5000];

void fumigar( int i, int j, int l)
{
    int tmp = W, tmp2 = H;

    while( tmp-- && tmp2-- && i<=l && j<=l )
    {
        mark[i][j] = true;
        i++;
        j++;
    }
}

int main()
{
    freopen("FUMIGACION.in","r",stdin);
    freopen("FUMIGACION.out","w",stdout);

    int N,L;

    bool band = false;

    scanf("%d%d%d%d",&N,&L,&W,&H);

    for( int i=0; i<N; i++ )
    {
        scanf("%d%d",&A.first,&A.second );
        mark[A.first][A.second] = true;
        fumigar( A.first,A.second,L );

        for(int e=0;e<=L;e++ )
        {
            for(int j=0;j<=L;j++ )
            {
                if( !mark[e][j] )
                {
                    band = true;
                }
            }
        }

        if( i != N-1 && band )
            band = false;
        else
        if( band )
            break;
    }

    if( band )
        printf("-1");
    else
        printf("%d%d",A.first,A.second);

    return 0;
}
