/**
    Provincia : Santiago de Cuba
    Nombre : Livan Arzuaga Sanchez
    Escuela : IPVCE Antonio Maceo
    Grado : 10mo
    Codigo : SC 8
**/

#include <bits/stdc++.h>

using namespace std;

int N,a,b,c=0;

int A[50],B[50],C[50],Arr[50],Arr2[50];

bool A_mark[50],B_mark[50],C_mark[50];

int hallar_C( int a, int b,int c )
{

    int tmp, l = 0, m = c;;

    for( int i=0; i<a; i++ )
    {
        for( int j=0; j<=c; j++ )
        {
            if( A[i] == C[j] )
            {
                C[j] = 0;
                break;
            }
        }

    }

    for( int i=0; i<b; i++ )
    {
        for( int j=0; j<=c; j++ )
        {
            if( B[i] == C[j] )
            {
                C[j] = 0;
                break;
            }
        }

    }

    stable_sort( C+1,C+1+c );

    while( l <=c/2 && m >=c/2 )
    {
            tmp = C[l];
            C[l] = C[m];
            C[m] = tmp;

            l++;
            m--;
    }

    tmp = 0;

    for( int i=0 ;i<c; i++ )
    {
        if( C[i] > 0 )
            tmp++;
    }

    stable_sort( C,C+tmp );

    return tmp;
}

void hallar_Arr( int a ,int c ,int l)
{
    int pos = 0,tmp=0,tmp2=0;

    bool bandera = false ,bandera2 = false,bandera3 = false ;

    for( int i=0; i<a; i++ )
    {
        for(int j = 0; j<c; j++ )
        {
            if( C[j] < A[i] && !bandera && !C_mark[j] )
            {
                Arr[pos] = C[j];
                C_mark[j] = true;
                pos++;
            }
            else
            if( C[j] > A[i] )
            {
                bandera = true;
                break;
            }

             if( j == c-1 && C_mark[j] )
                bandera3 = true;

        }

        if( i == a-1 && !bandera3)
            bandera2 = true;

        if( bandera )
        {
            Arr[pos] = A[i];
            pos++;
            tmp2 = i+1;
            bandera = false;
        }
    }

    for( int i=0; i<c; i++ )
    {
        if( !C_mark[i] )
        {
            tmp = i;
            break;
        }
    }

    if( bandera2 )
    while(pos <= l-1)
    {
        Arr[pos] = C[tmp];
        C_mark[tmp] = true;
        pos++;
        tmp++;
    }

    if( bandera3 )
    {
        while( pos <= l-1 )
        {
            Arr2[pos] = B[tmp2];
            B_mark[tmp2] = true;
            pos++;
            tmp2++;
        }
    }
}

void hallar_Arr2( int b ,int c ,int l)
{
    int pos = 0,tmp=0,tmp2=0;

    bool bandera = false ,bandera2 = false,bandera3 = false ;

    for( int i=0; i<b; i++ )
    {
        for(int j = 0; j<c; j++ )
        {
            if( C[j] < B[i] && !bandera && !C_mark[j] )
            {
                Arr2[pos] = C[j];
                C_mark[j] = true;
                pos++;
            }
            else
            if( C[j] > B[i] )
            {
                bandera = true;
                break;
            }

            if( j == c-1 && C_mark[j] )
                bandera3 = true;
        }

        if( i == b-1 && !bandera3)
            bandera2 = true;

        if( bandera )
        {
            Arr2[pos] = B[i];
            B_mark[i] = true;
            tmp2 = i+1;
            pos++;
            bandera = false;
        }
    }

    if( bandera2 )
    for( int i=0; i<c; i++ )
    {
        if( !C_mark[i] )
        {
            tmp = i;
            break;
        }
    }

    if( bandera2 )
    while(pos <= l-1)
    {
        Arr2[pos] = C[tmp];
        C_mark[tmp] = true;
        pos++;
        tmp++;
    }

    if( bandera3 )
    {
        while( pos <= l-1 )
        {
            Arr2[pos] = B[tmp2];
            B_mark[tmp2] = true;
            pos++;
            tmp2++;
        }
    }
}

int main()
{
    freopen("TABLAS.in","r",stdin);
    freopen("TABLAS.out","w",stdout);

    int formas=0;

    scanf("%d",&N);

    scanf("%d",&a);
    for( int i = 0; i<a; i++ )
        scanf("%d",&A[i]);

    scanf("%d",&b);
    for( int i=0; i<b; i++ )
        scanf("%d",&B[i]);

    for( int i=1; i<=2*N; i++ )
    {
        C[i] = i;
        c++;
    }

    c = hallar_C( a, b, c );

    stable_sort(A,A+a);
    stable_sort(B,B+b);

    hallar_Arr( a,c,N );
    hallar_Arr2( b,c,N);

    formas++;

    for( int i=N; i>0; i-- )
    {
        for( int j=N; j>0; j-- )
        {
            if( (Arr[i] > Arr2[j] && Arr2[j] > Arr[i-1]) || ( Arr2[j] > Arr[i] && Arr[i] > Arr2[j-1] && Arr[i] < Arr2[j+1] ) )
                formas++;
        }
    }

    printf("%d",formas);

    return 0;
}
