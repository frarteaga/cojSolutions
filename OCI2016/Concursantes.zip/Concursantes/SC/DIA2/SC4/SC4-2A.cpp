/**
   nombre: Adrian Lorenzo Lambert Diego
   grado: 11no
   escuela: IPVCE "Antonio Maceo"
   codigo: SC4.2A

*/
#include <cstdio>
#include <algorithm>

using namespace std;
int N, M, K, Arr1[100], Arr2[100], Arr3[100], L, fal, pro1[100], pro2[100], sol;
bool mark[100], band;

void recur()
{
    band=false;
    for(int i=1; i<=M; i++)
        pro1[i]=Arr1[i];
    for(int i=1; i<=K; i++)
        pro2[i]=Arr2[i];
    int a=M, b=K;
    for(int i=1; i<=L; i++)
        if( mark[i] )
            pro1[++a]=Arr3[i];
        else
            pro2[++b]=Arr3[i];
    sort(pro1+1, pro1+1+N);
    sort(pro2+1, pro2+1+N);
    for(int i=1; i<=N; i++)
        if(pro2[i]<=pro1[i])
        band=true;
    if( !band )
        sol++;
    return;
}

void comb(int pos, int cant)
{
    if(cant==fal)
    {
        recur();
        return;
    }
    if(pos==L)
        return;

    for(int i=pos+1; i<=L; i++)
    {
        mark[i]=true;
        comb(i,cant+1);
        mark[i]=false;
    }
    return;
}

int main()
{
    freopen("TABLAS.IN", "r", stdin);
    freopen("TABLAS.OUT", "w", stdout);

    scanf("%d", &N);

    scanf("%d", &M);
    for(int i=1; i<=M; i++)
        scanf("%d", &Arr1[i]), mark[Arr1[i]]=true;
    scanf("%d", &K);
    for(int i=1; i<=K; i++)
        scanf("%d", &Arr2[i]), mark[Arr2[i]]=true;
    for(int i=1; i<=N*2; i++)
        if( !mark[i] )
        Arr3[++L]=i;

    fal=N-M;
    fill(mark+1, mark+1+N*2, false);

    comb(0,0);

    printf("%d", sol);

    return 0;
}
