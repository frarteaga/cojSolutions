/**
   nombre: Adrian Lorenzo Lambert Diego
   grado: 11no
   escuela: IPVCE "Antonio Maceo"
   codigo: SC4.2B

*/
#include <cstdio>
#include <algorithm>
#include <vector>

using namespace std;
typedef pair<int,int> par;
vector<par> V[4000];
int N, a[4000], b[4000], c, nod[4000], cant, sol, sol2;
bool mark[4000][4000], band[4000];

void dfs(int start)
{
     int nodo;

     nod[++cant]=start;

     int tam=V[start].size();
     for(int i=0; i<tam; i++)
     {
         nodo=V[start][i].first;
         if(!mark[start][nodo])
            continue;
         if( !band[nodo] )
            band[nodo]=true, dfs(nodo);
     }
}

void dfs1(int start, int costo)
{
    sol=max(sol,costo);
    int nodo, newc;

    int tam=V[start].size();
    for(int i=0; i<tam; i++)
    {
        nodo=V[start][i].first;
        newc=costo+V[start][i].second;
        if(!mark[start][nodo])
            continue;
        if( !band[nodo] )
            band[nodo]=true, dfs1(nodo,newc), band[nodo]=false;
    }
}

int main()
{
    freopen("RUTAS.IN" , "r", stdin);
    freopen("RUTAS.OUT", "w", stdout);

    scanf("%d", &N);

    for(int i=1; i<N; i++)
    {
        scanf("%d%d%d", &a[i], &b[i], &c);
        mark[a[i]][b[i]]=true;
        mark[b[i]][a[i]]=true;
        V[a[i]].push_back(par(b[i],c));
        V[b[i]].push_back(par(a[i],c));
    }

    for(int i=1; i<N; i++)
    {
        mark[a[i]][b[i]]=false;
        mark[b[i]][a[i]]=false;
        band[a[i]]=true;
        dfs(a[i]);
        fill(band+1, band+1+N,false);
        for(int j=1; j<=cant; j++)
            band[nod[j]]=true, dfs1(nod[j],0), band[nod[j]]=false;
        sol2=sol;
        sol=0;
        cant=0;

        band[b[i]]=true;
        dfs(b[i]);
        fill(band+1, band+1+N,false);
        for(int j=1; j<=cant; j++)
            band[nod[j]]=true, dfs1(nod[j],0), band[nod[j]]=false;
        if(sol>sol2)
            swap(sol,sol2);
        printf("%d %d\n", sol, sol2);
        sol=0;
    }



    return 0;
}
