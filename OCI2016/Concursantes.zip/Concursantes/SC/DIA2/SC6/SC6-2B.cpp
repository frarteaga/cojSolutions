/**

  Nombre : Jorge Alejandro S�arez G�mez

  Provincia : Santiago de Cuba.

  Escuela : IPVCE " Antonio Maceo Grajales".

  Grado : 11mo.

**/

#include <bits\stdc++.h>

using namespace std;

typedef pair <int,int> par;
int N, costof1 = 0, costof2 = 0;
vector <par> V[500005];
queue <par> Qc;
bool mark[500005];

void dfs( int c1 )
{
   int costo, nodo;
   vector <par> :: iterator it;

   for( it = V[c1].begin(); it != V[c1].end(); it ++ )
   {
       costo = it -> second;
       nodo = it -> first;

       if( mark[nodo] )
        continue;

       costof1 += costo;
       mark[nodo] = true;

       dfs( nodo );
       mark[nodo] = false;
   }
}

void dfs2 ( int c2 )
{
   int costo, nodo;
   vector <par> :: iterator it;

   for( it = V[c2].begin(); it != V[c2].end(); it ++ )
   {
       costo = it -> second;
       nodo = it -> first;

       if( mark[nodo] )
        continue;

       costof2 += costo;
       mark[nodo] = true;

       dfs2( nodo );
       mark[nodo] = false;
   }
}

int main ( )
{
    freopen("RUTAS.in", "r", stdin);
    freopen("RUTAS.out", "w", stdout);

    scanf("%d", &N);

    int a, b, c;
    for( int i = 1; i < N; i ++ )
    {
       scanf("%d%d%d", &a, &b, &c);

       V[a].push_back(par(b,c));
       V[b].push_back(par(a,c));

       Qc.push(par(a,b));
    }

    int x, y;
    while( !Qc.empty() )
    {
       x = Qc.front().first;
       y = Qc.front().second;

       Qc.pop();

       mark[x] = true;
       mark[y] = true;

       dfs ( x );
       dfs2( y );

       printf("%d %d\n", min( costof1, costof2 ), max( costof1,  costof2 ));

       costof1 = 0;
       costof2 = 0;
    }





    return 0;
}
