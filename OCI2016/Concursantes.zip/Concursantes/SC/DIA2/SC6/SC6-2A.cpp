/**

  Nombre : Jorge Alejandro S�arez G�mez

  Provincia : Santiago de Cuba.

  Escuela : IPVCE " Antonio Maceo Grajales".

  Grado : 11mo.

**/

#include <bits\stdc++.h>

using namespace std;

int N, Mat[3][75], A[75], B[75], C[75], formas = 0;
bool mark[75], MARK[5][75], band;

bool ver ( int ix, int jx )
{
    if( ( Mat[ix][jx+1] == 0 ) && (Mat[ix-1][jx] == 0) && (Mat[ix][jx-1] < Mat[ix][jx]) && (Mat[ix+1][jx] > Mat[ix][jx]) )
        return true;

    if( (Mat[ix][jx-1] == 0) && (Mat[ix-1][jx] == 0) && (Mat[ix][jx+1] > Mat[ix][jx]) && (Mat[ix+1][jx] > Mat[ix][jx]) )
        return true;

    if( (Mat[ix][jx-1] == 0) && (Mat[ix+1][jx] == 0)  && (Mat[ix][jx+1] > Mat[ix][jx]) && (Mat[ix-1][jx] < Mat[ix][jx]) )
        return true;

    if( (Mat[ix][jx+1] == 0) && (Mat[ix+1][jx] == 0) && (Mat[ix][jx-1] < Mat[ix][jx]) && (Mat[ix-1][jx] < Mat[ix][jx]) )
        return true;

    if(( Mat[ix][jx+1] > Mat[ix][jx]) && (Mat[ix-1][jx] == 0) && (Mat[ix][jx-1] < Mat[ix][jx]) && (Mat[ix+1][jx] > Mat[ix][jx]) )
        return true;

    if( (Mat[ix][jx+1] > Mat[ix][jx]) && (Mat[ix-1][jx] < Mat[ix][jx]) && (Mat[ix][jx-1] < Mat[ix][jx]) && (Mat[ix+1][jx] == 0) )
       return true;


    return false;
}

int main ( )
{
    freopen("TABLAS.in", "r", stdin);
    freopen("TABLAS.out", "w", stdout);

    scanf("%d", &N);

    int a, b, cont = 1;

    scanf("%d", &a);

    for( int i = 1; i <= (N/2); i ++ )
    {
       for( int j = 1; j <= N; j ++ )
       {
           Mat[i][j] = cont;
           cont ++;
       }
    }

    for( int i = 1; i <= a; i ++ )
    {
        scanf("%d", &A[i]);
        mark[A[i]] = true;
    }

    scanf("%d", &b);

   for( int j = 1; j <= b; j ++ )
   {
       scanf("%d", &B[j]);
       mark[B[j]] = true;
   }

   sort( A + 1, A + a + 1 );
   sort( B + 1, B + b + 1 );

   cont = 1;

   for( int i = 1; i <= (N*2); i ++ )
   {
       if( mark[i] )
        continue;

       C[cont] = i;
       cont ++;
   }

  sort( C + 1, C + cont );
  int tam = cont - 1;
  cont = 1;

  for( int i = 1; i <= 1; i ++ )
  {
      for( int j = 1; ( j <= N ) && (cont != a + 1 ); j ++ )
      {
          if( Mat[i][j] >= A[cont] )
          {
              Mat[i][j] = A[cont];
              MARK[i][j] = true;
              cont ++;
          }
      }
  }

  cont = 1;

  for ( int i = 2; i <= 2; i ++ )
  {
      for( int j = 1; ( j <= N ) && ( cont != b + 1); j ++ )
      {
          if( Mat[i][j] >= B[cont] )
          {
              Mat[i][j] = B[cont];
              MARK[i][j] = true;
              cont ++;
          }
      }
  }

  do
  {
      cont = 1;
      band = false;

      for( int i = 1; i <= 1; i ++ )
      {

         if( cont == tam + 1)
         break;

        for( int j = 1; j <= N; j ++ )
         {

          if( !MARK[i][j] )
          {
              Mat[i][j] = C[cont];
              cont ++;

              if( ver ( i, j ) == false )
                {
                    band = true;
                    break;
                }
          }
        }
      }

      if( !band )
      {
         for( int i = 2; i <= 2; i ++ )
         {
           if( cont == tam )
            break;

            for( int j = 1; j <= N; j ++ ){
            if( !MARK[i][j] )
            {
                Mat[i][j] = C[cont];
                cont ++;

                if( ver ( i, j ) == false )
                  {
                    band = true;
                    break;
                  }
             }
             }
           }
      }


      if ( !band )
      {
          formas ++;
      }

  }while( next_permutation( C + 1, C + tam + 1 ) );


  printf("%d", formas);


    return 0;
}
