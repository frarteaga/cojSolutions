/**
 Nombre: Ernesto David Pe�a Herrera
 Escuela: IPU Rafael Maria de Mendive
 Grado: 12
 Problema: 2A
*/

#include <bits/stdc++.h>
#define maxn 40

using namespace std;

int N, CA, A[maxn], CB, B[maxn], CC, C[maxn], F1[maxn], F2[maxn], sol, c1, c2;
int free1[maxn], free2[maxn];
bool mark[2*maxn], puesto[2*maxn];

bool check ( )
{
 int act_p = 0, p, v;
 for ( int i = 1; i <= CC; i ++ )
 {
  if ( puesto[i] )
    continue;
  act_p ++;
  p = free2[act_p];
  v = C[i];

  if ( F1[p] > v )
    return false;
  if ( F2[p-1] > v )
    return false;
  if ( F2[p+1] && F2[p+1] < v )
    return false;
  F2[p] = v;
 }

 for ( int i = 1; i <= c2; i ++ )
    F2[free2[i]] = 0;
 return true;
}

void comb_C ( int act_p, int last_v )
{
 if ( act_p == c1+1 )
 {
  sol += check ( );
  return;
 }

 int v, p = free1[act_p];
 for ( int i = last_v+1; i <= CC; i ++ )
 {
  v = C[i];
  if ( F1[p-1] > v )
    continue;
  if ( F2[p] && F2[p] < v )
    continue;
  if ( F1[p+1] && F1[p+1] < v )
    continue;
  F1[p] = v;
  puesto[i] = true;
  comb_C ( act_p+1, i );
  puesto[i] = false;
  F1[p] = 0;
 }
}

void comb_B ( int act, int last )
{
 if ( act == CB+1 )
 {
  int p = 0;
  for ( int i = 1; i <= N; i ++ )
   if ( !F2[i] )
    free2[++p] = i;
  comb_C ( 1, 0 );
  return;
 }

 for ( int i = last+1; i <= N; i ++ )
 {
  if ( F1[i] > B[act] )
    continue;
  F2[i] = B[act];
  comb_B ( act+1, i );
  F2[i] = 0;
 }
}

void comb_A ( int act, int last )
{
 if ( act == CA+1 )
 {
  int p = 0;
  for ( int i = 1; i <= N; i ++ )
   if ( !F1[i] )
     free1[++p] = i;
  comb_B ( 1, 0 );
  return;
 }

 for ( int i = last+1; i <= N; i ++ )
 {
  F1[i] = A[act];
  comb_A ( act+1, i );
  F1[i] = 0;
 }
}

int main()
{
 freopen ("TABLAS.IN", "r", stdin );
 freopen ("TABLAS.OUT", "w", stdout );

 scanf ("%d%d", &N, &CA );
 for ( int i = 1; i <= CA; i ++ )
    {
     scanf ("%d", &A[i] );
     if ( A[i] == 2*N )
     {
      printf("0");
      return 0;
     }
     mark[A[i]] = true;
    }

 scanf ("%d", &CB );
 for ( int i = 1; i <= CB; i ++ )
    {
     scanf ("%d", &B[i] );
     if ( B[i] == 1 )
     {
      printf ("0");
      return 0;
     }
     mark[B[i]] = true;
    }

 stable_sort ( A+1, A+1+CA );
 stable_sort ( B+1, B+1+CB );

 for ( int i = 1; i <= 2*N; i ++ )
  if ( !mark[i] )
    C[++CC] = i;

 c1 = N-CA;
 c2 = N-CB;
 comb_A ( 1, 0 );

 printf ("%d", sol );

 return 0;
}
