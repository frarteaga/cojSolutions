/**
 Nombre: Ernesto David Peña Herrera
 Escuela: IPU Rafael Maria de Mendive
 Grado: 12
 Problema: 2C
*/
#include <bits/stdc++.h>
#define maxn 1905

using namespace std;

int N, L, F, C, mat[maxn][maxn], iter, broke = 2e8;

int min ( int a, int b )
{
 return (a<b)? a: b;
}

int max ( int a, int b )
{
 return (a>b)? a : b;
}

int menor ( int f1, int c1, int f2, int c2 )
{
 int ret = 1<<30;
 for ( int i = f1; i <= f2 && iter < broke ; i ++ )
  for ( int j = c1; j <= c2 && iter < broke ; j ++ )
   {
    iter ++;
    ret = min ( ret, mat[i][j] );
   }
 return ret;
}

int main()
{
 freopen ("FUMIGACION.IN", "r", stdin );
 freopen ("FUMIGACION.OUT", "w", stdout );

 scanf ("%d%d%d%d", &N, &L, &F, &C );
 int sol = 0;
 if ( L > maxn )
 {
  iter = 1e9;
  goto fin;
 }

 for ( int i = 1; i <= L; i ++ )
  for ( int j = 1; j <= L; j ++ )
   mat[i][j] = 1<<30;

 int x, y;
 for ( int i = 1; i <= N; i ++ )
 {
  scanf ("%d%d", &x, &y );
  mat[x][y] = min ( mat[x][y], i );
 }

 int tmp;
 for ( int i = 1; i+F-1 <= L && iter < broke ; i ++ )
  for ( int j = 1; j+C-1 <= L && iter < broke ; j ++ )
  {
   tmp = menor ( i, j, i+F-1, j+C-1 );
   sol = max ( sol, tmp );
  }

 fin:
 if ( sol == 1<<30 || iter > broke )
    sol = -1;
 printf ("%d", sol );

 return 0;
}
