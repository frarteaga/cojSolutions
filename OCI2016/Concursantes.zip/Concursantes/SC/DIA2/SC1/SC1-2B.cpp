/**
 Nombre: Ernesto David Pe�a Herrera
 Escuela: IPU Rafael Maria de Mendive
 Grado: 12
 Problema: 2B
*/
#include <bits/stdc++.h>
#define maxn 500005

using namespace std;

int N, dead, Dp[maxn], may1[maxn], may2[maxn];
vector <int> G[maxn];
struct edges
{
 int a, b, c;
 int next ( int nod )
 {
  return (nod==a)? b : a;
 }
}E[maxn];

void dfs ( int nod, int pad )
{
 Dp[nod] = may1[nod] = may2[nod] = 0;

 int t, id, newn, cost;
 t = G[nod].size();
 for ( int i = 0; i < t; i ++ )
 {
  id = G[nod][i];
  if ( id <= dead )
    continue;
  newn = E[id].next ( nod );
  cost = E[id].c;

  if ( newn == pad )
    continue;
  dfs ( newn, nod );

  Dp[nod] = max ( Dp[nod], Dp[newn] );
  if ( may1[newn] + cost >= may1[nod] )
  {
   may2[nod] = may1[nod];
   may1[nod] = may1[newn] + cost;
  }
  else if ( may1[newn] + cost > may2[nod] )
   may2[nod] = may1[newn] + cost;
 }
 Dp[nod] = max ( Dp[nod], may1[nod]+may2[nod] );
}

int main()
{
 freopen ("RUTAS.IN", "r", stdin );
 freopen ("RUTAS.OUT", "w", stdout );

 scanf ("%d", &N );
 int a, b, c;
 for ( int i = 1; i < N; i ++ )
 {
  scanf ("%d%d%d", &a, &b, &c );
  G[a].push_back ( i );
  G[b].push_back ( i );
  E[i] = edges { a, b, c };
 }

 for ( dead = 1; dead < N; dead ++ )
 {
  dfs ( E[dead].a, -1 );
  dfs ( E[dead].b, -1 );
  a = Dp[E[dead].a];
  b = Dp[E[dead].b];

  if ( a > b )
    swap ( a, b );
  printf ("%d %d", a, b );
  if ( dead != N-1 )
    printf("\n");
 }

 return 0;
}
