/***********************************************/
/* Leandro Morales Naranjo                     */
/* IPU Antonio Santiago Garc�a                 */
/* 10mo                                        */
/*                                             */
/***********************************************/

#include <iostream>
#include <stdio.h>
#include <stdint.h>
using namespace std;
int N, K ,M ,C;
int Arr[MAX];
 long long Sol ;
 int main(){

 freopen("RUTAS.IN","r",stdin);
 freopen("RUTAS.OUT","w",stdout);
scanf("%d%d%",&N ,&M);
   for(int i=0 ; i<N ;i++){
     for(int i=0 ; i<M ;i++){
        for( int i=0 ;i<K ;i++){

        }
     }
   }





    return 0;
}
