/**
SC7 Jorge Alejandro Jimenez Luna
Grado: 10
Escuela: IPVCE Antonio Maceo
Provincia: Santiago de Cuba
*/


#include <bits/stdc++.h>

using namespace std;

int N, M, A[100], B[100], K;
bool MK[100];
int TA[100];
int TB[100];
int ORD[100];
int _ORD[100];

int main()
{
    freopen("TABLAS.IN", "r", stdin);
    freopen("TABLAS.OUT", "w", stdout);

    scanf("%d", &N);
    scanf("%d", &M);

    for(int i = 0; i < M; i++){
        scanf("%d", &A[i]);
        MK[A[i]] = 1;

        if(A[i] < N)
            TA[A[i]] = A[i];
        else
            TA[A[i] - N] = A[i];
    }

    scanf("%d", &K);

    for(int i = 0; i < K; i++){
        scanf("%d", &B[i]);
        MK[B[i]] = 1;

        if(B[i] < N)
            TB[B[i]] = B[i];
        else
            TB[B[i] - N]  = B[i];
    }

    int sol = 0, ind = 0;

    for(int i = 1; i <= N*2; i++){
        if(!MK[i]){
            ORD[ind++] = i;
            _ORD[ind] = i;
        }
    }
    int iter = 0;
    bool b1 = true;


    for(int j = 1; j <= N; j++)
        if(!TA[j]){
            TA[j] = ORD[iter++];
    }
    do{
        for(int i = 1; i <= N; i++)
            if(TA[i] < TA[i -1])
                b1 = 0;
        if(b1)
            sol++;
    }while(next_permutation(TA, TA + N));

    iter = 0;
    b1 = 1;

    for(int j = 1; j <= N; j++)
        if(!TB[j]){
            TB[j] = ORD[iter++];
    }
    do{
        for(int i = 1; i <= N; i++)
            if(TB[i] < TB[i -1])
                b1 = 0;
        if(b1)
            sol++;
    }while(next_permutation(TB, TB + N));

    printf("%d", sol + 1);


    return 0;
}
