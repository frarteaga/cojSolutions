/**
SC7 Jorge Alejandro Jimenez Luna
Grado: 10
Escuela: IPVCE Antonio Maceo
Provincia: Santiago de Cuba
*/


#include <bits/stdc++.h>

using namespace std;

typedef long long int64;

int N;
int64 L, W, H, X[10000000], Y[10000000];
int MK[5000][5000];

int POW (int M){
    return M*M;
}

int main()
{
    freopen("FUMIGACION.IN", "r", stdin);
    freopen("FUMIGACION.OUT", "w", stdout);

    scanf("%d%I64d%I64d%I64d", &N, &L, &W, &H);

    int i = 0;
    bool b1 = false;

    int S_1 = 0, S_2 = 0;

    for(i = 1; i <= N; i++){
        scanf("%I64d%I64d", &X[i], &Y[i]);

        S_1 = S_1 + (X[i] - X[i - 1]);
        S_2 = S_2 + (Y[i] - Y[i - 1]);

        if(S_1 >= W + S_2 && S_2 >= H + S_1)
            break;
    }

    printf("%d", (i - 1 == N) ? -1 : i);


    return 0;
}
