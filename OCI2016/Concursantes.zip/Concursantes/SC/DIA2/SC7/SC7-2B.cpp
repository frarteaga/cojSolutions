/**
SC7 Jorge Alejandro Jimenez Luna
Grado: 10
Escuela: IPVCE Antonio Maceo
Provincia: Santiago de Cuba
*/


#include <bits/stdc++.h>
#define MAX 500000

using namespace std;

struct two {
    int newn, cost;

    bool operator < (const two &s1) const {
        return cost > s1.cost;
    }
};

int N;
int M[MAX];
vector<two> V[MAX];
priority_queue<two> Q;
int A[MAX], B[MAX], C;

void Dijkstra (int nodo)
{
    int nod, newn, cost = 0;

    fill(M, M + N + 1, 1 << 30);
    M[nodo] = 0;
    Q.push((two) {nodo, 0});

    while(!Q.empty())
    {
        nod = Q.top().newn;
        Q.pop();

        for(vector<two>::iterator i = V[nod].begin(); i != V[nod].end(); i++)
        {
            newn = i -> newn;
            cost = i -> cost + M[nod];

            if(M[newn] > cost)
            {
                M[newn] = cost;
                Q.push((two) {newn, cost});
            }
        }
    }
}

int main()
{
    freopen("RUTAS.IN", "r", stdin);
    freopen("RUTAS.OUT", "w", stdout);

    scanf("%d", &N);
    int EVERY = 0;

    for(int i = 1; i < N; i++){
        scanf("%d%d%d", &A[i], &B[i], &C);

        V[A[i]].push_back((two) {B[i], C});
        V[B[i]].push_back((two) {A[i], C});
        EVERY += C;
    }


    for(int i = 1; i < N; i++){
        Dijkstra(i);

        int l1 = 0, l2 = 0;

        for(vector<two>::iterator j = V[A[i]].begin(); j != V[A[i]].end(); j++) {
            if(B[i] == j -> newn)
                continue;
            l1 = M[j -> newn];
            l2 = EVERY - M[B[i]] - M[j -> newn];
            EVERY = EVERY - M[j -> newn];
        }

        if(l1 > l2)
            swap(l1, l2);

        printf("%d %d\n", (l1 < 0) ? 0 : l1, (l2 < 0) ? 0 : l2);
    }

    return 0;
}
