/********************************************
 *  Roberto Labadie Tamayo                  *
 *  SC3-2A                                  *
 *  12mo                                    *
 *  IPVCE "Antonio Maceo Grajales"          *
 *                                          *
 ********************************************/

#include <bits/stdc++.h>


using namespace std;

int N, a, b, c;
int A[90];
int B[90];
int C[90];
bool marka[90];
bool mark[90];
bool markb[90];
bool markc[90];
int T[5][90];
int sol;


void comb(int f, int co)
{

    if(f > 2)
     {
         sol ++;
         return;
     }

    ///poner de a
    for(int i = 1; i <= a; i++)
    if(!marka[i])
     if(T[f][co-1] < A[i] && f == 1 && T[f-1][co] < A[i])
     {
         T[f][co] = A[i];
         marka[i] = 1;
        if(co == N)
         comb(f+1, 1);
        else
       comb(f, co+1);
       marka[i] = 0;
    }


    ///poner de b
    for(int i = 1; i <= b; i++)
    if(!markb[i])
    if(f == 2 && T[f][co-1] < B[i] && T[f-1][co] < B[i])
    {
        T[f][co] = B[i];
    markb[i] = true;
          if(co == N)
        comb(f+1, 1);
        else
         comb(f, co+1);
         markb[i] = 0;
    }


    ///poner de c
    for(int i = 1; i <= c; i++)
    if(!markc[i])
    if(T[f][co-1] < C[i] && T[f-1][co] < C[i])
    {
        T[f][co] = C[i];
        markc[i] = 1;
          if(co == N)
        comb(f+1, 1);
        else
         comb(f, co+1);
         markc[i] = 0;
    }


}
int main()
{
    freopen("TABLAS.in", "r", stdin);
    freopen("TABLAS.out", "w", stdout);
    scanf("%d%d", &N, &a);
    for(int i = 1; i <= a; i++)
    {
        scanf("%d", &A[i]);
        mark[A[i]] = 1;
    }
    scanf("%d", &b);
    for(int i = 1; i <= b; i++)
    {
        scanf("%d", &B[i]);
        mark[B[i]] = 1;
    }

    for(int i = 1; i <= 2*N; i++)
        if(!mark[i])
         C[++c] = i;

    comb(1,1);
    printf("%d", sol);

    return 0;
}
