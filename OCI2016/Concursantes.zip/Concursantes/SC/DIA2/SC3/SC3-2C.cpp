/********************************************
 *  Roberto Labadie Tamayo                  *
 *  SC3-2C                                     *
 *  12mo                                    *
 *  IPVCE "Antonio Maceo Grajales"          *
 *                                          *
 ********************************************/

#include <bits/stdc++.h>

using namespace std;

int T[3000][3000];
int A[3000][3000];
int N, L, F, C;

void update()
{
    L = min(L, 2000);
    for(int i = 0; i <= L; i++)
     fill(T[i], T[i]+1+L, false);

    for(int i = 0; i <= L; i++)
    {
       for(int j = 0; j <= L; j++)
         T[i][j] = A[i][j] + ((j-1 >= 0) ? T[i][j - 1] : 0) + ((i-1 >= 0) ?  T[i-1][j] : 0) -  ((i-1 >= 0&& j -1 >= 0) ? T[i-1][j-1] : 0);
    }
}

bool query()
{
    for(int i = 0; i + F - 1 <= L; i++)
      for(int j = 0; j + C - 1 <= L;  j++)
      {
        int acc = 0;
        acc = T[i+F-1][j+C-1] - ((i-1 >= 0) ? T[i-1][j+C-1] : 0) - ((j-1 >= 0) ? T[i+F-1][j-1] : 0) + ((i-1 >= 0&& j -1 >= 0) ? T[i-1][j-1] : 0);
        if(!acc)
          return false;
      }
      return true;
}

int main()
{
    freopen("FUMIGACION.in", "r", stdin);
    freopen("FUMIGACION.out", "w", stdout);

    scanf("%d%d%d%d", &N, &L, &F, &C);

    int a, b;
    bool band = false;
    for(int i = 1; i <= N; i++)
    {
        scanf("%d%d", &a, &b);
        a, b;
        if(A[a+1][b+1])
            continue;

        A[a+1][b+1] = 1;

       update();

       if(query())
       {
           band = true;
           printf("%d", i+(1 << 1));
           break;
       }
    }

    if(!band)
        printf("-1");
    return 0;
}
