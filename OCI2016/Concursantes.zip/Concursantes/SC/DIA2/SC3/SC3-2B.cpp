/********************************************
 *  Roberto Labadie Tamayo                  *
 *  SC3-2B                                   *
 *  12mo                                    *
 *  IPVCE "Antonio Maceo Grajales"          *
 *                                          *
 ********************************************/

#include <bits/stdc++.h>

using namespace std;

int N, LCA[500016][20], L[500016], Dp[500016][20];
typedef pair<int, int>par;
struct edge{

    int b, c, id;
    edge (int g = 0, int k = 0, int op = 0)
    {
        b = g;
        c = k;
        id = op;
    }
};
vector<edge>G[500016];
edge A[500016];
bool mark[500016];
vector <int>comp;


void bfs()
{
    queue<int>q;
    while(!q.empty())
     q.pop();

    vector<edge>::iterator it;
    int node, nn, nc;
    q.push(1);
    mark[1] = 1;
    L[1] = 1;

    while(!q.empty())
    {
        node = q.front();
        q.pop();

        for(it = G[node].begin(); it != G[node].end(); it++)
        {
            nn = it -> b;
            nc = it -> c;

            if(mark[nn]) continue;
            mark[nn ] = true;
            q.push(nn);
            L[nn] = L[node] + 1;
            LCA[nn][0] = node;
            Dp[nn][0] = nc;
            int lg = log2(L[nn]);
            for(int i = 1; i <= lg; i++)
             if(LCA[nn][i-1])
               LCA[nn][i] = LCA[LCA[nn][i-1]][i-1],
               Dp[nn][i] = Dp[LCA[nn][i-1]][i-1] + Dp[nn][i-1];
        }
    }
}

void dfs( int node, int padre)
{
    int ady, ar;
    vector<edge>::iterator it;

    for(it = G[node].begin(); it != G[node].end(); it++)
    {
        ady = it -> b;
        ar = it -> id;

        if(ady == padre || mark[ar])
            continue;

        dfs(ady, node);
    }
    comp.push_back(node);

}

int query(int a, int b)
{
    if(L[a] < L[b])
        swap(a, b);

    int lg = log2(L[a]);
    int acc = 0;
    for(int i = lg; i >= 0; i--)
     if(LCA[a][i] && L[a] - (1 << i) >= L[b])
        acc += Dp[a][i], a = LCA[a][i];

     if(a == b)
     return acc;

     lg = log2(L[a]);
      for(int i = lg; i >= 0; i--)
        if(LCA[a][i] && LCA[a][i] != LCA[b][i])
         acc += Dp[a][i] + Dp[b][i], a = LCA[a][i], b = LCA[b][i];

    acc += Dp[a][0] + Dp[b][0];
    return acc;
}
int main()
{
    freopen("RUTAS.in", "r", stdin);
    freopen("RUTAS.out", "w", stdout);
    scanf("%d", &N);

	int a, b, c;

	for(int i = 1; i < N; i++)
    {
        scanf("%d%d%d", &a, &b, &c);
        G[a].push_back(edge(b, c, i));
        G[b].push_back(edge(a, c, i));
        A[i] = edge(a, b, i);
    }

    bfs();
    fill(mark, mark+1+N, false);

    for(int i = 1; i < N; i++)
    {
        a = A[i].b;
        b = A[i].c;
        c = A[i].id;
        mark[c] = true;

        dfs(a, -1);
        int sol = 0;
        for(int j = 0; j < comp.size(); j++)
          for(int k = j+1; k < comp.size(); k++)
            sol = max(sol, query(comp[j], comp[k]));

        int sol1 = 0;
        comp.clear();
        dfs(b, -1);

        for(int j = 0; j < comp.size(); j++)
          for(int k = j+1; k < comp.size(); k++)
            sol1 = max(sol1, query(comp[j], comp[k]));

         if(sol > sol1)
          swap(sol, sol1);

         printf("%d %d", sol, sol1);
        sol = 0;
        comp.clear();
        if(i < N-1)
         printf("\n");
    }

    return 0;
}

