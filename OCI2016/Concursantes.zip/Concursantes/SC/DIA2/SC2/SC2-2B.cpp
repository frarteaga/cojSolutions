/**

SC2-2B
mariano rodriguez cisneros
santiago de cuba
12 grado

**/

#include <bits/stdc++.h>
#define mxn 500005

using namespace std;

int N;
struct pre
{
  int a, b, v;
}P[mxn], S[mxn];

struct nod
{
  int a, v;
}H[mxn][3];

typedef pair <int,int>par;
vector <par> V[mxn];

int calc(int x)
{
  int A = H[x][0].v, B = H[x][1].v;
  if (A < 0) A = 0;
  if (B < 0) B = 0;
  return A + B;
}

queue <par>Q;
bool mark[mxn];
void bfs(int star)
{
    int nx, x, c, tam, tam1;

fill(mark,mark+N+1, false);
    bool ban;
    int m1=0, m2=0, s1=0;
    mark[star] = true;

    tam = V[star].size();
    for (int j = 0; j < tam; j++){

     mark[V[star][j].first] = true;

     Q.push(par(V[star][j].first,V[star][j].second));

     s1 = 0;

     while (!Q.empty())
        {
            nx = Q.front().first;
            c = Q.front().second;
            Q.pop();
            ban = false;
            s1 = max(s1,c);
            tam1 = V[nx].size();
            for (int i = 0 ; i < tam1 ;i++){
                x = V[nx][i].first;
                if (mark[x]) continue;
                ban = true;
                Q.push(par(x,c+V[nx][i].second));
                mark[x] = true;
            }
        }

        if (m1 <= s1)
            m2 = m1,m1 = s1;
        else if (m2 < s1) m2 = s1;
    }
    H[star][0].v = m1;
    H[star][1].v = m2;
}

void unio(pre x)
{
    V[x.a].push_back(par(x.b, x.v));
    V[x.b].push_back(par(x.a, x.v));
    for (int i = 1; i <= N; i++){
       H[i][0].v = H[i][1].v = 0;
       bfs(i);
    }
}

int main()
{
    freopen("RUTAS.in", "r", stdin);
    freopen("RUTAS.out", "w", stdout);

    scanf("%d", &N);
    for (int i = 1; i < N; i++){
        scanf("%d%d%d", &P[i].a, &P[i].b, &P[i].v);
        H[i][0].a = i,H[i][0].v = 0;
        H[i][1].a = i, H[i][1].v = 0;
    }
    H[N][0].a = N,H[N][0].v = 0;
    H[N][1].a = N, H[N][1].v = 0;

    int A, B;
    for (int i = N-1; i >= 1; i--){
        A = calc(P[i].a);
        B = calc(P[i].b);
        S[i].a = A, S[i].b = B;
        unio(P[i]);
    }

    for (int i = 1; i < N; i++){
        if (S[i].a > S[i].b)
            printf("%d %d", S[i].b , S[i].a);
        else  printf("%d %d", S[i].a , S[i].b);
        if (i != N-1) printf("\n");
    }

    return 0;
}
