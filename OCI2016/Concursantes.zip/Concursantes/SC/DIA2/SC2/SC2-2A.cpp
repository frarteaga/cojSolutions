/**

SC2-2A
mariano rodriguez cisneros
santiago de cuba
12 grado

**/

#include <bits/stdc++.h>
#define mxn 40
#define mxm 80

using namespace std;

int N, M, K, mi = 1<<30, H;
int A[mxn], B[mxn], arr[2][mxn], C[mxm];
long long sol;

bool mark[mxm], mark2[mxn];

void chec2 (int npos, int ctn)
{
    if (ctn >= H){
        sol++;
        return;
    }
    int i=1;
    for (i = npos; i <= N && arr[1][i]; i++);
    for (int k = 1; k <= H; k++){
        if (mark2[k]) continue;
        if (arr[1][i-1] > C[k]) return;
        if (arr[0][i] > C[k]) return;
        if (arr[1][i+1] && arr[1][i+1] < C[k]) return;
        arr[1][i] = C[k];
        mark2[k] = true;
        chec2(i+1, ctn+1);
        mark2[k] = false;
        arr[1][i] = 0;
    }
}

void chec1 (int npos, int ctn)
{
    int i=1;
    for (i = npos; i <= N && arr[0][i]; i++);
    if (i > N){
        chec2(1,ctn);
        return;
    }
    for (int k = 1; k <= H; k++){
        if (mark2[k]) continue;
        if (arr[0][i-1] > C[k]) return;
        if (arr[0][i+1] && arr[0][i+1] < C[k]) return;
        arr[0][i] = C[k];
        mark2[k] = true;
        chec1(i+1,ctn+1);
        mark2[k] = false;
        arr[0][i] = 0;
    }

}

void convB (int pos, int npos)
{
   if (pos > K){
        chec1(1,0);
        return;
    }
    int lim = N-(K-pos);
    for (int i = npos; i <= lim; i++)
        if (arr[0][i] < B[pos]){
           arr[1][i] = B[pos];
           convB(pos+1,i+1);
           arr[1][i] = 0;
        }
}

void conv (int pos, int npos)
{
    if (pos > M){
        convB(1,1);
        return;
    }
    int lim = N-(M-pos);
    for (int i = npos; i <= lim; i++){
        arr[0][i] = A[pos];
        conv(pos+1,i+1);
        arr[0][i] = 0;
    }
}

int main()
{
    freopen("TABLAS.in", "r", stdin);
    freopen("TABLAS.out", "w", stdout);

    scanf("%d%d", &N, &M);
    for (int i = 1; i <= M; i++)
        scanf("%d", &A[i]), mark[A[i]] = true, mi = min(mi,A[i]);
    scanf("%d", &K);
    for (int i = 1; i <= K; i++)
        scanf("%d", &B[i]), mark[B[i]] = true,  mi = min(mi,B[i]);
    sort(A+1,A+1+M);
    sort(B+1,B+1+K);
    int p = 0;
    for (int i = 1; i <= N*2; i++)
        if (!mark[i]) C[++p] = i;
    H = p;
    conv(1,1);

    printf("%I64d", sol);

    return 0;
}
