/**
Cidasmi Ariel Bravo Justiz.
IPU Antonio Santiago Garcia.
10mo.
**/

#include <bits/stdc++.h>
using namespace std;
int F[1000], N;
int main(){
    freopen(".in","r",stdin);
    freopen(".out","w",stdout);
       scanf("%d",&N);
     for(int i=0; i<N; i++){
        for(int j=0; j<N; j++)
            for(int k=0; k<N; k++)

    printf("El numero de fumigacion es %d")
 return 0;
}
