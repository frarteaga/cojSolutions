/**
Cidasmi Ariel Bravo Justiz.
IPU Antonio Santiago Garcia.
10mo.
**/

#include <bits/stdc++.h>
using namespace std;
int A, B, C, F, C;
int main(){
    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);

        return 0;
}
