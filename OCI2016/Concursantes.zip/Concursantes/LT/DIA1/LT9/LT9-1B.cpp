#include <bits/stdc++.h>

using namespace std;
int semejantes;
string palabras[30001];
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie();
    freopen("cuentas.in","r",stdin);
    freopen("cuentas.out","w",stdout);
    int n,l,s;
    cin >> n >> l >> s;
    for(int i = 1; i <= n;i++){
        cin >> palabras[i];
    }
    int cont=0;
    for(int i = 1; i <= n;i++){
    for(int j = i+1;j <= n;j++){
        for(int k = 0;k < l;k++){
            if(palabras[i][k]!=palabras[j][k]){
                cont++;
                if(cont>1){
                        cont=0;
                    break;
                }
            }
        }
        if(cont==1){
            semejantes++;
            cont=0;
        }
    }
    }
    cout << semejantes;
    return 0;
}
