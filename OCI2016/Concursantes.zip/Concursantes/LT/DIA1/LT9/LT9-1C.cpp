#include <bits/stdc++.h>

using namespace std;
char mat[201][201];
int cop[201][201];
pair<int,int> WAYF[201][201];
int ki[]={0,1};
 int n,m,k;
 int cont=1;
 int it,jt;
int kj[]={1,0};
void bfs (int i,int j){
queue<pair<int,int> > cola;
int contcola=1;
cola.push(pair<int,int>(i,j));
while(!cola.empty()){
        if(cont > contcola){
            break;
        }
    pair<int,int> x = cola.front();
    cola.pop();
    for(int k = 0; k < 2;k++){
        int ii = ki[k]+x.first;
        int jj = kj[k]+x.second;
        if(mat[ii][jj]!='#'){
                if(cop[ii][jj] < (mat[x.first][x.second]-'0')+(mat[ii][jj]-'0')){
                cola.push(pair<int,int>(ii,jj));
                contcola++;
                cop[ii][jj]=(mat[x.first][x.second]-'0')+(mat[ii][jj]-'0');
                WAYF[ii][jj] = pair<int,int>(x.first,x.second);
                it=ii;
                jt=jj;
                }
    }
}
cont++;
}
return;
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie();
    freopen("robot.in","r",stdin);
    freopen("robot.out","w",stdout);
    cin >> n >> m >> k;
    for(int i = 1;i <= n;i++){
        for(int j = 1; j <= m;j++){
            cin >> mat[i][j];
        }
    }
   bfs(1,1);
   string comando="";
   for(int i = 1; i <= 101;i++){
    if(it == WAYF[it][jt].first && jt != WAYF[it][jt].second){
        comando+="R";
        jt=WAYF[it][jt].second;
    }
    else{
        comando+="D";
        it=WAYF[it][jt].first;
    }
    if(WAYF[it][jt].first==0 && WAYF[it][jt].second==0){
        break;
    }
   }
   reverse(comando.begin(),comando.end());
   string comando2="";
   for(int i = 0;i < k;i++){
    comando2+=comando[i];
   }
   cout << comando2;
    return 0;
}
