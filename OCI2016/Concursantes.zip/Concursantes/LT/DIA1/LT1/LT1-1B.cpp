/*
    Kedir Enrique Lluch Milanes
    IPVCE: Luis Urquiza
    Las Tunas
    LT1
    problema B
*/
#include <bits/stdc++.h>

using namespace std;

const int maxn = 3e4 + 1;

typedef unsigned long long LL;
string A[maxn];

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("CUENTAS.IN", "r", stdin);
    freopen("CUENTAS.OUT", "w", stdout);

    int N, L, TIP;
    cin >> N >> L >> TIP;

    for(int i = 1; i <= N; i++){
        cin >> A[i];
    }
    LL sol = 0;
    for(int it = 0; it < L; it++){
        for(int i = 1; i <= N; i++){
            string s = " " +  A[i];
            s[0] = A[i][L - 1];
            A[i] = s.substr(0, L);
        }

        sort(A + 1, A + N + 1);

        string s1 = A[1].substr(0, L - 1);
        LL cont = 1;
        for(int i = 2; i <= N; i++){
            string s2 = A[i].substr(0, L - 1);
            if(s1 == s2){
                cont++;
            }
            if(i == N || s1 != s2) {
                sol += (cont * (cont - 1)) / 2;
                cont = 1;
            }
            s1 = s2;
        }
    }
    cout << sol;
    return 0;
}
