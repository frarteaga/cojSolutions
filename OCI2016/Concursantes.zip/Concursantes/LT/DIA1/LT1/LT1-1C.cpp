/*
    Kedir Enrique Lluch Milanes
    IPVCE: Luis Urquiza
    Las Tunas
    LT1
    problema C
*/
#include <bits/stdc++.h>

using namespace std;

const int maxn = 205;

char C[maxn][maxn];
int  A[maxn][maxn];
typedef pair < int , int > ii;
typedef pair < ii , string > sii;

queue <sii> Q;
int N, M, K, val = 0;
string sol = "";

void check(string s){
    int x = 1, y = 1, v = 0, L = s.size(), it = 0;
    while(x <= N && y <= M){
        it %= L;
        if(s[it] == 'R'){
            y++;
        }
        else
        if(s[it] == 'D'){
            x++;
        }
        if(C[x][y] == '#')
            return;
        v += A[x][y];
        it++;
    }
    if(v > val){
        sol = s;
        val = v;
    }
    return;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("ROBOT.IN", "r", stdin);
    freopen("ROBOT.OUT", "w", stdout);


    cin >> N >> M >> K;

    for(int i = 1; i <= N; i++){
        for(int j = 1; j <= M; j++){
            cin >> C[i][j];
            if(C[i][j] >= '0' && C[i][j] <= '9'){
                A[i][j] = C[i][j] - '0';
            }
        }
    }
    string s = "";
    Q.push(sii(ii(1, 1), s));
    while(!Q.empty()){
        sii P = Q.front();
        Q.pop();
        int x = P.first.first, y = P.first.second;
        s = P.second;
        if(s.size() == K){
            check(s);
            continue;
        }

        x++;
        if(x > N){
            string a = s + 'D';
            check(a);
        }
        else
        if(C[x][y] != '#'){
            Q.push(sii(ii(x, y), s + 'D'));
        }
        x--;
        y++;
        if(y > M){
            string a = s + 'R';
            check(a);
        }
        else
        if(C[x][y] != '#'){
            Q.push(sii(ii(x, y), s + 'R'));
        }
        y--;
        if(clock() >= 1.90 * CLOCKS_PER_SEC){
            cout << s;
            return 0;
        }
    }
    cout << sol;
    return 0;
}
