//By Forte11
//Javier Esteban Forte Reyes
//1C:Programa para el Robot
//IPVCE Luis Urquiza Jorge
#include <bits/stdc++.h>

using namespace std;

#define cik(i, a, b, c) for(int i =(a); i <=(b); i +=(c))
#define ull unsigned long long
#define bi2 pair<int, ull>
#define bi pair<int, int>
#define tet pair<bi2, bi >
#define pent pair<tet, int >
#define f first
#define s second
#define mkp make_pair

const int maxn = 205;

map<string, ull> M1;
map<ull, string> M2;

int A[maxn][maxn];

int N, M, K, Mejor_cost, M_Cad;

bool ok(int a, int b){
    return a > 0 && a <= N && b > 0 && b <= M;
}

void Dijkstra(){
    M1[" "] = 0;
    M2[0] = " ";

    priority_queue<pent, vector<pent >, greater<pent > > Q;

    //cost
    //cadena
    //fila
    //columna
    //pos_cadena
    Q.push(mkp(mkp(mkp(0, 0), mkp(1, 1)), 1));

    while(!Q.empty()){
        int C = Q.top().f.f.f;
        ull Cad = Q.top().f.f.s;
        int Fila = Q.top().f.s.f;
        int Colum = Q.top().f.s.s;
        int pos = Q.top().s;
        Q.pop();
        string a;
        bool flag = false;
        if(M2[Cad].size() > K){
            flag = true;
            a = M2[Cad];

            //cout << a << "\n";

            if(a[pos] == 'R'){
                Colum++;
            }
            else{
                Fila++;
            }
            pos++;
            if(pos > K){
                pos = 1;
            }

            if(!ok(Fila, Colum)){
                if(C > Mejor_cost){
                    Mejor_cost = C;
                    M_Cad = M1[a];
                    return;
                    //cout << a << "\n";
                }
                continue;
            }

            if(A[Fila][Colum] != -1){
                C += A[Fila][Colum];
                Q.push(mkp(mkp(mkp(C, Cad),
                            mkp(Fila, Colum)), pos));
            }
        }
        else{

            a = M2[Cad];


            //out << a << "\n";


            //cout << a << "\n";

            int new_fil = Fila + 1;

            a = a + "D";
            if(M1.find(a) == M1.end()){
                int K = M1.size() + 1;
                M1[a] = K;
                M2[K] = a;
                if(!ok(new_fil, Colum)){
                    if(C > Mejor_cost){
                        Mejor_cost = C;
                        M_Cad = K;
                        return;
                    }
                }
                else if(A[new_fil][Colum] != -1){
                    int new_cost = C + A[new_fil][Colum];
                    int new_cad =  K;
                    Q.push(mkp(mkp(mkp(new_cost, new_cad),
                                   mkp(new_fil, Colum)),
                                    pos));
                }
            }

            a = M2[Cad] + "R";

            int new_col = Colum + 1;

            if(M1.find(a) == M1.end()){
                int K = M1.size() + 1;
                M1[a] = K;
                M2[K] = a;
                if(!ok(Fila, new_col)){
                    if(C > Mejor_cost){
                        Mejor_cost = C;
                        M_Cad = K;
                        return;
                    }
                }
                else if(A[Fila][new_col] != -1){
                    int new_cost = C + A[Fila][new_col];
                    int new_cad =  K;
                    Q.push(mkp(mkp(mkp(new_cost, new_cad),
                                   mkp(Fila, new_col)),
                                    pos));
                }
            }
        }

        ////////////////////////////////////

        if(flag){
            continue;
        }

        a = M2[Cad];

        if(pos >= a.size()){
            pos = 1;
        }
        char d = a[pos];

        //cout << a << "\n";

        if(a.size() <= 1 && a.size() < K){
            continue;
        }

        if(d == 'R'){
            Colum++;

            if(!ok(Fila, Colum)){
                if(C > Mejor_cost){
                    Mejor_cost = C;
                    M_Cad = Cad;
                    return;
                }
            }

            if(A[Fila][Colum] != -1){
                C += A[Fila][Colum];
                Q.push(mkp(mkp(mkp(C, M1[a]),
                                mkp(Fila, Colum)),
                                pos + 1));
            }
        }
        if(d == 'D'){
            Fila++;

            if(!ok(Fila, Colum)){
                if(C > Mejor_cost){
                    Mejor_cost = C;
                    M_Cad = Cad;
                    return;
                }
            }

            if(A[Fila][Colum] != -1){
                C += A[Fila][Colum];
                Q.push(mkp(mkp(mkp(C, M1[a]),
                                mkp(Fila, Colum)),
                                pos + 1));
            }
        }
    }

    return;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("ROBOT.IN", "r", stdin);
    freopen("ROBOT.OUT", "w", stdout);

    cin >> N >> M >> K;

    cik(i, 1, N, 1){
        cik(j, 1, M, 1){
            char a; cin >> a;
            if(a == '#'){
                A[i][j] = -1;
            }
            else{
                A[i][j] = (int)(a) - (int)'0';
            }
        }
    }

    Dijkstra();

    string Sol = M2[M_Cad];
    cout << Sol.substr(1) << "\n";

    return 0;
}
