//By Forte11
//Javier Esteban Forte Reyes
//1B:Pares de cuentas similares
//IPVCE Luis Urquiza Jorge
#include <bits/stdc++.h>

using namespace std;

#define cik(i, a, b, c) for(int i =(a); i <=(b); i +=(c))
#define ull unsigned long long
#define bi pair<ull, ull>
#define mkp make_pair

const int maxn = 205;
const ull base = 311;

ull Pot[maxn], TH[maxn];
map<bi, int> M;
map<ull, int> S;

ull Sol;

int N, L, Alf;

void calc_pot(){
    Pot[0] = 1;
    cik(i, 1, L, 1){
        Pot[i] = Pot[i - 1] * base;
    }
    return;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("CUENTAS.IN", "r", stdin);
    freopen("CUENTAS.OUT", "w", stdout);

    cin >> N >> L >> Alf;

   // if(Alf == 64){
        calc_pot();

        cik(n, 1, N, 1){
            string A; cin >> A;

            A = " " + A;
            int lona = L;
            TH[0] = 1;
            cik(i, 1, lona, 1){
                TH[i] = TH[i - 1] * base + (ull)(A[i]);
            }

            cik(i, 1, lona, 1){
                ull H1, H2;

                H1 = TH[i - 1];
                H2 = TH[lona] - TH[i] * Pot[lona - i];

                bi K = mkp(H1, H2);
                if(M.find(K) == M.end()){
                    M[K] = 1;
                }
                else{
                    Sol += M[K];
                    M[K]++;
                }
            }

            if(S.find(TH[lona]) != S.end()){
                Sol -= S[TH[lona]] * L;
                S[TH[lona]]++;
            }
            else{
                S[TH[lona]] = 1;
            }
        }

        cout << Sol << "\n";
  //  }

    return 0;
}
