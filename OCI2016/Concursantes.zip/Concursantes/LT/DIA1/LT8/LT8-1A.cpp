/*
Hector Alexander Espinosa Reyes: LT-8
IPVCE: Luis Urquiza Jorge
Problema: Dia 1 A: Hexagono con espiral
*/
#include <bits/stdc++.h>

using namespace std;

long long N, M, S, P, Q;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("HEXAGONO.in", "r", stdin);
    freopen("HEXAGONO.out", "w", stdout);

    cin >> N >> M >> S >> P >> Q;

    long long pos = P * Q * N;
    long long bigerrow = (M + S - 1) / S;

    cout << pos << '\n';

    cout << bigerrow << ' ' << N;
    return 0;
}
