/*
Hector Alexander Espinosa Reyes: LT-8
IPVCE: Luis Urquiza Jorge
Problema: Dia 1 B: Pares de cuentas similares
*/
#include <bits/stdc++.h>

using namespace std;

int N, L, S;
int cont, frec;
string A[30000];

bool accountCompare(string c1, string c2){
    if (c1.size() != c2.size())
        return false;

    for (int i = 0; i < c1.size(); i++){
            if (c1[i] != c2[i]){
                frec++;
                if (frec > 1){
                    frec = 0;
                    return false;
                }
            }
    }
    if (frec == 0)
        return false;
    frec = 0;
    return true;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("CUENTAS.in", "r", stdin);
    freopen("CUENTAS.out", "w", stdout);

    cin >> N >> L >> S;

    for (int i = 0; i < N; i++){
        cin >> A[i];
    }

    for (int i = 0; i < N; i++){
        for (int j = i + 1; j < N; j++){
            if (A[i] == A[j]){
                continue;
            }
            if (accountCompare(A[i], A[j])){
                cont++;
            }
        }
        if (clock() > CLOCKS_PER_SEC * 3.90)
            goto ya;
    }

    ya:
    cout << cont;
    return 0;
}
