/** Dorian A. Mart�nez Zamora. Grado: 10mo */
/** C�digo: LT6 */

#include <bits/stdc++.h>

using namespace std;

unsigned long long N, M, S, P, Q;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    cin >> N >> M >> S >> P >> Q;

    cout << P * Q * N << '\n';

    cout << (M + S - 1) / S << " " << N;

    return 0;
}
