/** Dorian A. Mart�nez Zamora. Grado: 10mo */
/** C�digo: LT6 */

#include <bits/stdc++.h>

using namespace std;

const int MAXN = 30001;
int N, L, Alph;
string cuentas[MAXN];

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("CUENTAS.IN", "r", stdin);
    freopen("CUENTAS.OUT", "w", stdout);

    cin >> N >> L >> Alph;

    for(int i = 1; i <= N; i++){
        cin >> cuentas[i];
    }

    int sol = 0; int d = 0;

    for(int i = 1; i <= N; i++){
        for(int j = i + 1; j <= N; j++){
            for(int k = 0; k < L; k++){
                if(cuentas[i][k] != cuentas[j][k])
                    d++;
            }
            if(d == 1)
                sol++;
            d = 0;
        }
    }

    cout << sol;

    return 0;
}
