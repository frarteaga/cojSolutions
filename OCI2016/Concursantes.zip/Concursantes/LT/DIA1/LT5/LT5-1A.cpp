/*
    Samuel Santiesteban Avila
    11no LT5
    Problema

*/
#include <bits/stdc++.h>

using namespace std;
typedef pair<int,int> ii;
typedef pair<ii,int> pii;
#define f first
#define s second
vector<pii> sol2;
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("HEXAGONO.in","r",stdin);
    freopen("HEXAGONO.out","w",stdout);
    int n,cn,ini,x,y;
    cin>>n>>cn>>ini>>x>>y;
    int z=1,b=1,sum=ini,sol=0,j=6*(n*(n+1)/2)+1;
    int glob=2;
    while(1){
            if(sum==j+ini-1)break;
        for(int k=1;k<=n;k++){
            b+=1;sum++;
            if(y==b){
                sol2.push_back(pii(ii(z,b),sum));
            }
        }
        for(int u=1;u<n;u++){
            b+=1;z+=1;sum++;
            if(y==b){
                sol2.push_back(pii(ii(z,b),sum));
            }
        }
        for(int u=1;u<n;u++){
            b-=1;z+=1;sum++;
            if(y==b){
                sol2.push_back(pii(ii(z,b),sum));
            }
        }
         for(int k=1;k<n;k++){
            b-=1;sum++;
            if(y==b){
                sol2.push_back(pii(ii(z,b),sum));
            }
        }
         for(;z>glob;){
            z-=1;sum++;
            if(y==b){
                sol2.push_back(pii(ii(z,b),sum));
            }
        }
        b+=1;sum++;glob++;n--;
        if(y==b){
                sol2.push_back(pii(ii(z,b),sum));
        }
    }
    int may=0,t=x%2,pos1=0,pos2=0,gh=ini+cn-1;
    for(int u=0;u<sol2.size();u++){
        if(sol2[u].f.f==x&&sol2[u].f.s==y){
            cout<<sol2[u].s<<"\n";
        }
        if(sol2[u].f.s==y&&(sol2[u].f.f%2)==t&&sol2[u].s<=gh){
            if(sol2[u].s>may){
                may=sol2[u].s;
                pos1=sol2[u].f.f;
                pos2=sol2[u].f.s;
            }
        }
    }
    cout<<pos1<<" "<<pos2<<"\n";
    return 0;
}
