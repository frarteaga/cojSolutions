/*
    Samuel Santiesteban Avila
    11no LT5
    Problema 1B

*/
#include <bits/stdc++.h>

using namespace std;
bool comp(const string &a,const string &b){
    int ini=0,fin=a.size()-1,mit=0,cont=0;
    mit=a.size()/2;
    for(;ini<=mit-1&&fin>=mit;ini++,fin--){
        if(a[ini]!=b[ini])cont++;
        if(a[fin]!=b[fin])cont++;
        if(cont>1)return false;
    }
    return true;
}
const int maxn=30002;
string arr[maxn];
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("CUENTAS.in","r",stdin);
    freopen("CUENTAS.out","w",stdout);
    int n,l,car;
    cin>>n>>l>>car;
   for(int i=0;i<n;i++){
    string k;
    cin>>k;
    arr[i]=k;
   }
   int sol=0;
   for(int i=0;i<n;i++)
    for(int y=i+1;y<n;y++)
        if(comp(arr[i],arr[y]))sol++;

   cout<<sol<<"\n";

    return 0;
}
