/*
    Samuel Santiesteban Avila
    11no LT5
    Problema 1C

*/
#include <bits/stdc++.h>

using namespace std;
typedef pair<int,int> ii;
typedef pair<ii,string> sip;
#define f first
#define s second
map<int,string> cam;
map<char,ii> mov;
int n,m,k;
char mat[202][202];
void gen(){
    int cont=0;
   queue<sip> h;
   if(mat[1][2]!='#'){h.push(sip(ii(1,2),"R"));cam[cont]="R";cont++;}
   if(mat[2][1]!='#'){h.push(sip(ii(2,1),"D"));cam[cont]="D";cont++;}
   if(k==1)return;
   while(!h.empty()){
        sip w=h.front();h.pop();
        if(mat[w.f.f+mov['D'].f][w.f.s+mov['D'].s]!='#'){
            if(w.s.size()+1<k){
               h.push(sip(ii(w.f.f+mov['D'].f,w.f.s+mov['D'].s),w.s+'D'));
            }
            cam[cont]=w.s+'D';cont++;
        }
        if(mat[w.f.f+mov['R'].f][w.f.s+mov['R'].s]!='#'){
            if(w.s.size()+1<k){
               h.push(sip(ii(w.f.f+mov['R'].f,w.f.s+mov['R'].s),w.s+'R'));
            }
            cam[cont]=w.s+'R';cont++;
        }
   }
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("ROBOT.in","r",stdin);
    freopen("ROBOT.out","w",stdout);
    mov['D']=ii(1,0);
    mov['R']=ii(0,1);
    for(int u=0;u<202;u++){
        fill(mat[u],mat[u]+202,'@');
    }

    cin>>n>>m>>k;
    for(int i=1;i<=n;i++){
            for(int y=1;y<=m;y++){
                char v;
                cin>>v;
                mat[i][y]=v;
            }
    }
    if(k==1){
        int conr=0,cond=0;
        for(int p=1;p<=n;p++){
            if(mat[1][p]=='#'){
                conr=0;break;
            }
            conr++;
        }
        for(int p=1;p<=m;p++){
            if(mat[p][1]=='#'){
                cond=0;break;
            }
            cond++;
        }
        if(conr>cond){
            cout<<"R"<<"\n";
        }
        else{
            cout<<"D"<<"\n";
        }
    }
    else{
    gen();
    int may=0,pos=0,r=0,x=1,y=1,c=0;
    for(int i=0;i<cam.size();i++){
        string q=cam[i];
        int mod=q.size();
        while(1){
            if(mat[x+mov[q[r%mod]].f][y+mov[q[r%mod]].s]=='#'){
                    c=0;x=1;y=1;
                    break;
            }

            else{
                c+=(mat[x+mov[q[r%mod]].f][y+mov[q[r%mod]].s]-'0');
            }
            if(mat[x+mov[q[r%mod]].f][y+mov[q[r%mod]].s]=='@'){
                if(c>may){
                    pos=i;
                    may=c;
                }
                c=0;x=1;y=1;
            }
            x+=mov[q[r%mod]].f;
            y+=mov[q[r%mod]].s;
            r++;
        }
        r=0;
    }
    cout<<cam[pos]<<"\n";
    }

    return 0;
}
