///Raul Castro Rivero
///12mo IPVCE Luis Urquiza Jorge
///Las Tunas - 1C
#include <bits/stdc++.h>

using namespace std;

#define f first
#define s second

typedef pair<int, int> pii;
typedef pair<pii, int> pii3;

const int MAXN = 202;

int N, M, K;
char m[MAXN][MAXN];
bool mk[MAXN][MAXN];
pii way[MAXN][MAXN];
vector<string > sec;

void cds(int x, int y){
    vector<pii> w;
    while(true){
        if(x == 1 && x == y)
            break;
        w.push_back(pii(x, y));
        x = way[x][y].f;
        y = way[x][y].s;
    }
    w.push_back(pii(1, 1));

    string sc = "";

    for(int i = w.size() - 1 ; i >= 0 ; i--){
        if(abs(w[i].first - w[i - 1].first) == 1)
            sc = "D" + sc;
        else
            sc = "R" + sc;
    }
    if(sc.size())
        sec.push_back(sc);
}

void dfs(int x, int y, int k){
    if(!k){
        cds(x, y);
        return;
    }

    if(x > N || y > M){
        cds(x, y);
        return;
    }

    if(m[x + 1][y] != '#' && !mk[x + 1][y]){//down
        way[x + 1][y] = pii(x, y);
//        mk[x + 1][y] = true;
        dfs(x + 1, y, k - 1);
//        mk[x + 1][y] = false;
        way[x + 1][y] = pii(0, 0);
    }
    if(m[x][y + 1] != '#' && !mk[x][y + 1]){//rigth
        way[x][y + 1] = pii(x, y);
//        mk[x][y + 1] = true;
        dfs(x, y + 1, k - 1);
//        mk[x][y + 1] = false;
        way[x][y + 1] = pii(0, 0);
    }
}

vector<string> sol;

//void the_best(int x, int y, int ind){
//    int pos = 0;
//    cout << sec[ind] << '\n';
//    while(x <= N && y <= M){
//        if(m[x][y] == '#')
//            return;
//        if(sec[ind][pos] == 'R')
//            x++;
//        else
//            y++;
//        if(pos == sec[ind].size() - 1)
//            pos = 0;
//        else
//            pos++;
//    }
//
//    sol.push_back(sec[ind]);
//}

void ret(int x, int y, int i){
    string a = sec[i];
    if(!a.size())
        return;
    int p = 0;
    while(x <= N && y <= M){
        if(m[x][y] == '#')
            return;
        if(a[p] == 'R')
            y++;
        else if(a[p] == 'D')
            x++;
        p++;
        if(p > a.size())
            p = 0;
    }
    sol.push_back(a);
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);


    freopen("ROBOT.IN", "r", stdin);
    freopen("ROBOT.OUT", "w", stdout);

    cin >> N >> M >> K;
    for(int i = 1 ; i <= N ; i++)
        for(int j = 1 ; j <= M ; j++){
            cin >> m[i][j];
            if(m[i][j] == '#')
                mk[i][j] = true;
        }


    dfs(1, 1, K);

    for(int i = 0 ; i < sec.size() ; i++)
        ret(1, 1, i);

//    if(sol[0].size() > K)
//        for(int i = 0 ; i < K ; i++)
//            cout << sol[0][i];
    cout << sol[0] << '\n';

    return 0;
}
