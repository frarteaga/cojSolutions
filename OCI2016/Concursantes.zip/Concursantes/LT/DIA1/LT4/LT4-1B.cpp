///Raul Castro Rivero
///12mo IPVCE Luis Urquiza Jorge
///Las Tunas - 1B
#include <bits/stdc++.h>

using namespace std;

const int MAXN = 30001;

long long sol;
int N, M, K;
int fq[2];
string wd[MAXN];

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("CUENTAS.IN", "r", stdin);
    freopen("CUENTAS.OUT", "w", stdout);

    cin >> N >> M >> K;
//    if(K == 2){
//        for(int i = 0 ; i < N ; i++){
//            cin >> wd[i];
//            for(int j = 0 ; j < 2 ; j++)
//                fq[wd[i][j] - '0']++;
//        }
//
//        if(fq[0])
//            sol += fq[0] - 1;
//        if(fq[1])
//            sol += fq[1] - 1;
//        cout << sol;
//        return 0;
//    }

    for(int i = 0 ; i < N ; i++){
        cin >> wd[i];
        for(int j = i - 1 ; j >= 0 ; j--){
            int cont = 0, ei = M - 1;
            for(int k = 0 ; k < M / 2 ; k++ , ei--){
                if(wd[i][k] != wd[j][k])
                    cont++;
                if(wd[i][ei] != wd[j][ei])
                    cont++;
                if(cont > 1) break;
            }

            if(cont == 1)
                sol++;
        }
    }

    cout << sol;

    return 0;
}
