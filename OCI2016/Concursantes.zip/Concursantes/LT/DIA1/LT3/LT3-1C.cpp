///LT3
///Camilo Soto Rom�n | 10mo Grado.
///IPVCE Luis Urquiza Jorge.
///Dia 1.
///Problema C: Programa para el robot.


#include <bits/stdc++.h>

using namespace std;
const int tam = 202;
char terreno[tam][tam];
string way = "";

int DRi[] = {1};
int DRj[] = {0};

int DDi[] = {0};
int DDj[] = {1};

void cons(int i, int j){
    terreno[i][j] = '.';
    for (int k = 0; k < 1; k++){

        int ddi = DRi[k] + i;
        int ddj = DRj[k] + j;

        int dri = DDi[k] + i;
        int drj = DDj[k] + j;

        if (terreno[dri][drj] == 'x' && terreno[ddi][ddj] == '#') break;
        if (terreno[dri][drj] == '#') {way+='D'; cons(ddi, ddj);}
        if (terreno[ddi][ddj] == '#') { way+='R'; cons(dri, drj);}
        else if (terreno[ddi][ddj] != '#' && terreno[dri][drj] != '#'){
            if (terreno[ddi][ddj] > terreno[dri][drj]) { way+='D'; cons(ddi, ddj);}
            else if (terreno[dri][drj] > terreno[ddi][ddj]){ way+='R'; cons(dri, drj);}
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("ROBOT.IN", "r", stdin);
    freopen("ROBOT.OUT", "w", stdout);

    int N, M, K;
    cin >> N >> M >> K;

    for (int i = 0; i <= N + 1; i++){
        for (int j = 0; j <= M + 1; j++){
            terreno[i][j] = 'x';
        }
    }

    for (int i = 1; i <= N; i++){
        for (int j = 1; j <= M; j++){
            cin >> terreno[i][j];
        }
    }

    cons(1,1);


    for (int i = 0; i < K; i++)
        cout << way[i];

    return 0;
}
