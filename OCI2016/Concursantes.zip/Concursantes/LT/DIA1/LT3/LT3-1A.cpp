///LT3
///Camilo Soto Rom�n | 10mo Grado.
///IPVCE Luis Urquiza Jorge.
///Dia 1.
///Problema A: Hex�gono con espiral.


#include <bits/stdc++.h>

using namespace std;
const int maxs = 10000;
int llen[maxs][maxs];

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("HEXAGONO.IN", "r", stdin);
    freopen("HEXAGONO.OUT", "w", stdout);

    int N, M, S, P, Q;
    cin >> N >> M >> S >> P >> Q;

    int cot = S;
    int element = M*N;

    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++){
            llen[i][j] = cot;
            element = cot*Q+N;
        }

        int sod = Q+1;

        cout << element << '\n';
        cout << sod << ' ' << Q;

    return 0;
}
