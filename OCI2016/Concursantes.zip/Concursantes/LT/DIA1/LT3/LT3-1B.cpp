///LT3
///Camilo Soto Rom�n | 10mo Grado.
///IPVCE Luis Urquiza Jorge.
///Dia 1.
///Problema B: Pares de cuentas similares.


#include <bits/stdc++.h>

using namespace std;
vector <string> native;
int cont;
int N, L, S;

bool compara(string org, string cpy){
int cont = 0;

for (int i = 0; i < cpy.size(); i++){
    if (cpy[i] != org[i]) cont++;
    if (cont > 1)break;
}

if (cont == 1) return true;

return false;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("CUENTAS.IN", "r", stdin);
    freopen("CUENTAS.OUT", "w", stdout);

    cin >> N >> L >> S;

    for (int i = 0; i < N; i++){
        string ax;
        cin >> ax;
        native.push_back(ax);
}
    for (int i = 0; i < N - 1; i++){
        for (int j = i+1; j < N; j++){
            if ( compara(native[i], native[j]) == true )
                cont++;
        }

    }

    cout << cont;

    return 0;
}
