/*
 name: Alben Luis Urquiza Rojas(alurquiza)
 code: LT2
 problem: "Hexagono con espiral"
 compilador: GCC 4.7.1
*/
#include <bits/stdc++.h>

using namespace std;

typedef pair<long long,long long> pii;

pii f2(long long l,long long e){
    if(l == 1)
        return pii(1,1);
    if(6 * (l - 1) >= e){

        long long f,c,aux = l * 2 - 3;
        if(e <= l) f = 1,c = e;
        else if(e >= l && e <= l + aux) f = e - l + 1,c = f + l - 1;
        else if(e >= l + aux + 1 && e <= l * 2 + aux) f = l + l - 1, c = l - (e - (l + aux)) + 1;
        else f = l - (6 * (l - 1) - (l * 2 + aux)) + 1,c = 1;

        return pii(f,c);
    }
    pii aux = f2(l - 1,e - (6 * (l - 1)));
    return pii(aux.first + 1,aux.second + 1);
}

long long f1(long long l,long long i,long long f,long long c){
    return i;
    //no completada
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("hexagono.in","r",stdin);
    freopen("hexagono.out","w",stdout);

    long long N,M,S,P,Q;
    cin >> N >> M >> S >> P >> Q;

    cout << f1(N,S,P,Q) << '\n';
    pii par = f2(N,M);
    cout << par.first << ' ' << par.second << '\n';

    return 0;
}
