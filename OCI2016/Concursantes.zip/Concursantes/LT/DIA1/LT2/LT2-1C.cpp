/*
 name: Alben Luis Urquiza Rojas(alurquiza)
 code: LT2
 problem: "Programa para el robot"
 compilador: GCC 4.7.1
*/
#include <bits/stdc++.h>

using namespace std;

const int SIZE = 202;
vector<pair<int,string> > P[SIZE][SIZE];
typedef pair<int,int> pii;
int A[SIZE][SIZE],N,M,K,;
int Mf[] = {1,0},N,M,K;
int Mc[] = {0,1};
char Mov[] = "DR";
long long sol = 0;
string SOL;

void bfs(){
    queue<pii> Q;
    P[1][1].push_back(make_pair(A[1][1],""));

    for(int i = 1;i <= N + 1;i++){
        for(int j = 1;j <= M + 1;j++){
            if((i == 1 && j == 1) || A[i][j] == -1)
                continue;
            Q.push(make_pair(i,j));
        }
    }

    while(!Q.empty()){
        int f = Q.front().first;
        int c = Q.front().second;

        Q.pop();

        for(int i = 0;i < 2;i++){
            int ff = f - Mf[i];
            int cc = c - Mc[i];

            for(int q = 0;q < P[ff][cc].size();q++)
                P[f][c].push_back(make_pair(P[ff][cc][q].first + A[f][c],P[ff][cc][q].second + Mov[i]));

            if((f > N && c > 0) || (c > M && f > 0)){
                for(int w = 1;w <= K;w++){
                    for(int q = 0;q < P[f][c].size();q++){
                        if(P[f][c][q].first > sol){
                            bool flag = true;
                            for(int j = 0;j < P[f][c][q].second.size();j++){
                                int aux = j % w;
                                if(P[f][c][q].second[j] != P[f][c][q].second[aux]){
                                    flag = false;
                                    break;
                                }
                            }
                            if(flag){
                                sol = P[f][c][q].first;
                                SOL = P[f][c][q].second.substr(0,w);
                            }
                        }
                    }
                }
            }
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("robot.in","r",stdin);
    freopen("robot.out","w",stdout);

    cin >> N >> M >> K;

    for(int i = 1;i <= N;i++){
        for(int j = 1;j <= M;j++){
            char l;
            cin >> l;

            if(l == '#')
                A[i][j] = -1;
            else
                A[i][j] = l - '0';
        }
    }

    bfs();

    cout << SOL << '\n';

    return 0;
}
