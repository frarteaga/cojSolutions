/*
 name: Alben Luis Urquiza Rojas(alurquiza)
 code: LT2
 problem: "Pares de cuentas similares"
 compilador: GCC 4.7.1
*/
#include <bits/stdc++.h>

using namespace std;

map<string,int> M;
string s;

string func_S(int pos){
    string newS('0',s.size());
    for(int i = 0;i < s.size();i++){
        if(i == pos)
            continue;
        newS[i] = s[i];
    }
    return newS;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("cuentas.in","r",stdin);
    freopen("cuentas.out","w",stdout);

    int N,L,S;
    cin >> N >> L >> S;

    long long sol = 0;
    for(int i = 1;i <= N;i++){
        cin >> s;

        for(int j = 0;j < L;j++)
            sol += M[func_S(j)]++;

    }

    cout << sol << '\n';

    return 0;
}
