/*
    Samuel Santiesteban Avila
    LT5 11no Problema A
*/
#include <bits/stdc++.h>

using namespace std;
int mat[75];
int mat2[75];
int A[40];
int B[40];
int arr[3][40];
int mi(){
    for(int i=1;i<75;i++){
        if(mat[i]==3)return i;
    }
    return 0;
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("TABLAS.in","r",stdin);
    freopen("TABLAS.out","w",stdout);
    fill(mat,mat+75,3);
    int n,m,k;
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        int f;
        cin>>f;
        mat[f]=1;
        A[i]=f;
    }
    for(int i=1;i<=k;i++){
        int f;
        cin>>f;
        mat[f]=2;
        B[i]=f;
    }
    sort(A,A+m);
    sort(B,B+k);
    for(int i=1;i<=m;i++){
        arr[0][i]=A[i];
    }
    if(B[1]<A[1]&&B[1]< mi()){
        cout<<0<<"\n";
    }
    else{
        for(int i=1;i<=2*n;i++){
            if(mat[i]==3){
                if(i<A[1]){
                    mat2[i]=1;
                }
                else{
                    mat2[i]=2;
                }
            }
        }
        int cont=0;
        for(int p=1;p<=2*n;p++){
            if(mat2[p]==2)cont++;
        }
        cout<<cont<<"\n";
    }

    return 0;
}
