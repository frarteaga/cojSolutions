/*
    Samuel Santiesteban Avila
    LT5 11no Problema
*/
#include <bits/stdc++.h>

using namespace std;
typedef pair<int,int> ii;
#define s second
#define f first
int n,l,w,h;
ii coo[100005];
int mov1[5];
int mov2[5];
vector<ii> prog;
bool com(ii q,ii e,ii o){
    int minx=min(q.f,e.f),mayx=max(q.f,e.f)
    ,miny=min(q.s,e.s),mayy=max(q.s,e.s);
        if(o.f>minx&&o.f<mayx&&o.s>miny&&o.s<mayy)return true;
        return false;
}
bool fun(ii g){
    if(g.f>=0&&g.s>=0&&g.f<=l&&g.s<=l)
        return true;

    return false;
}
bool ok(){
    bool mo[4];
    fill(mo,mo+4,0);
    for(int p=0;p<prog.size();p++){
        for(int u=0;u<prog.size();u++){
                if(p==u)continue;
            for(int j=0;j<4;j++){
                if(fun(ii(prog[p].f+mov1[j],prog[p].s+mov2[j]))){
                    if(com(prog[p],ii(prog[p].f+mov1[j],prog[p].s+mov2[j]),prog[u])){
                        mo[j]=true;
                    }
                }
                else{
                    mo[j]=true;
                }
            }
        }
         for(int q=0;q<4;q++){
            if(!mo[q])return true;
        }
        fill(mo,mo+4,0);
    }

    return false;

}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("FUMIGACION.in","r",stdin);
    freopen("FUMIGACION.out","w",stdout);

    cin>>n>>l>>w>>h;
    for(int i=0;i<n;i++){
        int x,y;
        cin>>x>>y;
        coo[i]=ii(x,y);
    }
    mov1[0]=h;mov1[1]=(h*-1);mov1[2]=h;mov1[3]=(h*-1);
    mov2[0]=w;mov2[1]=w;mov2[2]=(w*-1);mov2[3]=(w*-1);
    for(int d=0;d<n;d++){
        prog.push_back(coo[d]);
        if(!ok()){
            cout<<d+1<<"\n";
            return 0;
        }
    }
    cout<<-1<<"\n";

    return 0;
}
