/*
    Samuel Santiesteban Avila
    LT5 11no Problema B
*/
#include <bits/stdc++.h>

using namespace std;
int n;
typedef pair<int,int> ii;
typedef pair<int,ii> pii;
#define s second
#define f first
pii ar[500003];
bool mk[500003];
//bool mat[40003][40003];
int fun(int m,int num){
    long long sum=0;
    for(int i=num;i<n-1;i++){
            if(ar[i].s.f==m){
                sum+=ar[i].f+fun(ar[i].s.s,num);
            }
    }
    return sum;
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("RUTAS.in","r",stdin);
    freopen("RUTAS.out","w",stdout);

    cin>>n;
    for(int y=0;y<n-1;y++){
        int a,b,c;
        cin>>a>>b>>c;
        ar[y]=pii(c,ii(a,b));
    }
    for(int y=0;y<n-1;y++){
            int fg=fun(ar[y].s.f,y+1),gh=fun(ar[y].s.s,y+1);
        if(fg>gh){
            cout<<gh<<" "<<fg<<"\n";
        }
        else{
            cout<<fg<<" "<<gh<<"\n";
        }

    }
    return 0;
}
