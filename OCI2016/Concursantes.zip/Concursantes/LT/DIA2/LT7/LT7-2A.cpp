//By Forte11
//Javier Esteban Forte Reyes
//LT7
//IPVCE Luis Urquiza Jorge
//2A Tablas con tres conjuntos

#include <bits/stdc++.h>

using namespace std;

#define cik(i, a, b, c) for(int i =(a); i <=(b); i +=(c))
#define Vit vector<int>::iterator

const int maxn = 40;

set<int> A, B;
set<vector<int > > SVI;

//vector<int > Mat[3];
//vector<int > new_Mat[3];
//vector<int > C;

vector<int> AA, BB;
bool Bo[maxn * 2];

int N, M, K, Sol;

bool ok(){
    AA.clear();
    BB.clear();

    cik(i, 1, N * 2, 1){
        if(A.find(i) != A.end()){
            AA.push_back(i);
        }
        else if(B.find(i) != B.end()){
            BB.push_back(i);
        }
        else if(Bo[i]){
            AA.push_back(i);
        }
        else{
            BB.push_back(i);
        }
    }

    if(SVI.find(AA) != SVI.end()){
        return false;
    }

    SVI.insert(AA);
    if(AA[0] > BB[0]){
        return false;
    }

    cik(i, 1, N - 1, 1){
        if(AA[i] > AA[i - 1] && BB[i] > BB[i - 1] && AA[i] < BB[i]){
            continue;
        }
        return false;
    }
    return true;
}

void backtracking(int id, int ele){
    if(ele == N){
        Sol += ok();
        return;
    }

    cik(i, id, N * 2, 1){
        if(A.find(i) == A.end() && B.find(i) == B.end() && !Bo[i]){
            Bo[i] = true;
            backtracking(id + 1, ele + 1);
            Bo[i] = false;
        }
    }
    return;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("TABLAS.IN", "r", stdin);
    freopen("TABLAS.OUT", "w", stdout);

    cin >> N >> M;

    cik(i, 1, M, 1){
        int a; cin >> a;
        A.insert(a);
        //Mat[1].push_back(a);
    }
    int K; cin >> K;
    cik(i, 1, K, 1){
        int a; cin >> a;
        B.insert(a);
        //Mat[2].push_back(a);
    }

    int CantA = A.size();
    int CantB = A.size();

    if(CantA < CantB){
        swap(CantA, CantB);

        set<int > C;
        C = A;
        A = B;
        B = C;
    }

    backtracking(1, CantA);

    cout << Sol << "\n";

    return 0;
}
