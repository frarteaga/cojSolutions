//By Forte11
//Javier Esteban Forte Reyes
//LT7
//IPVCE Luis Urquiza Jorge
//2B Rutas mas largas
#include <bits/stdc++.h>

using namespace std;

#define cik(i, a, b, c) for(int i =(a); i <=(b); i +=(c))
#define bi pair<int, int>
#define f first
#define s second
#define mkp make_pair
#define mx(a, b) ((a) > (b) ? (a) : (b))
#define mn(a, b) ((a) < (b) ? (a) : (b))

const int maxn = 5e5 + 5;

vector<bi > Adlist[maxn];
set<bi > S;

bi A[maxn];
bool B[maxn];
int C[maxn];

int N, M_Cost, best;

void clean(){
    best = M_Cost = 0;
    cik(i, 1, N, 1){
        B[i] = false;
        C[i] = 0;
    }
    return;
}

void dfs(int nod){
    if(B[nod]){
        return;
    }

    B[nod] = true;

    if(M_Cost < C[nod]){
        M_Cost = C[nod];
        best = nod;
    }
    int lon = Adlist[nod].size() - 1;

    cik(i, 0, lon, 1){
        int nn = Adlist[nod][i].f;
        int ncost = Adlist[nod][i].s + C[nod];

        int may = mx(nod, nn);
        int men = mn(nod, nn);

        if(S.find(mkp(men, may)) == S.end()){
            if(!B[nn]){
                C[nn] = ncost;
                dfs(nn);
            }
        }
    }
    return;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("RUTAS.IN", "r", stdin);
    freopen("RUTAS.OUT", "w", stdout);

    cin >> N;

    cik(i, 2, N, 1){
        int a, b, c; cin >> a >> b >> c;
        Adlist[a].push_back(mkp(b, c));
        Adlist[b].push_back(mkp(a, c));

        A[i] = mkp(a, b);
    }

    cik(i, 2, N, 1){
        int a = A[i].f;
        int b = A[i].s;

        int may = mx(a, b);
        int men = mn(a, b);
        S.insert(mkp(men, may));

        dfs(a);
        int nn = best;
        clean();

        dfs(nn);
        int ncost = C[best];
        clean();
        int Sol1 = ncost;

        dfs(b);
        nn = best;
        clean();
        dfs(nn);
        ncost = C[best];
        clean();
        int Sol2 = ncost;

        cout << mn(Sol1, Sol2) << " " << mx(Sol1, Sol2) << "\n";
    }

    return 0;
}
