//By Forte11
//Javier Esteban Forte Reyes
//LT7
//IPVCE Luis Urquiza Jorge
//2C Fumigacion sobre los Arboloes
#include <bits/stdc++.h>

using namespace std;

#define cik(i, a, b, c) for(int i =(a); i <=(b); i +=(c))
#define bi pair<int, int>
#define f first
#define s second
#define mkp make_pair

const int maxn = 1e4 + 5;

set<bi> S;

int A[maxn][maxn];
bi B[maxn];

int N, L, W, H, Sol;

void update(int a, int b){
    while(a <= L){
        A[a][b]++;
        a++;
    }
    return;
}

bool query1(){
    cik(a, W - 1, L, 1){
        cik(b, H - 1, L, 1){
            bool flag = false;
            cik(i, b - H, b - 1, 1){
                if(a == W - 1){
                    if(A[a][i]){
                        flag = true;
                        break;
                    }
                }
                else{
                    if(A[a][i] - A[a - W + 1][i]){
                        flag = true;
                        break;
                    }
                }
            }

            if(!flag){
                return false;
            }
        }
    }
    return true;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("FUMIGACION.IN", "r", stdin);
    freopen("FUMIGACION.OUT", "w", stdout);

    cin >> N >> L >> W >> H;

    if(L <= 1e4){
        cik(i, 1, N, 1){
            Sol = i;
            int a, b; cin >> a >> b;

            if(S.find(mkp(a, b)) != S.end()){
                continue;
            }
            S.insert(mkp(a, b));
            update(a, b);
            if(query1()){
                cout << Sol << "\n";
                return 0;
            }
        }
        cout << "-1\n";
    }

    else {
        B[0].f = -1, B[0].f = -1;
        cik(i, 1, N, 1){
            cin >> B[i].f >> B[i].s;
            bool flag = true;

            B[i + 1].f = B[i + 1].s = L + 1;
            cik(j, 0, i + 1, 1){
                int fil = abs(B[i].f - B[j].f);
                int col = abs(B[i].s - B[j].s);

                if(fil > W && col > H){
                    flag = false;
                    break;
                }
            }

            if(flag){
                cout << i << "\n";
                return 0;
            }

        }

        cout << "-1\n";
    }

    return 0;
}
