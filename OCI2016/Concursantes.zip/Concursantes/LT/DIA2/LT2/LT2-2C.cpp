/*
 name: Alben Luis Urquiza Rojas(alurquiza)
 code: LT2
 problem: "Fumigacion sobre arboles"
 complier: GCC 4.7.1
*/
#include <bits/stdc++.h>

using namespace std;

typedef pair<int,int> pii;
vector<pii> V;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("fumigacion.in","r",stdin);
    freopen("fumigacion.out","w",stdout);

    int N,L,W,H;
    cin >> N >> L >> W >> H;

    for(int e = 1;e <= N;e++){
        pii ent;
        cin >> ent.second >> ent.first;
        V.push_back(ent);

        bool continua = true;
        for(int i = 0;i + H <= L && continua;i++){
            int imax = i + H;
            for(int j = 0;j + W <= L && continua;j++){
                int jmax = j + W;
                bool flag = false;
                for(int q = 0;q < e && !flag;q++){
                    int f = V[q].first;
                    int c = V[q].second;
                    if(i < f && imax > f && j < c && jmax > c){
                        flag = true;
                        j = c - 1;
                    }
                }

                if(!flag)
                    continua = false;
            }
        }

        if(continua){
            cout << e << '\n';
            return 0;
        }

        if(clock() > CLOCKS_PER_SEC * 1.70){
            cout << -1 << '\n';
            return 0;
        }
    }

    cout << -1 << '\n';

    return 0;
}
