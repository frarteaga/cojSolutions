/*
 name: Alben Luis Urquiza Rojas(alurquiza)
 code: LT2
 problem: "Rutas mas largas"
 complier: GCC 4.7.1
*/
#include <bits/stdc++.h>

using namespace std;

const int SIZE = 5e5 + 1;
typedef pair<int,int> pii;
typedef pair<pii,int> p3i;
vector<pii> Adlist[SIZE];
p3i C[SIZE];
deque<pii> sol;
int DS[SIZE],N;

int busca(int a){
    if(DS[a] != a)
        DS[a] = busca(DS[a]);
    return DS[a];
}

void une(int a,int b){
    DS[busca(a)] = b;
}

void llena(){
    for(int i = 1;i <= N;i++)
        DS[i] = i;
}

bool Mk[SIZE];

int bfs(int ini,int fin){
    queue<pii> Q;
    Q.push(make_pair(0,ini));

    fill(Mk,Mk + N + 1,0);
    int r = 0;
    Mk[ini] = 1;

    while(!Q.empty()){
        int nod = Q.front().second;
        int cost = Q.front().first;

        Q.pop();

        for(int i = 0;i < Adlist[nod].size();i++){
            int nod_act = Adlist[nod][i].first;

            if(!Mk[nod_act]){
                if(nod_act == fin)
                    return cost + Adlist[nod][i].second;
                Mk[nod_act] = 1;
                Q.push(make_pair(cost + Adlist[nod][i].second,nod_act));
            }
        }
    }
    return r;
}

int averig(int nodo){
    vector<int> CC;
    for(int i = 1;i <= N;i++)
        if(busca(i) == busca(nodo))
            CC.push_back(i);

    int sol = 0;

    for(int i = 0;i < CC.size();i++)
        for(int j = i + 1;j < CC.size();j++)
            sol = max(sol,bfs(CC[i],CC[j]));

    return sol;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("rutas.in","r",stdin);
    freopen("rutas.out","w",stdout);

    cin >> N;

    llena();

    for(int i = 1;i < N;i++){
        int a,b,c;
        cin >> a >> b >> c;
        C[i] = make_pair(make_pair(a,b),c);
    }

    int a = 0,b = 0;
    for(int i = N - 1;i >= 1;i--){
        int n1 = C[i].first.first;
        int n2 = C[i].first.second;

        a = averig(n1);
        b = averig(n2);

        sol.push_front(make_pair(min(a,b),max(a,b)));

        int cost = C[i].second;

        une(n1,n2);

        Adlist[n1].push_back(make_pair(n2,cost));
        Adlist[n2].push_back(make_pair(n1,cost));
    }

    for(int i = 0;i < sol.size();i++)
        cout << sol[i].first << ' ' << sol[i].second << '\n';

    return 0;
}
