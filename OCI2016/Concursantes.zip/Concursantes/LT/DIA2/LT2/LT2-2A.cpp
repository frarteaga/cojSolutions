/*
 name: Alben Luis Urquiza Rojas(alurquiza)
 code: LT2
 problem: "Tablas con tres conjuntos"
 complier: GCC 4.7.1
*/
#include <bits/stdc++.h>

using namespace std;

const int SIZE = 36;
int I[SIZE * 2];
bool Mk[SIZE * 2];
int A[2][SIZE + 1],sol,N;

void back(int num){
    if(num == N * 2 + 1){
        sol++;
        return;
    }
    if(clock() > CLOCKS_PER_SEC * 1.8)
        return;
    if(!Mk[num]){
        if(I[num] <= 1){
            for(int c = 1;c <= N;c++){
                if(!A[0][c] && A[0][c - 1] < num && (A[0][c + 1] == 0 || A[0][c + 1] > num)
                  && (A[1][c] == 0 || A[1][c] > num)){
                    Mk[num] = true;
                    A[0][c] = num;
                    back(num + 1);
                    Mk[num] = false;
                    A[0][c] = 0;
                }
            }
        }
        if((I[num] == 2 || I[num] == 0)){
            for(int c = 1;c <= N;c++){
                if(!A[1][c] && A[1][c - 1] < num && (A[1][c + 1] == 0 || A[1][c + 1] > num)
                  && (A[0][c] == 0 || A[0][c] < num)){
                    Mk[num] = true;
                    A[1][c] = num;
                    back(num + 1);
                    Mk[num] = false;
                    A[1][c] = 0;
                }
            }
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("tablas.in","r",stdin);
    freopen("tablas.out","w",stdout);

    cin >> N;

    int M;
    cin >> M;

    for(int i = 1;i <= M;i++){
        int ent;
        cin >> ent;
        I[ent] = 1;
    }

    int K;
    cin >> K;

    for(int j = 1;j <= K;j++){
        int ent;
        cin >> ent;
        I[ent] = 2;
    }

    back(1);

    cout << sol << '\n';

    return 0;
}
