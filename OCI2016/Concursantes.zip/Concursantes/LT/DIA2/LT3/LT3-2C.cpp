///LT3
///Camilo Soto Rom�n | 10mo.
///IPVCE Luis Urquiza Jorge.
///DIA 2.
///Problema C:
///Fumigacion sobre los arboles.

#include <bits/stdc++.h>
#define pii pair<int,int>

using namespace std;

set<pii> fumigacion;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("FUMIGACION.IN", "r", stdin);
    freopen("FUMIGACION.OUT", "w", stdout);

    int N, W, H;
    long L;
    cin >> N >> L >> W >> H;

    for (int i = 0; i < N; i++){
            int x, y;
            cin >> x >> y;
            fumigacion.insert(pii(x,y));
    }

    cout << fumigacion.size();

    return 0;
}
