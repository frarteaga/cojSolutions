///LT3
///Camilo Soto Rom�n | 10mo.
///IPVCE Luis Urquiza Jorge.
///DIA 2.
///Problema A:
///Tablas con tres conjuntos.

#include <bits/stdc++.h>

using namespace std;
vector<int>fila1;
vector<int>fila2;
vector<int>cfila1;

bool mk[40];

int cont;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("TABLAS.IN", "r", stdin);
    freopen("TABLAS.OUT", "w", stdout);

    int N, M, K;
    cin >> N;

    cin >> M;

    while (M--){
        int a;
        cin >> a;
        mk[a] = true;
        fila1.push_back(a);
        cfila1.push_back(a);
    }

    cin >> K;

    while (K--){
        int a;
        cin >> a;
        mk[a] = true;
        fila2.push_back(a);
    }

//    if (M == K) {cout << 1; return 0;}

    X:
    fila1.clear();
    for (int i = 0; i < cfila1.size(); i++){
        fila1.push_back(cfila1[i]);
    }

    sort(fila1.begin(), fila1.end());
    sort(fila2.begin(), fila2.end());

    if (fila1.size() < fila2.size()){
        for (int i = 0; i <= N*2; i++){
            if (mk[i] == false){
                fila1.push_back(i);
                mk[i] = true;
            }
            if (fila1.size() == fila2.size()) goto C;
            else continue;
        }
        cout << cont/2;
        return 0;
        C:
            sort(fila1.begin(), fila1.end());
            sort(fila2.begin(), fila2.end());
            bool ment = true;

            for (int i = 0; i < fila1.size(); i++){
                    if (i < fila1.size() - 1){
                if (fila1[i] > fila1[i+1]) {ment = false; break;}
                if (fila2[i] > fila2[i+1]) {ment = false; break;}
                    }
                if (fila1[i] > fila2[i]) {ment = false; break;}
            }

            if (ment == true) {cont++; goto X;}
    }


//    if (aes.size() > bes.size()){
//        while(aes.size()!= bes.size())
//            bes+='*';
//    }
//
//    else if (aes.size() < bes.size()){
//        while(aes.size()!= bes.size())
//            aes+='*';
//    }
//
//sort(aes.begin(), aes.end());
//sort(bes.begin(), bes.end());
//
//do {
//    do {
//
//        bool alpha = true;
//        for (int i = 0; i < aes.size() - 1; i++){
//            if (i == 0 && (bes[i] == '*' || aes[i] == '*')) continue;
//            if (i > 0 &&  (bes[i] == '*' || aes[i] == '*')) {alpha = false; break;}
//            if (aes[i] - '0' > aes[i+1] - '0') {alpha = false; break;}
//            if (bes[i] - '0' > bes[i+1] - '0') {alpha = false; break;}
//            if (aes[i] - '0' > bes[i]   - '0') {alpha = false; break;}
//        }
//
//        if (alpha == true) cont++;
//
//
//    }while(next_permutation(aes.begin(), aes.end()));
//   sort(aes.begin(), aes.end());
//
//}while(next_permutation(bes.begin(), bes.end()));
//
//    cout << cont - 1;

    cout << cont;
    return 0;
}
