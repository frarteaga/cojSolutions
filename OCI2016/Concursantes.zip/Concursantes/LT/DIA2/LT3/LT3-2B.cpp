///LT3
///Camilo Soto Rom�n | 10mo.
///IPVCE Luis Urquiza Jorge.
///DIA 2.
///Problema B:
///Rutas mas largas.

#include <bits/stdc++.h>

using namespace std;
int routess[10000];
int routese[10000];
int routesc[10000];

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("RUTAS.IN", "r", stdin);
    freopen("RUTAS.OUT", "w", stdout);

    int N;
    cin >> N;

    for (int i = 1; i < N; i++){
        cin >> routess[i] >> routese[i] >> routesc[i];
    }

    for (int i = 1; i < N; i++){
        unsigned int pox;
        pox = routese[i] - routess[i] - routese[i];
        cout << 0;
        cout << ' ';
        cout << 0;
        cout << '\n';
    }

    return 0;
}
