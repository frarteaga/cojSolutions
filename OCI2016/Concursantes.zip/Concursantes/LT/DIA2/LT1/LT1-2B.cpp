/*
    Kedir Enrique Lluch Milanes
    Las Tunas
    IPVCE: Luis Urquiza
    LT1
    problema:B
*/
#include <bits/stdc++.h>

using namespace std;

const int maxn = 5e5 + 1;
typedef pair < int , int > ii;
//typedef pair < int , ii > i3;

int N;
vector < ii > A[maxn];
ii orden[maxn];

int a, b;

bool mk[maxn];
bool mk2[maxn];

ii F(int n, int p){
    mk[n] = true;
    int R = 0, C1 = 0, C2 = 0;
    for(int i = 0; i < A[n].size(); i++){
        int nod = A[n][i].first;
        int edge = A[n][i].second;
        if(nod != p && !mk2[nod] && !mk[nod]){
            ii k = F(nod, n);
            if(k.first > R)
                R = k.first;
            if(k.second + edge > C2)
                C2 = k.second + edge;
            if(C2 > C1)
                swap(C1, C2);
        }
    }
    if(C1 + C2 > R)
        R = C1 + C2;
    return ii(R, C1);
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("RUTAS.IN", "r", stdin);
    freopen("RUTAS.OUT", "w", stdout);

    int L;
    cin >> N;
    for(int i = 1; i <= N; i++){
        cin >> a >> b >> L;
        A[a].push_back(ii(b,L));
        A[b].push_back(ii(a,L));
        orden[i] = ii(a, b);
    }

    for(int i = 1; i <= N; i++){
        a = orden[i].first;
        b = orden[i].second;
        mk2[a] = mk2[b] = true;
        ii sola = F(a, a);
        ii solb = F(b, b);
        if(sola.first > solb.first)
            swap(sola.first, solb.first);
        cout << sola.first << " " << solb.first << '\n';
        for(int j = 1; j <= N; j++) mk[j] = false;
    }

    return 0;
}
