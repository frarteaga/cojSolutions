#include <bits/stdc++.h>

using namespace std;

const int maxm = 5e3 + 1;
const int maxn = 1e5 + 1;

bool A[maxm][maxm];

int X[maxn];
int Y[maxn];

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("FUMIGACION.IN", "r", stdin);
    freopen("FUMIGACION.OUT", "w", stdout);

    int N, L, W, H;
    cin >> N >> L >> W >> H;
    if(L >= maxm)
    {
        cout << -1;
        return 0;
    }
    for(int i = 1; i <= N; i++) cin >> X[i] >> Y[i];
    int limit = L * L, cont = 0;
    for(int sol = 1; sol <= N; sol++){
        int x = X[sol] - W + 1;
        int xx = X[sol] + W - 1;
        int y = Y[sol] - H + 1;
        int yy = Y[sol] + H - 1;
        if(x < 1)
            x = 1;
        if(y < 1)
            y = 1;
        if(xx > L)
            xx = L;
        if(yy > L)
            yy = L;

        for(int i = x; i <= xx; i++){
            for(int j = y; j <= yy; j++){
                if(!A[i][j]){
                    A[i][j] = true;
                    cont++;
                }
            }
        }
        if(cont == limit)
        {
            cout << sol;
            return 0;
        }
    }
    cout << -1;
    return 0;
}
