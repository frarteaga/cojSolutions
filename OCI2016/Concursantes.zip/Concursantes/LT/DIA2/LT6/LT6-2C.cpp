/**Dorian Armando Martinez Zamora
   IPVCE "Luis Urquiza Jorge".
   Grado 10mo.
 */
#include <bits/stdc++.h>

using namespace std;

const int MAXN = 8000;
bool field[MAXN][MAXN];
int W, H, N, L;
bool flag;
int sol;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("FUMIGACION.in", "r", stdin);
    freopen("FUMIGACION.out", "w", stdout);

    cin >> N >> L >> W >> H;

    for(int i = 1; i <= N; i++){
        int a, b;

        cin >> a >> b;

        field[a][b] = true;
    }
    for(int d = 1; d <= L; d++){
        for(int i = 1; i <= L; i++){
            for(int j = 1; j <= H; j++){
                for(int c = 1; c <= W; c++){
                    if(field[d][c] == true){
                        flag = true;
                    }
                    else if(sol < 1){
                        sol++;
                        flag = false;
                        break;
                    }
                }
            }
        }
        if(clock() > CLOCKS_PER_SEC * 1.95){
            goto IS;
        }
    }

    IS:

    cout << N - sol;

    return 0;
}
