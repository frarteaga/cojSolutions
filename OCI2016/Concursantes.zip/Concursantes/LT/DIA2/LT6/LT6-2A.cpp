/**
   Dorian Armando Martinez Zamora
   IPVCE "Luis Urquiza Jorge".
   Grado 10mo.
 */

#include <bits/stdc++.h>

using namespace std;

vector<int> sec;
vector<int> sec2;
vector<int> sec3;
int sol;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("TABLAS.in", "r", stdin);
    freopen("TABLAS.out", "w", stdout);

    int N, M;

    cin >> N;

    cin >> M;

    for(int i = 1; i <= M; i++){
        int c;
        cin >> c;
        sec.push_back(c);
    }

    int K;

    cin >> K;

    for(int i = 1; i <= K; i++){
        int c;
        cin >> c;
        sec2.push_back(c);
    }

    sort(sec.begin(), sec.end());
    sort(sec2.begin(), sec2.end());

    for(int i = 1; i <= N * 2; i++){
        if(!binary_search(sec.begin(), sec.end(), i) && !binary_search(sec2.begin(), sec2.end(), i)){
            sec3.push_back(i);
        }
    }

    for(int i = 1; i <= 2 * N; i++){
        vector<int>res1;
        vector<int>res2;
        res1.push_back(sec[0]);
        res2.push_back(sec2[0]);

        for(int j = 1; j <= 2 * N; j++){
            if(j <= sec.size()){
                if(res1[res1.size() - 1] < sec[j - 1])
                    res1.push_back(sec[j - 1]);
            }
            else{
                if(res1[res1.size() - 1] < sec3[j - 1]){
                    res1.push_back(sec3[j - 1]);
                    sec3[j - 1] = -1;
                }
            }
            if(j <= sec2.size()){
                if(res2[res2.size() - 1] < sec2[j - 1]){
                    res2.push_back(sec2[j - 1]);
                }
            }
            else{
                if(res2[res2.size() - 1] < sec3[j - 1]){
                    res2.push_back(sec3[j - 1]);
                    sec3[j - 1] = -1;
                }
            }
        }
        bool flag = false;

        for(int k = 0; k <= res1.size(); k++){
            if(res1[k] < res2[k])
                flag = true;
            else{
                flag = false;
                break;
            }
        }
        if(flag){
            sol++;
        }
        for(int i = 1; i <= N * 2; i++){
                if(!binary_search(sec.begin(), sec.end(), i) && !binary_search(sec2.begin(), sec2.end(), i)){
                    sec3.push_back(i);
                }
        }
        if(clock() > CLOCKS_PER_SEC * 1.95){
            goto IS;
        }
    }

    IS:
    cout << sol;

    return 0;
}
