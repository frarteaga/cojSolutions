#include <bits/stdc++.h>

using namespace std;
int cc;
vector<pair<int,int> > carreteras[500];
pair<pair<int,int>,int> g[501];
pair<pair<int,int>,int> h[501];
vector<int> kk;
int conta[501];


int calcost(int x){
queue<int> cola;
cola.push(x);
int cont=0;
int mk[501];
for(int i = 1; i <= 500;i++){
    mk[i]=0;
}
mk[x]=1;
conta[x]=0;
vector <int> az;
while(!cola.empty()){
   int q = cola.front();
   cola.pop();
   for(int i = 0; i < carreteras[q].size();i++){
    if(carreteras[q][i].first!=0){
           if(mk[carreteras[q][i].first]==1){
            goto q;
        }
        cola.push(carreteras[q][i].first);
        cont= max(cont,conta[q]+carreteras[q][i].second);
        conta[carreteras[q][i].first] = carreteras[q][i].second;
        mk[carreteras[q][i].first]=1;
    }
   }
}
q:
return cont;
}


void bfs(int x){
queue<int> cola;
cola.push(x);
vector <int> az;
az.push_back(x);
int mk[501];
for(int i = 1; i <= 500;i++){
    mk[i]=0;
}
while(!cola.empty()){
   int q = cola.front();
   cola.pop();
   for(int i = 0; i < carreteras[q].size();i++){
        if(mk[carreteras[q][i].first]==1){
            goto q;
        }
    if(carreteras[q][i].first!=0){
        cola.push(carreteras[q][i].first);
        az.push_back(carreteras[q][i].first);

        mk[carreteras[q][i].first]=1;
    }
   }
}
q:
int mayor=0;
for(int i = 0; i < az.size();i++){
int medio = calcost(az[i]);
        mayor = max(mayor,medio);
}
kk.push_back(mayor);
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie();
    freopen("rutas.in","r",stdin);
    freopen("rutas.out","w",stdout);
    cin >> cc;
    for(int i = 1; i < cc;i++){
            int a,b,c;
        cin >> a >> b >> c;
        carreteras[a].push_back(pair<int,int>(b,c));
        carreteras[b].push_back(pair<int,int>(a,c));
        g[i].first.first=a;
        g[i].first.second=b;
        g[i].second=c;
        h[i].first.first=b;
        h[i].first.second=a;
        h[i].second=c;
    }
    for(int i = 1; i <= cc-1;i++){
            for(int j = 0; j < carreteras[g[i].first.first].size();j++){
                    if(carreteras[g[i].first.first][j].first != 0){
           int r = carreteras[g[i].first.first][j].first;
    carreteras[g[i].first.first][j]=pair<int,int>(0,0);
    carreteras[h[i].first.first][j]=pair<int,int>(0,0);
    bfs(g[i].first.first);
    bfs(r);
    sort(kk.begin(),kk.end());
    cout << kk[0] << " " << kk[1] << '\n';
    kk.clear();
    break;
                    }
            }
    }
    return 0;
}
