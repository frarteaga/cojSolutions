#include <bits/stdc++.h>

using namespace std;
bool mat[10000][10000];
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie();
    freopen("fumigacion.in","r",stdin);
    freopen("fumigacion.out","w",stdout);
    int t,l,w,h,con=0;
    cin >> t >> l >> w >> h;
    for(int k = 1; k <= t;k++){
            bool flag =true;
    int a,b;
    cin >> a >> b;
    int s,d,f,g;
    if(a-w < 0){
        s=0;
    }
    else{
        s=a-w;
    }
    if(a+w > l){
        d=l;
    }
    else{
        d=a+w;
    }
    if(b-h < 0){
        f=0;
    }
    else{
        f=b-h;
    }
    if(b+h > l){
        g=l;
    }
    else{
        g=b+h;
    }
    for(int i = s;i <= d;i++){
    for(int j = f;j <= g;j++){
        mat[i][j]=true;
    }
    }
    for(int i = 0;i <= l;i++){
    for(int j = 0;j <= l;j++){
        if(mat[i][j]==false){
                flag = false;
        }
    }
    }
    if(flag==true){
    con = k;
        goto q;
        t = t-k;
    }
    }
    q:
        for(int i = 1; i <= t;i++){
            int trash;
            cin >> trash;
        }
    if(con>0){
        cout << con;
    }
    else{
        cout << -1;
    }
    return 0;
}
