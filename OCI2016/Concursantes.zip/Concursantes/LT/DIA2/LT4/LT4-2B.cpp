///Raul Castro Rivero
///IPVCE Luis Urquiza Jorge
///12mo Las Tunas 2B
#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> pii;
typedef pair<int, pii> pii3;

const int MAXN = 5e5 + 1;

int N;
vector<pii> ad[MAXN];
vector<pii> vs;
map<pii, bool> mk;
int dist[MAXN];
bool visited[MAXN];

void bfs(){
    queue<int> Q;
    Q.push(1);
    visited[1] = true;

    while(!Q.empty()){
        int nod = Q.front();
        Q.pop();

        for(int i = 0 ; i < ad[nod].size() ; i++){
            int nn = ad[nod][i].first;
            int nc = ad[nod][i].second;

            if(!visited[nn]){
                visited[nn] = true;
                dist[nn] = dist[nod] + nc;
                Q.push(nn);
            }
        }
    }
}

int mas_lejosde_n(int n){
    queue<pii> Q;
    Q.push(pii(n, 0));
    memset(visited, 0, sizeof visited);
    visited[n] = true;

    int mdn = n;
    int dit = 0;

    while(!Q.empty()){
        int nod = Q.front().first;
        int cc = Q.front().second;
        Q.pop();

        for(int i = 0 ; i < ad[nod].size() ; i++){
            int nn = ad[nod][i].first;
            int nc = ad[nod][i].second + cc;

            if(mk[pii(nod, nn)] == false || visited[nn])
                continue;

            if(dit < nc){
                mdn = nn;
                dit = nc;
                Q.push(pii(nn, nc));
                visited[nn] = true;
            }
        }
    }
    return mdn;
}

pii more_distant(int n){
    queue<int> Q;
    Q.push(n);
    memset(visited, 0, sizeof visited);
    visited[n] = true;

    int mdn = n;

    while(!Q.empty()){
        int nod = Q.front();
        Q.pop();

        for(int i = 0 ; i < ad[nod].size() ; i++){
            int nn = ad[nod][i].first;
            if(mk[pii(nod, nn)] == false)
                continue;
            if(dist[nn] > dist[mdn]){
                mdn = nn;
                Q.push(nn);
                visited[nn] = true;
            }
        }
    }
    return pii(mdn, mas_lejosde_n(mdn));
}

int cdist(int nod, pii otros, bool ok){
    int a = otros.first;
    int b = otros.second;
    return (dist[a] - dist[nod]) + (dist[b] - dist[nod]);
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

//    freopen("RUTAS.txt", "r", stdin);
    freopen("RUTAS.IN", "r", stdin);
    freopen("RUTAS.OUT", "w", stdout);

    cin >> N;
    for(int i = 1 ; i < N ; i++){
        int a, b, c; cin >> a >> b >> c;
        ad[a].push_back(pii(b, c));
        ad[b].push_back(pii(a, c));
        if(mk.find(pii(a, b)) == mk.end())
            mk[pii(a, b)] = mk[pii(b, a)] = true;
        vs.push_back(pii(a, b));
    }

    bfs();

    for(int i = 0 ; i < vs.size() ; i++){
        int n1 = vs[i].first;
        int n2 = vs[i].second;

        mk[vs[i]] = false;
        mk[pii(n2, n1)] = false;

        pii md2 = more_distant(n2);
        int c1 = cdist(n2, md2, 1);
        pii md1 = more_distant(n1);
        int c2 = cdist(n1, md1, 0);

        if(c1 > c2)
            swap(c1, c2);

        cout << c1 << ' ' << c2 << '\n';
    }

//    for(int i = 1 ; i <= N ; i++)
//        cout << dist[i] << '\n';

    return 0;
}
