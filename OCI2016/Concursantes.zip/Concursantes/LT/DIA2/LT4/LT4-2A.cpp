///Raul Castro Rivero
///IPVCE Luis Urquiza Jorge
///12mo Las Tunas 2A
#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> pii;

const int MAXN = 75;

int N, M, K
long long sol;
int nm[MAXN];
bool mk[3][MAXN];
//set<pii> mp;

void back(int j){
    if(j == 2 * N){
        sol++;
        return;
    }

    if(j < N)
        for(int i = 1 ; i <= N * 2 ; i++){
            if(!mk[2][i] && nm[j] < i && (mk[0][i] || (!mk[0][i] && !mk[1][i]))){
                mk[2][i] = true;
                nm[j + 1] = i;
                back(j + 1);
                nm[j + 1] = 0;
                mk[2][i] = false;
            }
        }
    else {
        int last = nm[j];
        if(j == N)
            last = 0;
        for(int i = 1 ; i <= N * 2 ; i++){
            if(!mk[2][i] && last < i && i > nm[N - j + 1] && (mk[1][i] || (!mk[0][i] && !mk[1][i]))){
                mk[2][i] = true;
                nm[j + 1] = i;
                back(j + 1);
                nm[j + 1] = 0;
                mk[2][i] = false;
            }
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

//    freopen("TABLAS.txt", "r", stdin);
    freopen("TABLAS.IN", "r", stdin);
    freopen("TABLAS.OUT", "w", stdout);

    cin >> N >> M;
    for(int i = 1 ; i <= M ; i++){
        int a; cin >> a;
        mk[0][a] = true;
    }

    cin >> K;
    for(int i = 1 ; i <= K ; i++){
        int b; cin >> b;
        mk[1][b] = true;
    }

    back(0);

    cout << sol;

    return 0;
}
