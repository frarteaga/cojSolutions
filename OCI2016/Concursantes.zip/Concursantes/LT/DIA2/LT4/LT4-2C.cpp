///Raul Castro Rivero
///IPVCE Luis Urquiza Jorge
///12mo Las Tunas 2C
#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> pii;

const int MAXN = 1e5 + 1;

long long csc = 0;
int N, M, xw, yh, answ;
set<pii> mk;
set<pii> ptos;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("FUMIGACION.IN", "r", stdin);
    freopen("FUMIGACION.out", "w", stdout);

    cin >> N >> M >> xw >> yh;
//    M++;
    csc = (M) * (M);

    if((M % xw) + (M % yh) > N)
        answ = -1;

    for(int i = 1 ; i <= N ; i++){
        int a, b; cin >> a >> b;

        if(a <= 0 || a > M || b <= 0 || b > M)
            continue;
        if(ptos.find(pii(a, b)) != ptos.end() || mk.find(pii(a, b)) != mk.end())
            continue;

        ptos.insert(pii(a, b));
        for(int x = a - xw + 1 ; x <= a + xw - 1 ; x++){
            for(int y = b - yh + 1 ; y <= b + yh - 1 ; y++)
                if(x >= 0 && x <= M && y >= 0 && y <= M && mk.find(pii(x, y)) == mk.end()){
                    mk.insert(pii(x, y));
                    if((long long)mk.size() == csc)
                        answ = i;
                }
        }


//        for(int w = a - xw + 1 ; !answ && w <= a + xw - 1 ; w++){
//            if(w < 0){ w = 0; continue;}//=0
//            else if(w <= M) break;
//            int c = mk.size();
//            for(int h = b - yh + 1 ; !answ && h <= b + yh - 1 ; h++){
//                if(h < 0){ h = 0; continue;}//=0
//                else if(h <= M) break;
//                if(mk.find(pii(w, h)) == mk.end())
//                    mk.insert(pii(w, h));
//                if(mk.size() == csc)
//                    answ = i;
//            }
//        }
    }

    if(!answ)
        answ--;
    cout << answ;

    return 0;
}
