/**
Hector Alexander Espinosa Reyes: LT-8
IPVCE: Luis Urquiza Jorge
Problema: Dia 2-B: Rutas mas largas
**/

#include <bits/stdc++.h>

using namespace std;

int MATaD[10000][10000];
bool matAd[10000][10000];
int N, cost;
pair<int, int> c[5000];

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("RUTAS.in", "r", stdin);
    freopen("RUTAS.out", "w", stdout);

    cin >> N;

    for (int i = 1; i < N; i++){
        cin >> c[i].first >> c[i].second >> cost;
        matAd[c[i].first][c[i].second] = true;
        matAd[c[i].second][c[i].first] = true;
        MATaD[c[i].first][c[i].second] = cost;
        MATaD[c[i].second][c[i].first] = cost;
    }

    int max1 = 0;
    int max2 = 0;

    for (int k = 1; k <= N; k++){
        for (int i = 1; i <= N; i++){
            for (int j = 1; j <= N; j++){
                if (matAd[i][j] || (matAd[i][k] && matAd[k][j])){
                    matAd[i][j] = true;
                }
            }
        }
    }

    for (int i = 1; i <= N; i++){
        matAd[c[i].first][c[i].second] = false;
        matAd[c[i].second][c[i].first] = false;

        for (int j = 1; j <= N; j++){
            if (matAd[c[i].first][j]){
                max1 = max(max1, MATaD[c[i].first][j]);
            }
        }

        for (int k = 1; k <= N; k++){
            if (matAd[k][c[i].second]){
                max2 = max(max2, MATaD[k][c[i].second]);
            }
        }

        cout << min(max1, max2) << " " << max(max1, max2) << '\n';
        max1 = 0;
        max2 = 0;
    }
    return 0;
}
