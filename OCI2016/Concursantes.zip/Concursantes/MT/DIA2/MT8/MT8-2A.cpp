#include <iostream>

using namespace std;

int main()
{
int n;
cout<<"introduzca la cantidad de valores de la tabla\n";
cin>>n;
int x[2][n],y[2][n],z[2][n];
cout<<"Conjunto A\n";
cin>>x[2][n];
cout<<"Cojunto B\n";
cin>>y[2][n];
cout<<"Conjunto C\n";
cin>>z[2][n];
if(x[2][n]+y[2][n]+z[2][n]<n)
cout<<"No se puede ejecutar esta tabla\n";
if(x[2][n]+y[2][n]+z[2][n]>n)
cout<<"Coloque los valores para la comparacion\n";
return 0;
}


