#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{   int n,a,b,c;
    cout << "introduzca el numero de columnas de la tabla: ";
    cin>>n;
    int x,z[2][n];
    if (n>35)
        cout << "introduzca un numero mas pequeno";
    else
    cout << "introduzca la cantidad valores del conjunto A: ";
    cin>>a;
    cout << "introduzca los cantidad valores del conjunto B: ";
    cin>>b;
    cout << "introduzca los cantidad valores del conjunto C: ";
    cin>>c;
    if(a+b+c>n*2 || a>n || b>n)
       cout <<"Error, imposible llenar la tabla";
    else
    cout << "Y con un buen informatico q me entrenara seguro q hacia el resto,introduzca un numero para cerrar el programa";
    cin>>a;




    return 0;
}

