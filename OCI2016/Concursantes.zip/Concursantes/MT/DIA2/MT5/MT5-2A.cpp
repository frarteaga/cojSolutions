#include <iostream>

using namespace std;

int main()
{   int n;
    cout<<"Introduzca la cantidad de valores en la tabala: ";
    cin>>n;
  int a[2][n],b[2][n],c[2][n];
    do
    {cout<<"Introduzca los valores de A: ";
    cin>>a[2][n];
    cout<<"Introduzca los valores de B: ";
    cin>>b[2][n];
    cout<<"Introduzca el valor de C: ";
    cin>>c[2][n];
    cout<<"\n\n";
    if(a[2][n]+b[2][n]+c[2][n]>n)
    cout<<"Esta tabla no puede ejecutarse";
    cout<<"\n\n";
    if(a[2][n],b[2][n],c[2][n]<n)
    cout<<"Coloque la cantidad de datos para la comparacion en tabla\n";

    }while(a[2][n]<500,b[2][n]<500,c[2][n]<500);
    return 0;
}
