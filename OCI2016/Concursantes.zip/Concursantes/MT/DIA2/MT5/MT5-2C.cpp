#include <iostream>
using namespace std;

int main()
{ int a[1000000000][1000000000]{1<1000000000};

    return 0;
}
