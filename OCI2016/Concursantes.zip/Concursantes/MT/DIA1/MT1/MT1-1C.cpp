#include <iostream>
#include <stdio.h>
#include <cstdio>
using namespace std;

int main()
{cout << "ROBOT.IN" << endl;
int n,m ;
cin>>n,m ;
cout << "ROBOT.OUT" ;
     return 0;
}
