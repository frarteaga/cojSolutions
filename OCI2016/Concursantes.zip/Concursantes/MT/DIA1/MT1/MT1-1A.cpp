#include <iostream>
#include <stdio.h>
#include <cstdio>
using namespace std;

int main()
{
cout << "HEXAGONO.IN" << endl;
int n,m,s,p,q ;
cin>>n,m,s,p,q ;
cout << "HEXAGONO.OUT" ;
 return 0;

}
