#include <iostream>
#include <stdio.h>
#include <cstdio>
using namespace std;

int main()
{cout << "CUENTAS.IN" << endl;
int n,l,s;
cin>>n,l,s ;
cout << "CUENTAS.OUT" ;
    return 0;
}
