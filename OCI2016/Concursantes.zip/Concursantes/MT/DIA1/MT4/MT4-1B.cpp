#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{

 printf ("**********************\n*A Quien revise esto**\n**********************\nPor favor, disculpe usar este medio para dar el msj de que alumnos como nosotros estamos interesados en querer aprender mas acerca de la informatica como ciencia ya que este es sin lugar a dudas el futuro de las siguientes generaciones");
 printf("y creemos q los alumnos de la Carlos Marx tienen la capacidad y el talento para hacer mucho mas q esto. Mi pregunta es la siguiente: por que no conozco al entrenador nacional ni provincial. Por que estando en un concurso nacional y se solamente sumar dos numeros. Quien se da cuenta de esto. Por que no puedo saber mas cosas si es por eso que estoy en una vocacional donde supuestame estan las mejor condiciones nacional a nivel de Preuniversitario (incluyendo preparacion para concursos). Por que tengo que estudiar por un libro sin que nadie me explique nada. Por que menospresiar a la informatica si es tan importante en nuestros dias. Esperando que esto signifique mas q unos caracteres en una pantalla les deseo buen dia.  \n\n\n\n" );

 return 0;
}
