#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{


    int N,M,S,P,Q; //Denotando Variables//
    scanf ("%d %d %d %d",&N, &M, &S, &P, &Q);
    //Creo q deberia hacer un arreglo bidimensianal q me permitiria encontrar un numero en la secuencia dada pero no estoy seguro d como hacerlo//


    return 0;
}
