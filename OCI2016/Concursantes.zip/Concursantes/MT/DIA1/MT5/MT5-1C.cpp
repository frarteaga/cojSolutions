#include <iostream>

using namespace std;
int main()
{ cout<<"Introduzca las casillas para el movimiento\n";
int A[5][5]{1,2,3,4,5}{6,7,8,9,10}{11,12,13,14,15}{20,21,22,23,24}{25,26,27,28,29};
cin>>m>>n;
cout<<[m]<<[n];
return 0;
}
