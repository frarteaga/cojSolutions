#include <iostream>
using namespace std;


int main()
{cout<<"Hexagono\n";
int h[5][3]{5,6,7,16,17,18,8,15,19,9,14,20,10,13,12},m,n;
cin>>m>>n;
cout<<"La direccion de la fila P celda Q es:"<<h[5][3];

return 0;
}
