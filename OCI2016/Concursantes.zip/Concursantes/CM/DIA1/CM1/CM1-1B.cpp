/**
Name: Niuber Ramirez Grey
Problem: B:Cuentas
Grade: 12
IPVCE Maximo Gomez
Camaguey
**/

#include <bits/stdc++.h>

using namespace std;

#define MAX 30005
char r[MAX][205];

int main (){

    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen ("CUENTAS.in", "r", stdin);
    freopen ("CUENTAS.out", "w", stdout);

    int n,s,l;
    long long sol = 0;
    cin>>n>>l>>s;

    cin>>r[0];
    for (int i = 1 ;i < n;i++){
        cin>>r[i];
            for (int j = i-1 ; j >=0 ; j--){
                int y = 0;
                int k = 0;
                while (y!=2 and k<l){
                    if (r[i][k]!=r[j][k])y++;
                    k++;
                }
              if (y<2)sol++;
            }
    }

    cout<<sol;


return 0;

}
