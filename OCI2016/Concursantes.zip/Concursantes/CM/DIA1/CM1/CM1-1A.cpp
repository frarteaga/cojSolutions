/**
Name: Niuber Ramirez Grey
Problem: B:Cuentas
Grade: 12
IPVCE Maximo Gomez
Camaguey
**/


#include <bits/stdc++.h>

using namespace std;

int main (){

    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen ("HEXAGONO.in", "r", stdin);
    freopen ("HEXAGONO.out", "w", stdout);
    pair <long long, long long> ll;
    long long n,m,s,p,q,niuber;
    cin>>n>>m>>s>>p>>q;
    ll.first = 1;
    if (n>p)
    ll.second = (n*2-1) - (n-p);
    if (n<p)
    ll.second = (n*2-1) - (p-n);
    if (n==p)ll.second = (n*2-1);
    long long k = n;
    long long o =1;
    long long sum = s;
    while ((ll.first!= q and  ll.second!=q) and o!=p){
        ll.first++;
        ll.second--;
        o++;
        sum += (k*2) + (((k - 1) * 2 -1) * 2);
        k--;
    }

    if (k==1 and sum+1 <=m+s+1)cout<<sum;
    if (k==1 and sum+1 >m+s+1)cout<<0;
    if (k>1){
            int io = 0;
        long long yu = 1, dota = n-k+1, lol = n-k+1;
        if (dota==p){
            io = 1;
        while (yu<=k){
            yu++;
            sum++;
            if (lol == q)break;
            lol++;
           }
            if (sum+1 <=m+s+1)
                    cout<<sum-1;
            else cout<<0;
        }
        sum+=k;int yulo=0;
        if (io==0){
        yulo =1;
        lol=lol+k-1;
        dota = ((k-1)*2)-1;
        yu = n-k+1;
        while (dota--){
            yu++;
            sum++;
            if (yu==p and q>=k+1){
                if (sum+1 <=m+s+1)
                    cout<<sum-1;
            else cout<<0;
            }
        }
        }

        if (io == 0 and yulo ==0){
        dota = n - k +1;
        lol = n-k+k;
        if (dota + (((k-1)*2)-1)+1 == p){
          io = 5;
          while (lol>=n-k+1){
            sum++;
            if (lol==q){
                    if (sum+1 <=m+s+1)
                    cout<<sum-1;
            else cout<<0;

            }

            lol--;

          }

        }
        }
        sum+=k;

        if (io==0 and yulo==1){
            lol = n-k+1;
            yu = n*2-1-lol;
            while (lol<=n*2-1){
                lol++;
                sum++;
                if (yu==p and q<k+1){
                     if (sum+1 <=m+s+1)
                    cout<<sum-1;
            else cout<<0;
                }
                yu--;
            }
        }


    }

cout<<"\n";







    ll.first = 1;
    if (n>p)
    ll.second = (n*2-1) - (n-p);
    if (n<p)
    ll.second = (n*2-1) - (p-n);
    if (n==p)ll.second = (n*2-1);
    while (sum<=s+m+1){
        sum += (k*2) + (((k - 1) * 2 -1) * 2);
        k--;
    }

    sum-=(k*2) + (((k - 1) * 2 -1) * 2)+1;
    if (k==0)cout<<n<<" "<<n;
    long long qwer=(m+s)-sum-1;
    if (qwer<=k){
        cout<<k<<" "<<k+k-qwer+1;
    }
    qwer-=k;
    if ((k-1)*2-1>=qwer and qwer!=0 and qwer>0){
        int loco =k+k-1+qwer;
        cout<<k+qwer<<" "<<loco;
    }
    qwer-=(k-1)*2-1;
    if (qwer<=k and qwer!=0 and qwer>0){
        int loco = k+k-1;
        cout<<n-k+n<<" "<<loco-qwer+1;
    }
    qwer-=k;
     if (qwer<=k and qwer!=0 and qwer>0){
        int loco = n-k+n;
        cout<<loco-qwer<<" "<<k;
    }



return 0;

}
