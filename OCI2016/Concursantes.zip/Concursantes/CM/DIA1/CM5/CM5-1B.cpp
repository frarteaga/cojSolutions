/*Reynier L�pez Mena 11no
IPVCE M�ximo G�mez B�ez*/

#include <bits/stdc++.h>

using namespace std;
char p[6000001];
int main()
{
    freopen("CUENTAS.in","r",stdin);
    freopen("CUENTAS.out","w",stdout);
    int N,L,S,b=0,d,e=0;
    cin>>N>>L>>S;
    for (int i=0;i<N*L;i++){
       cin>>p[i];
     }
    for (int i=0;i<N*L;i++){
      for (int k=1;k<=N-1;k++){
       if(p[i]==p[i+(L*k)]){
       for(int j=1;j<L-1;j++){
         d=i+j;
           if (p[d]==p[d+(L*k)]){
            b++;}
            }
            if(b==L-2){
             e++;}
           }
           b=0;
          }
          if(i==1){
             i=L-1;}
          if((i-1)%L==0){
             i=(i-1)+(L-1);}
         }
        cout<<e;
    return 0;
}
