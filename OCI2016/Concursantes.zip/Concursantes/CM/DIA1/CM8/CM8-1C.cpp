#include <bits/stdc++.h>
//Kevin Reyes Perez. 10MO_grado. IPVCE Maximo Gomez Baez.
using namespace std;

int main()
{
    freopen("ROBOT.in","r",stdin);
    freopen("ROBOT.out","w",stdout);
        int N;
        for (int i=0; i<N ;i++ ){
            cin>>N;
            int M,K;
            for (int j=0; j<M ;j++ ){
                for (int p=0; p<K ;p++ ){
                    cin>>M>>K;
                    string s;
                    cin>>s;
                    if(s.size()=='#')
                    cout<<"R";
                }
            }
        }
    return 0;
}
