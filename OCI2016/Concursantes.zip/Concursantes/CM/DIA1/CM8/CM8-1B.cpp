#include <bits/stdc++.h>
//Kevin Reyes Perez. 10grado. IPVCE Maximo Gomez Baez.
using namespace std;

int main()
{
    freopen("CUENTAS.in","r",stdin);
    freopen("CUENTAS.out","w",stdout);
    int N;
    cin>>N;
    for (int i=0; i<N ; i++ ){
        int L,S;
        for (int j=0; j<L ;j++ ){
            cin>>L>>S;
        if(S==2){
            while(1){
             string c;
             cin>>c;
             c='0' && '1';
             int h,cont=0;
             h=c.size();
             for (int p=0; p<h+1 ;p++ ){
                    cont++;
             }
             cout<<cont;
                    }
            }
            else
            if(S==64){
                while(1){
                    string c;
                    cin>>c;
                    if(c==c){
                        int cont=0;
                        cont++;
                        cout<<cont;
                    }
                }
            }
        }
    }
    return 0;
}
