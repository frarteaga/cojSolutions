///  Jose A. Padilla Morani
///  IPVCE Maximo Gomez Baez
///  12grado
///  Problema 1C
///  CODIGO: CM9

#include <bits/stdc++.h>
using namespace std;
int n,m,k;
char field [205][205];
bool visited[205][205];
int h[] = {1,0};
int g[] = {0,1};
int camino[105];
stack <int> pila;
bool ind = false;
void bfs(){
    int x=0,y=0;
    bool ind2 = false;
    while(true){
        for(int i=k-1;i>=0;i--){
            x += h[camino[i]];
            y += g[camino[i]];
            if(x>n-1 || y>m-1){
                for(int j=k-1;j>=0;j--){
                    if(camino[j]==0)
                        cout<<"D";
                    if(camino[j]==1)
                        cout<<"R";
                }
                ind = true;
                break;
            }
            if(field[x][y]=='#'){
             ind2 =true;
                break;
            }
        }
              if(ind2)
                break;
              if(ind)
                break;
    }
}
void dfs(int x, int y ,int pasos){
     if(pasos==k){
        int cont=0;
        while(!pila.empty()){
            camino[cont++] = pila.top();
            pila.pop();
        }


        bfs();
        for(int i=cont-1;i>=0;i--)
            pila.push(camino[i]);
        if(ind)
            exit(0);
        memset(camino,0,sizeof(camino));

        pila.pop();
        visited[x][y] = false;
        return;
     }
     visited[x][y]=true;
     for(int i=0;i<2;i++){
        int new_x = x + h[i];
        int new_y = y + g[i];
        if(!visited[new_x][new_y] && field[new_x][new_y]!='#'){
            pila.push(i);
            dfs(new_x,new_y,pasos+1);
        }
     }
     pila.pop();
     visited[x][y] = false;
}
int main (){
    freopen("robot.in","r",stdin);
    freopen("robot.out","w",stdout);
    scanf("%d %d %d", &n, &m,&k);

    for(int i=0;i<n;i++){
         char cadena[205];
            cin>>cadena;
        for(int j=0;j<m;j++){
            field[i][j] = cadena[j];
        }
    }
    dfs(0,0,0);

return 0;
}

/*
3 4 3
012#
#045
6###
*/
