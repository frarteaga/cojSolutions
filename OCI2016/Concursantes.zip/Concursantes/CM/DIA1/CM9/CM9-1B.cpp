///  Jose A. Padilla Morani
///  IPVCE Maximo Gomez Baez
///  12grado
///  Problema 1B
///  Codigo: CM9

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,l,t,cant,cont,i,j;
set <string> s;
set <string>::iterator it;
set <string>::iterator it2;

int main (){
    freopen("cuentas.in","r",stdin);
    freopen("cuentas.out","w",stdout);

scanf("%lld %lld %lld", &n,&l,&t);
for(i =0;i<n;i++){
    string cadena;
    cin>>cadena;
    s.insert(cadena);
}
i =0 ,j =0;
for(it=s.begin();it!=s.end();it++){
    string temp = *it;
    for(it2 = s.begin(); it2!=s.end() ; it2++){
        if(i>j){
           j++;
            continue;
        }
        if(*it==*it2){
           j++;
            continue;
        }
        string temp2 = *it2;
        for(int k=0;k<l;k++){
            if(temp [k]!= temp2[k])
               cont++;
        }
        if(cont==1)
            cant++;
        cont=0;
    j++;
    }
    j=0;
    i++;
}
printf("%lld", cant);
return 0;
}
/*
4 3 64
Fax
fax
max
mac
*/
/*
4 4 64
ARPA
BBPA
CRPE
ZRPA
*/
/*
2 8 64
IslaRed1
2IslaRed
*/
