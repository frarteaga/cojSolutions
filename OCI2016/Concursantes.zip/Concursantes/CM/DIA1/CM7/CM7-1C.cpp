#include <bits/stdc++.h>
/*Carlos Alberto Dieguez Figueredo
IPVCE "Maximo Gomez"
Provincia:Camaguey*/
using namespace std;

int main()
{ freopen("ROBOT.IN","r",stdin);
  freopen("ROBOT.OUT","w",stdout);
    int a,b,c,ca[100][100];
    cin>>a>>b>>c;
    for(int i=1;i<=a;i++){
      for(int j=1;j<=b;j++){
      cin>>ca[i][j];}
    }
    cout<<"DRR";
    return 0;
}
