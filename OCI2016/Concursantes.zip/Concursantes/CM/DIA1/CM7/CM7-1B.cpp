#include <bits/stdc++.h>
/*Carlos Alberto Dieguez Figueredo
IPVCE "Maximo Gomez"
Provincia:Camaguey*/
using namespace std;

int main()
{freopen("CUENTAS.IN","r",stdin);
freopen("CUENTAS.OUT","w",stdout);
   int a,b,c,arr[100][100];
   cin>>a>>b>>c;
  for (int i =1;i<=a;i++){
    for (int j =1;j<=1;j++){
        cin>>arr[i][j];
    }
  }

cout<<a;
    return 0;
}
