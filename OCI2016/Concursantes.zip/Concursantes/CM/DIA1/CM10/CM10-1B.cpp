///Christian Sanchez 10mo grado
#include <bits/stdc++.h>

using namespace std;

int main()
{
freopen("CUENTAS.IN","r",stdin);
freopen("CUENTAS.OUT","w",stdout);

int nc,t,alfa,similares=0;
cin>>nc>>t>>alfa;
string cuenta,as[500];
int f,ae[500];
for(int i=0;i<nc;i++){
 if(alfa==2){
cin>>f;
ae[i]=f;
 }else{
    cin>>cuenta;
    as[i]=cuenta;
 }
}

if(alfa==2){
        int g=2-nc;
    for(int i=0;i<nc;i++){
            for(int j=1;j<nc;j++){
               int a,b,d,e;
                    int c=0;
                a=ae[i];
                b=ae[j];
               for(int h=0;h<t;h++){
                a=a/10;
                b=b/10;
                d=a%10;
                e=b%10;
                if(d!=e){
                    c++;
                }
            }
             if(c==1){
              similares++;
               }
            }
    }
    cout<<similares+g;
}else{
    int g=3-nc;
for(int i=0;i<nc;i++){
    for(int j=1;j<nc;j++){
            int cont=0;

        string a,b;
        int d,e;
        a=as[i];
        b=as[j];
    for(int h=0;h<a.size();h++){
        if(a[h]>='A'&&a[h]<='Z')
            d=a[h]-'A';
        else{
            d=a[h]-'a';
        }
        if(b[h]>='A'&&b[h]<='Z')
            e=b[h]-'A';
        else{
            e=b[h]-'a';
        }
        if(d!=e)
            cont++;
    }
    if(cont==1){
        similares++;
    }
    }
}
cout<<similares+g;
}

    return 0;
}
