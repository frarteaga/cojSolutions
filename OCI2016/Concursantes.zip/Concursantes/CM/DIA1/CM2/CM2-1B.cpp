// Alain Alavarez Lopez 10mo
// IPVCE Maximo Gomez Baez
#include <bits/stdc++.h>

using namespace std;

vector<string> st;

int main()
{
    freopen("CUENTAS.IN", "r",stdin);
    freopen("CUENTAS.OUT", "w",stdout);
    int n,l,a, k = 0;
    cin>>n>>l>>a;
    for (int i = 0; i < n; i++){
        string h;
        cin>>h;
        st.push_back(h);
    }
    for (int i = 0; i<n;i++){
        int d = 0;
        for (int j = 0; j < n; j++){
            for (int o = 0;o < l; o++){
                if (i!=j)
                if (st[i][o] != st[j][o]){
                   d++;
                }
            }
            if (d == 1){
                k++;
                //break;
            }
        }
    }
    cout<<k;
    return 0;
}
