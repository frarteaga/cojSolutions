// Alain Alavarez Lopez 10mo
// IPVCE Maximo Gomez Baez
#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("HEXAGONO.IN", "r",stdin);
    freopen("HEXAGONO.OUT", "w",stdout);
    long long n,m,l,x,y;
    cin>>n>>m>>l>>y>>x;
    long long t = n*(2*n)+1;
    //cout<<t<<"\n";
    long long p = t-x*y;
    cout<<p+l<<"\n";
    cout<<n+1<<" "<<t-m;
    return 0;
}
