/*Alain Alvarez Lopez 10mo
  IPVCE Maximo Gomez Baez
*/
#include <bits/stdc++.h>

using namespace std;

char mat[205][205];
//bool matb[205][205];
int n,m,c, sm = 0;

string path(int x,int y,string p, int s){
   s+=mat[y][x]-'0';
   //cout<<s<<"\n";
   if(x < 0 || x >= m-1 || y >= n-1 || y < 0){
    return p;
   }
   int ps = p.size();
   if (ps >= c){
    return p;
   }
   if (mat[y][x+1] != '#' && mat[y+1][x]-'0' < mat[y][x+1]-'0'){
     p.push_back('R');
     return path(x+1,y,p,s);
   }
   if (mat[y+1][x] != '#'){
     p.push_back('D');
     return path(x,y+1,p,s);
   }
   return p;
}

int main()
{
    freopen("ROBOT.IN", "r",stdin);
    freopen("ROBOT.OUT", "w",stdout);
    cin>>n>>m>>c;
    for (int i = 0; i < n; i++){
        for (int e =0;e< m; e++){
            cin>>mat[i][e];
            /*if (mat[i][e] == '#')
                matb[i][e] = true;*/
        }
    }
    int s = 0;
    string h;
    cout<<path(0,0,h, s);
    return 0;
}
