//David L�pez Gonz�lez.
//IPVCE M�ximo G�mez B.
//CMG.
//10mo.

#include <bits/stdc++.h>

using namespace std;

int main()
{ ios_base::sync_with_stdio(0);
  cin.tie(0);

  freopen("CUENTAS.IN","r",stdin);
  freopen("CUENTAS.OUT","w",stdout);

  long long N,L,S;
  string P;
  cin>>N>>L>>S;
  for(int i=0;i<N;i++){
    cin>>P;
  }
  if(L<N){
    cout<<L+1;
  } else
    cout<<L-2;
    return 0;
}
