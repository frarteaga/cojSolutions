//David L�pez Gonz�lez.
//IPVCE M�ximo G�mez B.
//CMG.
//10mo.

#include <bits/stdc++.h>

using namespace std;

int main()
{ ios_base::sync_with_stdio(0);
  cin.tie(0);

  freopen("ROBOT.IN","r",stdin);
  freopen("ROBOT.OUT","w",stdout);

  long long N,M,K,L;
  cin>>N>>M>>K;
  for(int i=0;i<N;i++){
    cin>>L;
    if(L/2==3){
    cout<<"D";
  }else
    cout<<"R";
  }
    return 0;
}
