//David L�pez Gonz�lez.
//IPVCE M�ximo G�mez B.
//CMG.
//10mo.

#include<bits/stdc++.h>
using namespace std;

int main()
{ ios_base::sync_with_stdio(0);
  cin.tie(0);

  freopen("HEXAGONO.IN","r",stdin);
  freopen("HEXAGONO.OUT","w",stdout);

  long long N,M,S,P,Q;
  cin>>N>>M>>S>>P>>Q;
  cout<<M+2<<endl;
  cout<<N+1<<" "<<N;
    return 0;
}
