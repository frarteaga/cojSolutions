//Karel D�az Vergara
#include <bits/stdc++.h>
//Maximo Gomez Baez
//Grupo:C1
using namespace std;
int main()
{
    freopen ("CUENTAS.IN","r",stdin);
    freopen  ("CUENTAS.OUT","w",stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);
   int a,b,c;
   cin>>a>>b>>c;
   char p[b*a];
   int j=b;
   int o=0;
   for(int i=0;i<a;i++){
    char s[201];
    cin>>s;
    int g=0;
   for(int y=o;y<b;y++){
     p[y]=s[g];
     g++;
   }
   o+=j;
   b+=b;

   }
   int u=j;
   int h3=j;
   int v8=0;
   int g=0;
   int con=0;
   for(int y=1;y<a;y++){
    int d9=a-y;
    while(d9>0){
        for(int n=g;n<j;n++){
            for(int m=n+u;m<1000;m++){
                if(p[n]!=p[m]){
                    con++;
                    break;
                }
                else
                    break;
            }
        }
        if(con==1)
            v8++;
        d9--;
        u+=h3;
    con=0;
    }
    g=0;
    j+=h3;
    g+=h3*y;
    u=0;
    if(y==a-2)
    u+=(h3*y)-h3;
    else
    u+=h3*y;
   }
cout<<v8;



    return 0;
}
