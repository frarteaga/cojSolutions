/**
Niuber Ramirez Grey
CM1
FUMIGACION
12 grado

**/

#include <bits/stdc++.h>

using namespace std;

typedef pair<long long, long long> ll;
vector <ll> g;
int main (){

    freopen ("FUMIGACION", "r", stdin);
    freopen ("FUMIGACION", "w", stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int n,w,h,x,y,d,sol = 0;
    cin>>n;
    long long l;
    cin>>l>>w>>h;

    for (int i = 1 ;i<=n;i++){
        cin>>x>>y;
        g.push_back(make_pair(x,y));

    }
    long long asd = 0;
    for (int i = 0 ;i<g.size();i++){
        asd += g[i].first;
        asd -= g[i].second;
        if (asd > 0) d =i;
        if (i>g.size()){sol++;
            for (int j = 1 ;j <=g.size();j++){
                for (int o = 1 ;o<g.size();o++){
                    if (g[o].first + g[j].first- g[i].first>0)d=o;
                    if (g[o].first + g[i].first- g[j].first>=0)d=j;
                    if (g[j].first + g[i].first- g[o].first<=0)d=i;
                    if (g[j].first + g[i].first- g[o].first==0)d=o;
                    if (g[o].first + g[j].first- g[i].first<0)d=i;
                    if (g[i].first+g[o].first- g[j].first<=0)d=o;
                }
            }


        }

    }

    if (sol==0)cout<<-1;
    else cout<<d;
return 0;
}
