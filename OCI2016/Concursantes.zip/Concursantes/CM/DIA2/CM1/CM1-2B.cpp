/**
Niuber Ramirez Grey
CM1
Rutas
12 grado

**/

#include <bits/stdc++.h>

using namespace std;

#define maxnodes 500005
typedef pair <int, int > ii;
vector <ii> g[maxnodes];
bool visited[maxnodes];
int h, b;
long long d[maxnodes];

void bfs(int a){
    h = maxnodes;
    memset (visited, 0 ,sizeof visited);
    queue <int> q;
    q.push(a);
    while (!q.empty()){
        int lol = q.front();
        q.pop();
        if (visited[lol]==0){
            visited[lol]=1;
            if (h>g[lol].size()){
                h = g[lol].size();
                b = lol;
            }

            for (int i = 0 ; i<g[lol].size();i++){
                    if (g[lol][i].first!=0)
                q.push(g[lol][i].first);
            }


        }

    }
}
int main (){

    freopen ("RUTAS.IN", "r", stdin);
    freopen ("RUTAS.OUT", "w", stdout);

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    queue <ii> Q;
    int n,v,u,w;
    cin>>n;
    for (int i = 2 ;i<= n ;i++){
        cin>>u>>v>>w;
        Q.push(make_pair(u,v));
        g[u].push_back(make_pair(v,w));
        g[v].push_back(make_pair(u,w));
    }

    while (!Q.empty()){
        int o = Q.front().first;
        int p = Q.front().second;
        Q.pop();

        for (int i = 0 ;i<g[o].size();i++){
            if (g[o][i].first==p){
                g[o][i].first=0;
                break;
            }
        }

        for (int i = 0 ;i<g[p].size();i++){
            if (g[p][i].first==o){
                g[p][i].first=0;
                break;
            }
        }
        long long sol = 0;
        bfs(p);

        priority_queue <ii> F;
        for (int i = 1 ;i<=n ;i++){
            d[i] = 0;
            visited[i] = 0;
        }
        F.push(make_pair(0,b));
        while (!F.empty()){
            u = F.top().second;
            visited[u] = 1;
            int dist = F.top().first;
            F.pop();
            if (dist>=d[u]){
                for (int i = 0 ;i<g[u].size();i++){
                    w = g[u][i].second;
                    v = g[u][i].first;
                    if (w+d[u]>d[v] and visited[v]==0 and v!=0){
                        d[v] = w + d[u];
                        sol = max(sol,d[v]);
                        F.push(make_pair(d[v],v));
                    }
                }

            }


        }

        bfs (o);
        long long wow = 0;
        for (int i = 1 ;i<=n ;i++){
            d[i] = 0;
            visited[i] = 0;
        }
        F.push(make_pair(0,b));
        while (!F.empty()){
            u = F.top().second;
            visited[u] = 1;
            int dist = F.top().first;
            F.pop();
            if (dist>=d[u]){
                for (int i = 0 ;i<g[u].size();i++){
                    w = g[u][i].second;
                    v = g[u][i].first;
                    if (w+d[u]>d[v] and visited[v]==0 and v!=0){
                        d[v] = w + d[u];
                        wow = max(wow,d[v]);
                        F.push(make_pair(d[v],v));
                    }
                }

            }


        }
        if (sol>=wow)cout<<wow<<" "<<sol<<"\n";
        else cout<<sol<<" "<<wow<<"\n";
    }


return 0;
}

/*
5
1 2 2
2 3 1
2 4 2
1 5 3


6
1 6 3
1 2 4
6 5 6
3 5 6
3 4 7
*/
