/**
Niuber Ramirez Grey
CM1
Tablas
12 grado

**/

#include <bits/stdc++.h>

using namespace std;

int sol[80];

int main (){

    freopen ("TABLAS.IN", "r", stdin);
    freopen ("TABLAS.OUT", "w", stdout);

    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int n, A[80], B[80],a,b,C[80],D[80],E[80];
    bool s[80];
    memset (s, 0 , sizeof s);
    cin>>n>>a;
    for (int i = 1 ;i<=a ;i++){
        cin>>A[i];
        s[A[i]] = 1;
        D[i]= A[i];
    }
    cin>>b;
    for (int i = 1 ;i<=b ;i++){
        cin>>B[i];
        s[B[i]] = 1;
        E[i] = B[i];
    }
    sort (A + 1, A + 1 + a);
    sort (B + 1, B + 1 + b);
    int m =1;
    for (int i = 1 ;i<=2*n ; i++){
        if (s[i]==0){
            C[m] = i;
            m++;
        }
    }

    int y = 1,a1 = a,b1= b;
    while (a1!=n){
        a1++;
        D[a1] = C[y];
        y++;
    }
    while (b1!=n){
        b1++;
        E[b1] = C[y];
        y++;
    }
    sort (D + 1, D + 1 +n);
    sort (E + 1, E + 1 +n);
    int loco = 0;
    for (int i = 1; i<=n;i++){
        if (D[i]>E[i]){loco++;cout<<D[i]<<" "<<E[i]<<endl;}
    }
    if (loco!=0)cout<<-1;




    else {
        for (int i =1 ;i<m;i++){
            if (C[i]<A[a]){a++;A[a]=C[i];C[i]=0;}
        }
        if (a<b){
            int mynameisniuber=1;
        while (a!=b){
            if (C[mynameisniuber]!=0){
                a++;
                A[a] = C[mynameisniuber];
                C[mynameisniuber] = 0;
            }
        }
        }
        sort (A + 1, A+1+a);

        for (int i = 1 ;i<m;i++){
            if (C[i]!=0){
                for (int j = 1 ;j <=b;j++){
                    if (B[j]>C[i] and B[j-1]<C[i] and A[j-1]<C[i])sol[j-1]++;
                }
            }
        }

        for (int i = 1 ;i<m;i++){
            if (C[i]!=0){
                if (C[i]>B[b])sol[b+1]++;
            }
        }
        int jkl = 0;
        for (int i = 1 ;i<=n;i++){
            if (i>b)jkl+=sol[i]/2;
            else
            jkl+=sol[i];
        }
        cout<<jkl;
        }

return 0;
}
