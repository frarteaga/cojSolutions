#include <bits/stdc++.h>

using namespace std;
int ca[70];
int cb[70];
int cc[70];
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);
    int n;
    cin>>n;
    int a,b;
    cin>>a;
    for(int i=0;i<a;i++){
        int j;
        cin>>j;
        ca[i]=j;
    }
    cin>>b;
    for(int p=0;p<b;p++){
        int h;
        cin>>h;
        cb[p]=h;
    }
    int u=0,g=0;
    for(int k=1;k<=n*2;k++){
        for(int l=0;l<a;l++){
            if(ca[l]==k)
                g++;
        }
        for(int l=0;l<b;l++){
            if(cb[l]==k)
                g++;
        }
        if(g==0){
            cc[u]=k;
            u++;
        }
        g=0;

    }
    int w=0;
    sort(ca,ca+a);
    sort(cb,cb+b);
    sort(cc,cc+u);
    for(int q=0;q<u;q++){
    for(int l=0;l<a;l++){
        if(cc[q]<ca[l] && cc[q]>ca[l+1] && cc[q]<cb[l])
            w++;
        else if(cc[q]<ca[l] && cc[q]<cb[l]){
        w++;
        break;
        }
        }
    }
    for(int q=0;q<u;q++){
    for(int l=0;l<b;l++){
        if(cc[q]<cb[l] && cc[q]>cb[l+1] && cc[q]>ca[l])
            w++;
        else if(cc[q]<cb[l] && cc[q]>ca[l]){
        w++;
        break;
        }
    }
    }
    cout<<w/2;


    return 0;
}
