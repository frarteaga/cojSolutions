#include <bits/stdc++.h>
/*Carlos Alberto Dieguez Figueredo
Camaguey
IPVCE MAximo Gomez */
usin4g namespace std;

int main()
{
    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);
    int n,a,b,d=0;
    cin>>n;
    cin>>a;
    for(int i=0;i<=a;i++){
        cin>>i;
    }
   cin>>b;
    for(int i=0;i<=b;i++){
        cin>>i;
    }
    d=(a+b)/2;
    cout<<d;

    return 0;
}
