/// Jose A. Padilla Morani
/// IPVCE Maximo Gomez Baez
/// 12 grado
/// Problema fumigacion

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,l,w,h,x,y;
ll field[10000][10000];
bool visited[10000][10000];
bool ind;
void build(){
    for(ll i=1;i<=l;i++){
        for(ll j=1;j<=l;j++){
            field[i][j] += field[i-1][j] + field[i][j-1] - field[i-1][j-1];
        }
    }
}

void update(ll x, ll y){
    for(ll i=x;i<=l;i++){
        for(ll j=y;j<=l;j++){
            field[i][j]--;
        }
    }
}

void inicio(){
    for(ll i=0;i<=l;i++){
        for(ll j=0;j<=l;j++){
            field[i][j]=1;
        }
    }
}

bool query(){
    //cout<<"asd";
    for(ll i=w;i<=l;i++){
        for(ll j=h;j<=l;j++){
            ll valor = field[i][j] - field[i][j-h] - field[i-w][j] + field[i-w][j-h];
            //cout<<valor<<"<----\n";
            if(valor>=w*h)
                return false;

        }
    }
    return true;
}

int main (){
    freopen("fumigacion.in","r",stdin);
    freopen("fumigacion.out","w",stdout);

   scanf("%lld %lld %lld %lld", &n,&l,&w,&h);
   l++;
   if(l>10001){
    printf("-1");
    exit(0);
   }
   inicio();
   //field[0][0] =1;
   for(ll i=0;i<=l;i++){
      field[0][i] = 0;
      field[i][0] = 0;
   }
   build();
   ind  = false;
   for(ll i = 0; i<n;i++){

        scanf("%lld %lld",&x,&y);
        x++;
        y++;
        if(!visited[x][y])
            update(x,y);
        if(ind)
            continue;
        visited[x][y]=true;
        bool a = query();
        if(a && ind==false){
           printf("%lld\n",i+1);
            ind =true;
        }
   }
   if(!ind)
    printf("-1");
return 0;
}
/*
14 10 5 4
3 4
0 2
5 1
10 10
4 0
8 7
2 7
6 5
9 2
7 3
5 8
6 5
4 2
3 6
*/
