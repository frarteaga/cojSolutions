/// Jose A. Padilla Morani
/// IPVCE Maximo Gomez Baez
/// 12 grado
/// Problema rutas

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,u,v,w,a,b;
vector <pair <int,int> > orden;
vector <pair <int,int> > g[500005];
ll dist[500005];
ll visited[500005];

void bfs(int source){

        for(int i=0;i<=n;i++){
            dist[i]=99999999;
            visited[i]=0;
        }
        queue <int> cola;
        cola.push(source);
        dist[source] = 0;
        while(!cola.empty()){
            ll u = cola.front();
            cola.pop();
            if(visited[u])
                continue;
            visited[u] = 1;
            for(int i=0;i<g[u].size();i++){
                ll v = g[u][i].first;
                if(v==-1)
                    continue;
                ll w = g[u][i].second;
                if(!visited[v] ){
                   dist[v] = dist[u] + w;
                   cola.push(v);
                }
            }
        }
}
int main (){
    freopen("rutas.in","r",stdin);
    freopen("rutas.out","w",stdout);

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    scanf("%lld" , &n);
    ll dist1=-1 , dist2=-1;
    for(int i=0;i<n-1;i++){
        dist1=-1,dist2=-1;
        scanf("%d %d %d" , &u,&v,&w);
        orden.push_back(make_pair(u,v));
        g[u].push_back(make_pair(v,w));
        g[v].push_back(make_pair(u,w));
    }
    for(int i=0;i<n-1;i++){
        a = orden[i].first;
        b = orden[i].second;
        for(int i=0;i<g[a].size();i++)
            if(g[a][i].first==b)
                g[a][i].first = -1;

        for(int i=0;i<g[b].size();i++)
            if(g[b][i].first==a)
                g[b][i].first = -1;

        bfs(a);
        ll mayor = -1;
        ll nodo;
        for(int i=0;i<=n;i++){
            if(dist[i]!=99999999){
                if(mayor < dist[i]){
                    mayor=dist[i];
                    nodo = i;
                }
            }
        }

        bfs(nodo);
        dist1 = -1;
        dist2 = -1;
        for(int i=0;i<=n;i++){
            if(dist[i]!=99999999){
                if(dist1 < dist[i]){
                    dist1=dist[i];
                }
            }
        }
        bfs(b);
        mayor=-1;
        for(int i=0;i<=n;i++){
            if(dist[i]!=99999999){
                if(mayor < dist[i]){
                    mayor=dist[i];
                    nodo = i;
                }
            }
        }



        bfs(nodo);
         for(int i=0;i<=n;i++){
            if(dist[i]!=99999999){
                if(dist2 < dist[i]){
                    dist2=dist[i];
                }
            }
        }

        if(dist1>dist2)
            cout<<dist2<<" "<<dist1<<"\n";
        if(dist1<=dist2)
            cout<<dist1<<" "<<dist2<<"\n";

    }
return 0;
}
/*
5
1 2 2
2 3 1
2 4 2
1 5 3
*/
