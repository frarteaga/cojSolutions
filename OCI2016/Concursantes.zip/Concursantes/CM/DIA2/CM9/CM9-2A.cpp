/// Jose A. Padilla Morani
/// IPVCE Maximo Gomez Baez
/// 12 grado
/// Problema tablas

#include <bits/stdc++.h>
using namespace std;
long long result=0;
int temp[50];
int temp2[50];
int main (){
    freopen("tablas.in","r",stdin);
    freopen("tablas.out","w",stdout);
     ios_base::sync_with_stdio(0);
    cin.tie(0);
    int n,m,k;
    scanf("%d",&n);
    int a[50];
    int b[50];
    scanf("%d",&m);
    for(int i=0;i<m;i++)
        scanf("%d",&a[i]);
    sort(a,a+m);

    scanf("%d",&k);
    for(int i=0;i<k;i++)
        scanf("%d",&b[i]);
    sort(b,b+k);
    for(int mask =1 ;mask<(1<<n);mask++){
        int cont=0;
        for(int i=0;i<n;i++){
            if(mask & (1<<i))
                cont++;
        }
        if(cont==m){
               // cout<<"asd";

           for(int mask2 =1 ; mask2< (1<<n);mask2++){
               int cant=0;
               for(int i=0;i<n;i++){
                  if(mask2 & (1<<i))
                    cant++;
               }
               if(cant==k){
                      bool ind = false;
                    //cout<<"sad";
                    int cont2 = 0;
                    int cant2 = 0;
                    for(int i=0;i<n;i++){
                        temp[i]=-1;
                        temp2[i]=-1;
                    }
                    for(int i=0;i<n;i++){
                        if(mask & (1<<i))
                            temp[i] = a[cont2++];
                    }
                    for(int i=0;i<n;i++){
                        if(mask2 & (1<<i))
                            temp2[i] = b[cant2++];
                    }

                    int cont3=0;
                    int cent=0;
                    for(int i=0;i<n;i++){
                        if(temp[i]==-1){
                          int limite;
                          for(int j=i+1;j<n;j++)
                                if(temp[j]!=-1){
                                    limite = temp[j]-1;
                                }
                                if(cent<limite)
                            temp[i]=cont3++;
                            else
                                ind=1;
                        }
                        else{
                            if(temp[i]!=-1)
                                cont3 = temp[i]+1;
                        }
                    }
                     cont3=0;
                    cent=0;
                    for(int i=0;i<n;i++){
                            cent=temp[i]+1;
                        if(temp2[i]==-1){
                            int limite;
                            for(int j=i+1;j<n;j++)
                            if(temp2[j]!=-1){
                                limite = temp2[j]-1;
                            }
                            if(cent<limite)
                            temp2[i]=cont3++;
                            else
                            ind = true;

                        }
                        else{
                            if(temp2[i]!=-1)
                                cont3 = temp2[i]+1;
                        }
                    }


                    for(int i=0;i<n;i++){
                        if(temp2[i]<temp[i]){
                            ind=true;
                        }
                    }

                    if(ind==false){

                        result++;
                    }
               }
           }
        }

    }
    cout<<result;
return 0;
}
/*
4
2 3 2
3 4 7 8
*/
