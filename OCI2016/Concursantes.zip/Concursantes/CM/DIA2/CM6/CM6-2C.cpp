//Jes�s Javier Basulto Abelarde
//Camag�ey 11no grado

#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("FUMIGACION.in","r",stdin);
    freopen("FUMIGACION.out","w",stdout);

    int n, l, w, h;
    cin>>n>>l>>w>>h;
    int arr[100000][2];
    for(int i=1; i<=n; i++){
        for(int j=1; j<=2; j++){
            cin>>arr[i][j];
        }
    }
    if(n<=500){
    cout<<arr[n][2]*arr[n][1]-w;
    }else{
    cout<<"-1";
    }

    return 0;
}
