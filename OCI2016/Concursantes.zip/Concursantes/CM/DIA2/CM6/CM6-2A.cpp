//Jes�s Javier Basulto Abelarde
//Camag�ey 11no grado

#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("TABLAS.in","r",stdin);
    freopen("TABLAS.out","w",stdout);

    int n, c=0;
    cin>>n;
    int m, arr[36];
    cin>>m;
    for(int i=1; i<=m; i++){
        cin>>arr[i];
    }
    int k, brr[36];
    cin>>k;
    for(int j=1; j<=k; j++){
        cin>>brr[j];
    }
    c=(n*2)-(m+k);
    cout<<c-1;

    return 0;
}
