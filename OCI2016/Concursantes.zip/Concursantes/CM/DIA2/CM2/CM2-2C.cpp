/*Alain Alvarez Lopez 10mo
IPVCE Maximo Gomez Baez*/
#include <bits/stdc++.h>

using namespace std;

pair<long long,long long> t[100005];

int main()
{
    freopen("FUMIGACION.IN","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    long long n,l,w,h,f = 0;
    bool fund = false;
    cin>>n>>l>>w>>h;
    for (int i = 0; i < n; i++){
        long long x,y;
        cin>>x>>y;
        t[i] = make_pair(x,y);
        if (!fund)
        for (int e = 0; e < n; e++){
            if (e != i){
                if (t[e].first == t[i].first && t[e].second == t[i].second){
                    fund = true;
                    f = i+2;
                    break;
                }
            }
        }
    }
    cout<<f;
    return 0;
}
