/*Alain Alvarez Lopez 10mo
IPVCE Maximo Gomez Baez*/
#include <bits/stdc++.h>

using namespace std;

int n,m,k;
int a[40], b[40],c[40];
int mat[2][40];

int main()
{
    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    cin>>n;
    cin>>m;
    for (int i = 0; i < m; i++)
        cin>>a[i];

    cin>>k;
    for (int i = 0;i < k; i++)
        cin>>b[i];

    sort(a,a+m);
    sort(b,b+k);

    int l = 0;
    for (int i = 1; i < 2*n; i++){
        if (!binary_search(a,a+m,i) && !binary_search(b,b+k,i)){
            c[l] = i;
            //cout<<i<<"\n";
            l++;
        }
        //cout<<i<<"\n";
    }
    sort(c,c+l);
    /* dasdasd  */
    /*for (int i = 0;i < m; i++)
        cout<<a[i]<<" ";
    cout<<"\n";
    for (int i = 0;i < k; i++)
        cout<<b[i]<<" ";
    cout<<"\n";
    for (int i = 0;i < l; i++)
        cout<<c[i]<<" ";
    cout<<"\n";*/
    /*  sadsad */
    int a1 = 0,b1 = 0,h = 0, y = 0;
    bool place = false;
    for (int j = 0; j < 2*n; j++){
     bool isvalid = true;
     for (int i = 0; i < 2; i++){
        for (int e = 0; e < n; e++){
            while (c[h] == 0 && h < l){
                h++;
            }
            if (e == j)
                e++;
            if (!place){

            if (a[e] < c[h]){
                mat[i][e] = a[e];
                e++;
                mat[i][e] = c[h-1];
                c[h-1] = 0;
            }else{
                mat[i][e] = c[h];
                c[h] = 0;
                e++;
                mat[i][e] = a[e-1];
            }

            }else{
                //Second
               if (b[e] < c[h]){
                mat[i][e] = b[e];
                e++;
                mat[i][e] = c[h-1];
                c[h-1] = 0;
                if (mat[i-1][e-1] > mat[i][e-1] || mat[i-1][e] > mat[i][e]){
                    isvalid = false;
                    i = n;
                    break;
                }
               }else{
                mat[i][e] = c[h];
                c[h] = 0;
                e++;
                mat[i][e] = b[e-1];
                if (mat[i-1][e-1] > mat[i][e-1] || mat[i-1][e] > mat[i][e]){
                    isvalid = false;
                    i = n;
                    break;
                }
               }

            }
            h++;
        }
        h = 0;
        place = true;
    }
       if (isvalid){
        y++;
       }
    }
    cout<<y;
    return 0;
}
