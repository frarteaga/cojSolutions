/*Alain Alvarez Lopez 10mo
IPVCE Maximo Gomez Baez*/
#include <bits/stdc++.h>

using namespace std;

vector<pair<int,int> > x[500005];

int main()
{
    freopen("RUTAS.IN","r",stdin);
    //freopen("RUTAS.OUT","w",stdout);
    int z;
    cin>>z;
    //cout<<"READY"<<"\n";
    int c1,c2,d,l = 1;
    while(cin>>c1>>c2>>d){
        //cout<<c1<<" "<<c2<<" "<<d<<"\n";
        x[c1].push_back(make_pair(c2,d));
        x[c2].push_back(make_pair(c1,d));

        l++;
    }
    for (int i = 1; i < l; i++){
       int d1 = 0,d2 = 0, p = 0;
       while(x[i][p].first == 0){
         p++;
       }

       for (int u = p+1; u < x[i].size(); u++){
         if (x[i][u].first != 0 && x[i][u].first != x[i][p].first){
         /*cout<<x[i][u].first<<" "<<x[i][u].second<<"Comp\n";
         cout<<x[i][p+1].first<<" "<<i<<"Comp2\n";*/
         d2+=x[i][u].second;
         }
       }
       for (int e = i+1; e < l; e++){
         for (int y = 0; y < x[e].size(); y++){
           /*bool can = true;
           for (int s = p; s < x[i].size(); s++){
              if (x[e][y].first == x[i][s].first || x[e][y].first == i || e == x[i][s].first){
                can = false;
                break;
              }
           }*/
           if (x[e][y].first != i && x[e][y].first != x[i][p].first){
           //cout<<x[e][y].first<<" "<<e<<" Compare\n";
           d1+=x[e][y].second;
           }
         }
       }
       x[i][p].first = 0;
       cout<<d1<<" "<<d2<<"\n";
    }
    return 0;
}
