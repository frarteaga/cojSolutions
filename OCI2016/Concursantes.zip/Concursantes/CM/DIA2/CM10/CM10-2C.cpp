#include <bits/stdc++.h>

using namespace std;
bool g[500]=false;
int main()
{
    freopen("FUMIGACION.IN","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);
int n,l,w,h,fumigacion=0;
pair<int,int>p;
pair<int,int>cord[500];
int ap[500];
cin>>n>>l>>w>>h;
for(int i=0;i<n;i++){
    cin>>p.first;
    cin>>p.second;
    cord[i]=p;
}

for(int i=0;i<l;i++){
    for(int j=0;j<l;j++){
    g[i;j]=cord[i];
    g[i;j]=true;
    }
}

for(int i=0;i<w;i++){
    for(int j=0;j<h;j++){
    if(g[i;j]==true){
        fumigacion++;
    }
    }
}

for(int i=w;i<l;i++){
if(fumigacion==0)
    break;
for(int j=h;j<l;j++){
    if(g[i;j]==true){
        fumigacion++;
    }
}
}
cout<<fumigacion;
    return 0;
}
