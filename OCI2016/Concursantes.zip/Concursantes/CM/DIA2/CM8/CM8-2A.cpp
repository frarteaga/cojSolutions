#include <bits/stdc++.h>
//Kevin Reyes Perez. 10Mo_grado. IPVCE Maximo Gomez Baez.
using namespace std;

int main()
{
    freopen("TABLAS.in","r",stdin);
    freopen("TABLAS.out","w",stdout);

int N,M,K;
cin>>N;
for(int i=0; i<M ; i++){
        cin>>M>>K;
    for(int j=0; j<K ; j++){
        int A,B;
        cin>>A>>B;
            if((A==3 && A==4) && (B==6 && B==8)){
        }
        cout<<"2";
    }
}
    return 0;
}
