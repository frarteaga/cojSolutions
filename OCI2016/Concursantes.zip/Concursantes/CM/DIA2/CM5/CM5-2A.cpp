//Reynier L�pez Mena 11no
//IPVCE M�ximo G�mez B�ez
#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("TABLAS.in","r",stdin);
    freopen("TABLAS.out","w",stdout);
    int N,K[36],M[36],A,B,sumK=0,sumM=0,G[2],rest,c=0;
    cin>>N;
    cin>>A;
    for (int i=0;i<A;i++){
       cin>>K[i];
       sumK+=K[i];}
    cin>>B;
    for (int i=0;i<B;i++){
       cin>>M[i];
       sumM+=M[i];}
       G[0]=sumK;
       G[1]=sumM;
       sort(G,G+2);
       rest=G[1]-G[0];
       while(rest%2==0){
        rest=rest/2;
        c++;
       }
       cout<<c+1;
    return 0;
}
