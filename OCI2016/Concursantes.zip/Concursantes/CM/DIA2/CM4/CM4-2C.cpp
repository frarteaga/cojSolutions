//David L�pez Gonz�lez.
//IPVCE M�ximo G�mez B.
//CMG.
//10mo.

#include <bits/stdc++.h>

using namespace std;

int main()
{ freopen("FUMIGACION.IN","r",stdin);
  freopen("FUMIGACION.OUT","w",stdout);

  long long N,L,W,H,X1,Y1,XY,WH,c=0,C;
  cin>>N>>L>>W>>H;
  for(int i=0;i<N;i++){
    cin>>X1>>Y1;
    XY=X1+Y1;
    WH=W+H;
    if(XY<WH){
      WH-XY;
    C=(WH-XY);
    }
  }
  cout<<C;
    return 0;
}
