//David L�pez Gonz�lez.
//IPVCE M�ximo G�mez B.
//CMG.
//10mo.

#include <bits/stdc++.h>

using namespace std;

int z[50];

int main()
{ freopen("TABLAS.IN","r",stdin);
  freopen("TABLAS.OUT","w",stdout);

  int N,M,K,m,k,l,g,c=0,d=0;
  cin>>N;
  cin>>M;
  for(int i=0;i<M;i++){
    cin>>m;
  }
  cin>>K;
  for(int i=0;i<K;i++){
    cin>>k;
  }
  for(int j=0;j<m;j++){
    z[j]=l;
    if(l<l+1){
        c++;
    }
  }
  for(int o=0;o<k;o++){
    z[o]=g;
    if(g<g+1){
        d++;
    }
  }
  cout<<((c+d)/2)-2;
    return 0;
}
