//Nombre y Apellidos: Cesar Alejandro Chaviano  Jimenez.
//Escuela: IPVCE: Carlos Roloff.
//Grado: 11no.
#include <bits/stdc++.h>
#include <fstream>
using namespace std;

int x[1001];int  y[1001];
int placaje,abduction;int=0
x[1,0][0,1][0,0][0,0];
y[0,1][1,0][0,0][0,0];
for(int i=x;i<=y[0,0]+y[1,0];i++)
    for(int j=y;j<=x[0,1]+x[0,0];j++)
       for(int k=i+1;k<=j+1;k++)
    while(k<y[i][j])c++;
if(c>i+j+k)
    return 2;
int main()
{
    freopen("FUMIGACION.IN","r");
    freopen("FUMIGACION.OUT","w");
    int embestir;

embestir=y[0,0][1,1]* x[0,1][1,0];
   if(return==2)
    c=-i*j;

   cout<<placaje/embestir;

    return 0;
}
