//Nombre y Apellidos:Cesar Alejandro Chaviano Jimenez.
//Escuela: IPVCE:Carlos Roloff.
//Grado: 11no.
#include <bits/stdc++.h>
#include <vector>

using namespace std;
int main()
{
    freopen("TABLAS.IN","r");
    freopen("TABLAS.OUT","w");
    vector <int>c;

  int N,M=2,K;
  string A[1001];
      string B[1001];
      cin>>N>>M>>K;
      for(int i=1;i<=M;i++){
        for(int j=1;j<=K;j++){
       cin>>B[j];
      }
      cin>>A[i];

      }
  while(i++)switch[i][j];
   if(N==4)
    break;
   cout<<2;
array(int reverse);
    return 0;
}
