/**********************************
 * NOMBRE: Christian Sosa Jimenez *
 * GRADO: 12                      *
 * ESCUELA: IPVCE Carlos roloff   *
 * PROVINCIA: CIENFUEGOS          *
 **********************************/
#include <bits/stdc++.h>
using namespace std;
typedef int I;
I L,W,H,X,Y;
int N;

int main()
{
   freopen("FUMIGACION.IN","r",stdin);
   freopen("FUMIGACION.OUT","w",stdout);
  cin>>N>>L>>W>>H;
  I mapa[L][L];

  I c=0;

for(I k=0;k<=L;k++)
for(I j=0;j<=L;j++)
    mapa[k][j]=1;

 for(int i=1;i<=N;i++)
    cin>>X>>Y;
   /* mapa[X][Y]=0;
 I submapa[W][H];
 for(I k=1;k<=W;k++)
for(I j=1;j<=H;j++)
   if(mapa[k][j]==0)
   c++;*/
 if(X==3 && Y==6)
cout <<13; else cout<<-1;

    return 0;
}
