/******************************
*Samuel David Suarez Rodriguez*
*Carlos Roloff Mialofsky      *
*11no Problem A               *
******************************/

#include <bits/stdc++.h>

using namespace std;

short N,M,K;
int l[2][35];
int cont;
bool mark[70];
int a,b,c=0;
int cc[35];
int f[70];

void fact(int n){
    f[0]=f[1]=1;
    for(int i=2;i<=n;i++)f[i]=i*f[i-1];
}

bool comp(){
    int aa[35],bb[35];
    for(int i=0;i<N;i++){
        aa[i]=l[0][i];
        bb[i]=l[1][i];
    }
    sort(aa,aa+N);
    sort(bb,bb+N);
    for(int i=0;i<N;i++){
        if(aa[i]>bb[i])return false;
    }

    /*for(int i=0;i<N;i++)cout<<aa[i]<<" ";
    cout<<endl;
    for(int i=0;i<N;i++)cout<<bb[i]<<" ";
    cout<<endl;*/
    return true;
}

void _fill(){
    int q=0;
    for(int i=a;i<N;i++){
        l[0][i]=cc[q++];
    }
    for(int i=b;i<N;i++){
        l[1][i]=cc[q++];
    }
}

int main()
{
    ifstream in("TABLAS.IN");
    ofstream out("TABLAS.OUT");

    in>>N;
    in>>M;
    for(int i=0;i<M;i++){
        in>>l[0][i];
        mark[l[0][i]]=1;
    }
    in>>K;
    for(int i=0;i<K;i++){
        in>>l[1][i];
        mark[l[1][i]]=1;
    }
    a=M;b=K;
    for(int i=1;i<=2*N;i++){
        if(!mark[i])cc[c++]=i;
    }
    fact(N);
    for(int i=0;i<f[c]/c;i++){
        _fill();
        next_permutation(cc,cc+c);
        /*for(int i=0;i<c;i++)cout<<cc[i]<<" ";
        cout<<endl;*/
        if(comp()){
            cont++;
        }
    }
    out<<cont;
    return 0;
}
