//Laura I L�pez Mart�n
//IPVCE Carlos Roloff Milofsky
//10mo

#include <bits\stdc++.h>

using namespace std;

int main()
{
   /* freopen("FUMIGACION.in","r",stdin);
freopen("FUMIGACION.out","w",stdout);*/

    int N, L,W,H,i,t,x,y,q,nf;
cin>>N>>L>>W>>H;

int cont=0;
for(int i=1;i<=N;i++){
cin>>x>>y;
for(int i=1;i<=N;i++)
t=x;
if(x==t)
cont++;
nf=cont-1;
}

while(x==t){
       cont++;
t=cont;
nf=N-t;
q=N+nf;
}
if(x<=W && y<=H){
}
cout<<q;

    return 0;
}
