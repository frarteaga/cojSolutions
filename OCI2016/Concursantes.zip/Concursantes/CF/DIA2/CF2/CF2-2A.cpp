//Elizabeth Rodr�guez Molina
//I.P.V.C.E �Carlos Roloff�
//10mo

#include <bits/stdc++.h>

using namespace std;

int main()
{
freopen("TABLAS.IN","r",stdin);
freopen("TABLAS.OUT","w",stdout);


 int n,m,k;
 cin>>n>>m>>k;


 for( int i=0;i<=n;i++){
    for(int j=0;j<=m;j++)
        j+=i;
 }

  if(n>m && m>k && n>k){
    cout<<k;
  }
if(k>m && m>n && n<k ){
    cout<<n;
}
   else
   if(n>m && k>m && k>n ){
        cout<<m;
   }
    if(n>m && k>m && k<n ){
        cout<<m;
    }



    return 0;

}
