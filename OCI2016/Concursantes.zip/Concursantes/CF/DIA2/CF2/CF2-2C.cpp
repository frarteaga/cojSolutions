//Elizabeth Rodr�guez Molina
//I.P.V.C.E � Carlos Roloff �
//10mo
#include <bits/stdc++.h>

using namespace std;

int main()
{
   freopen("FUMIGACION.IN","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);

    int n,l,w,h;
  cin>>n>>l>>w>>h;

  for( int i=0;i<n;i++){
      for( int j=1;j<=n;j++){
      }
  }
    if(n>l && n>w && n>h){
        cout<<n;
    }
   if(l>n && l>w && l>h){
    cout<<l;
   }
   if(w>n && w>l && w>h){
    cout<<w;
   }
   if(h>n && h>l && h>w){
    cout<<h;
   }



   return 0;

     }




