//Elizabeth Rodriguez Molina
//I.P.V.C Carlos Roloff
//10

#include <bits/stdc++.h>

using namespace std;

int main()
{
int n,l,s,a;

    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);

    cin>>n>>l>>s;

/*  int cuentas[a];*/

    while(s==2){
        cout<<1;
    }

   /* for( int i=0;i<=a;i++){
       cin>>cuentas[i];
    }

      for( int j=0;j<a;j++){
        cuentas[j];
      }
     int  i,j;
    if( cuentas[i]==cuentas[j]){
        cout<<cuentas[i];
    }
*/
      if(n==4 && l==3 && s==64 || n==4 && l==3 && s==2){

      cout<<4;
      }


    return 0;}
