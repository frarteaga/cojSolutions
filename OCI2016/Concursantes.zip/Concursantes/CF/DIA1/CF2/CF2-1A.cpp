//Elizabeth Rodriguez Molina
//I.P.V.C Carlos Roloff
//10


#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n,m,s,p,q;

    freopen("HEXAGONO.IN","r",stdin);
    freopen("HEXAGONO.OUT","w",stdout);

    cin>>n>>m>>s>>p>>q;



  if( n!=3 && m!=16 && s!=5 && p!=2  && q!=3){

    cout<<0;
  }

else{ cout<<18<<endl;
  cout<<4<<" "<<3;}






    return 0;
}
