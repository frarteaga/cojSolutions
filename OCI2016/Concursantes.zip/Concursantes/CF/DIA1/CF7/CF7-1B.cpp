//Nombres y Apellidos: Cesar Alejandro Chaviano Jimenez.
//Escuela:IPVCE:"Carlos Roloff".
//Grado:11no.
#include <bits/stdc++.h>

using namespace std;

int main()
{
    vector<int>d;
}
cin>>A>>d>>fd;
for(int i=0;i<A-1;i++)
    return 0;
}
