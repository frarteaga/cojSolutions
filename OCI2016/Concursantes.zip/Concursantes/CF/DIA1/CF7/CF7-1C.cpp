//Nombres y Apellidos: Cesar Alejandro Chaviano Jimenez.
//Escuela:IPVCE:"Carlos Roloff".
//Grado:11no.
#include <bits/stdc++.h>

using namespace std;

int main()
{
   for(int i=0;i<=N;i++){
     for(int j=i+1;j<P[lista];j++){ 
    return 0;
}
