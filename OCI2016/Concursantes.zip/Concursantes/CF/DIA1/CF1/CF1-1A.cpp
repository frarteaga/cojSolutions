#include <bits\stdc++.h>
//Laura Isabel Lopez Martin
//IPVCE CARLOS ROLOFF MIALOFSKY
//10MO
using namespace std;

int main()
{
    freopen("HEXAGONO.IN","r",stdin);
    freopen("HEXAGONO.OUT","w",stdout);
    int m,p,q,j,t,i,h;
    long n;
    long long s;
cin>>n>>m>>s>>p>>q;
int arr[10000];
t=n+(n+1)+(n+2);
t=t+(n+1)+(n+2);

for(int i=1,h=s;i<=t,h<=s+(m-1);i++,h++){
    arr[i]=h;
  }

  cout<<n+(2*n);
cout<<"\n"<<n+2<<" "<<n-3;

return 0;
}
