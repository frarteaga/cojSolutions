// Bertha Flores Alonso
// IPVCE Carlos Roloff
// 12

#include <iostream>
#include <fstream>

using namespace std;

//freopen("CUENTAS.IN"; "r")
//freopen("CUENTAS.OUT"; "W")

int main()

{
    int  l, c=0, z=0, n, s;
    char cad1[10], cad2[10], cad3[10], cad4[10];
cin >>  n;
cin >>  l;
cin >>  s;
    for (int i=0; i < l; i++)
cin >> cad1[i];
    for (int j=0; j < l; j++)
cin >> cad2[j];
  for (int k=0; k < l; k++)
cin >> cad3[k];
for (int d=0; d < l; d++)
cin >> cad3[d];
z=3;

{
    //1y2
    for (int i = 0, j = 0; i < l, j < l; i++, j++)
    if (cad1[i] == cad2[j] )
    c++;

        if ( (c == (l-1)) || (c == l)){
            z++;
        }
}

{
    //1y3
    c = 0;
    for (int i = 0, j = 0; i < l, j < l; i++, j++)
    if (cad1[i] == cad3[j] )
    c++;

     if ( (c == (l-1)) || (c == l)){
            z++;
     }
}
            {
                //1y4
                c = 0;
    for (int i = 0, j = 0; i < l, j < l; i++, j++)
    if (cad1[i] == cad4[j] )
    c++;

     if ( (c == (l-1)) || (c == l)){
            z++;
     }
}
            {
                //2y3
                c = 0;
    for (int i = 0, j = 0; i < l, j < l; i++, j++)
    if (cad3[i] == cad2[j] )
    c++;

     if ( (c == (l-1)) || (c == l)){
            z++;
     }
}

    {

                //2y4
                c = 0;
    for (int i = 0, j = 0; i < l, j < l; i++, j++)
    if (cad4[i] == cad2[j] )
    c++;

     if ( (c == (l-1)) || (c == l)){
            z++;
     }
}

            {
                //3y4
                c = 0;
    for (int i = 0, j = 0; i < l, j < l; i++, j++)
    if (cad3[i] == cad4[j] )
    c++;

     if ( (c == (l-1)) || (c == l)){
            z++;
     }

}

cout << z ;
    return 0;
}
