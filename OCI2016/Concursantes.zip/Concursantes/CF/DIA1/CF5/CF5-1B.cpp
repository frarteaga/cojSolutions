/******************************
*Samuel David Suarez Rodriguez*
*Carlos Roloff Mialofsky  11no*
*Problem B                    *
******************************/

#include <bits/stdc++.h>
#define MAX1 30001
#define MAX2 201
using namespace std;

int N,L,S;
char cad[MAX1][MAX2];
int c;

bool solve(int q,int w){
    bool ans=false;
    for(int i=0;i<L;i++){
        if(cad[q][i]!=cad[w][i]){
            if(ans)return false;
            ans=true;
        }
    }
    if(ans)return true;
    return false;
}

int main()
{
    ifstream in("CUENTAS.IN");
    ofstream out("CUENTAS.OUT");
    in>>N>>L>>S;
    for(int i=0;i<N;i++){
        in>>cad[i];
    }
    for(int i=0;i<N;i++){
        for(int j=i+1;j<N;j++){
            if(solve(i,j)){
                c++;
            }
        }
    }
    out<<c;
    return 0;
}
