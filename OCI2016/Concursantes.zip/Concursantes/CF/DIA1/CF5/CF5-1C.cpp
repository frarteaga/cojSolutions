/*******************************
*Samuel David Suarez Rodriguez *
*Carlos Roloff Mialofsky       *
*11no         Problem C        *
*******************************/

#include <bits/stdc++.h>
#define L 201
#define INF 99999
using namespace std;

int a[L][L];
string dp[L][L];
short N,M;
unsigned short K;
short dy[]={1,0};
short dx[]={0,1};
string best;
int sumax;

void _fill(){
    for(int i=1;i<=N;i++){
        for(int j=1;j<=M;j++){
            if(a[i][j]!=-INF){
                a[i][j]+=max(a[i-1][j],a[i][j-1]);
            }
        }
    }
}

bool comp(string com){
    for(unsigned int i=0,j=K;j<com.size();j++,i++){
        if(i==K)i=0;
        if(com[i]!=com[j])return false;
    }
    return true;
}

int main()
{
    ifstream in("ROBOT.IN");
    ofstream out("ROBOT.OUT");
    in>>N>>M>>K;
    for(int i=1;i<=N;i++){
        for(int j=1;j<=M;j++){
            char c;
            in>>c;
            if(c=='#')a[i][j]=-INF;
            else a[i][j]=c-'0';
        }
    }
    _fill();
    for(int i=1;i<=N;i++){
        for(int j=1;j<=M;j++){
            if(i==1 && j==1)continue;
            if(i==1 && j!=1){
                if(a[i][j-1]!=-INF)dp[i][j]=dp[i][j-1]+'R';
            }
            if(i!=1 && j==1){
                if(a[i-1][j]!=-INF)dp[i][j]=dp[i-1][j]+'D';
            }
            else{
                if(a[i-1][j]>a[i][j-1] && a[i-1][j]!=-INF){
                    dp[i][j]=dp[i-1][j]+'D';
                }
                if(a[i][j-1]>=a[i-1][j] && a[i][j-1]!=-INF){
                    dp[i][j]=dp[i][j-1]+'R';
                }
            }
        }
    }
    for(int i=1;i<=N;i++){
        if(a[N][i]!=-INF){
            if(comp(dp[N][i]) && a[N][i]>sumax){
                best=dp[N][i];
                sumax=a[N][i];
            }
        }
        if(a[i][M]!=-INF){
            if(comp(dp[i][M]) && a[i][M]>sumax){
                best=dp[i][M];
                sumax=a[i][M];
            }
        }
    }
    for(int i=0;i<K;i++)out<<best[i];
    return 0;
}
