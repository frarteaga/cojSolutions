/**********************************
 * NOMBRE: Christian Sosa Jimenez *
 * GRADO: 12mo                    *
 * ESCUELA: IPVCE Carlos Roloff   *
 * PROVINCIA: Cienfuegos          *
 **********************************/
#include <bits/stdc++.h>
using namespace std;

int main()
{


freopen("CUENTAS.IN", "r",stdin);
freopen("CUENTAS.OUT", "w", stdout);

int N, L, S,t=1,igual;
cin>>N>>L>>S;
char cadena[N][L];
for (int i=1; i <= N; i++)
    for ( int j=1; j <= L; j++ ) {
      cin >> cadena[i][j];
    }

           int c=0,q=0;
for (int i=1; i <= N; i++)
    for ( int j=1; j <= L; j++ ){

   while(t<=N){
   igual=cadena[i][t];
    if(cadena[i][t]==igual)
        c++; t++;
   }
    }
cout<<c;


    return 0;
}
