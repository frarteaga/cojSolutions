/**Alex Javier Rivas Martinez
IPVCE Carlos Roloff
11 grado**/
#include <fstream>
#define SIZE 200

using namespace std;

char cad[SIZE][ SIZE ];
short N, L, S;
short cant = 0;

bool letter( char a )
{
if( a >= char( 97 ) && a <= char ( 122 ) )
    return true;
if( a >= char ( 'a' - 32 ) && a <= char( 'z' - 32 ) )
    return true;
return false;
}

bool digit( char a )
{
if( a >= '0' && a <= '9' )
    return true;
return false;
}

void verificaResultsBinary()
{
    short cantCon = 0;
    for( short j = 1; j <= N; j++ )
    {
        for( short j1 = j + 1; j1 <= N; j1++ ){
            for( short i = 0; i < L; i++ )
            {
                if( cad[ j ][ i ] == cad[ j1 ][ i ] )
                    cantCon++;
            }
            if( cantCon == L - 1  )
            {
                cant++;
                cantCon = 0;
            }
            cantCon = 0;
        }
    }
}

void verificarResults()
{
    short pos;
    short cantCon = 0;
    for( short j = 1; j <= N; j++ )
    {
        for( short j1 = j + 1; j1 <= N; j1++ ){
            for( short i = 0; i < L; i++ )
            {
                if( cad[ j ][ i ] == cad[ j1 ][ i ] )
                    cantCon++;
                else
                {
                    pos = i;
                }
            }
            if( cantCon == L - 1 && letter( cad[ j ][ pos ] ) &&
               letter( cad[ j1 ][ pos ] ) ){
                cant++;
                cantCon = 0;
               }
            else if( cantCon == L - 1 && letter( cad[ j ][ pos ] ) &&
               digit( cad[ j1 ][ pos ] ) )
               {
                   cant++;
                    cantCon = 0;
               }
            else if( cantCon == L - 1 && digit( cad[ j ][ pos ] ) &&
               letter( cad[ j1 ][ pos ] ) )
            {
                cant++;
                cantCon = 0;
            }
            else if( cantCon == L - 1 && digit( cad[ j ][ pos ] )
                    && digit( cad[ j1 ][ pos ] ) ){
                    cant ++;
                    cantCon = 0;
                    }
            else if( cantCon == L - 1 && !digit( cad[ j ][ pos ] )
                    && !digit( cad[ j1 ][ pos ] ) &&
                    !letter( cad[ j ][ pos ] ) &&
                    !letter( cad[ j1 ][ pos ] ) )
                    {
                        cant++;
                        cantCon = 0;
                    }
            cantCon = 0;
        }
    }
}


int main()
{
    ifstream in( "CUENTAS.IN" );
    ofstream out( "CUENTAS.OUT" );
    in >> N >> L >> S;
    for( short j = 1; j <= N; j++ )
        for( short i = 0; i < L; i++ )
        in >> cad[ j ][ i ];
    if( S == 2 )
    {
        verificaResultsBinary();
        out << cant;
        return 0;
    }
    else
    {
        verificarResults();
        out << cant;
        return 0;
    }
}
