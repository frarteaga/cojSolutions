/**Alex Javier Rivas Martinez
IPVCE Carlos Roloff
11 grado**/
#include <fstream>
#define MAXN 200
#define MAXC 200

using namespace std;

char cad[ MAXN ][ MAXC ];
short N, M, K;
short dx[] = {1,0};
short dy[] = {0,1};
char cadAns[ 100 ];
short o;

void dfs( int x, int y )
{
    short i = 0;
    for( short i = 1; i <= N; i++ )
    {
           if( cad[ i ][ M ] == '0' )
               return;
    }
    if( cad[ x + dx[ i ] ][ y  + dy[ i ] ] != '#' &&
        cad[ x + dx[ i + 1 ] ][ y  + dy[ i + 1 ] ] != '#' )
    {
        if( cad[ x + dx[ i ] ][ y  + dy[ i ] ] <
            cad[ x + dx[ i + 1 ] ][ y  + dy[ i + 1 ] ] )
            {
                cad[ x + dx[ i + 1 ] ][ y  + dy[ i + 1 ] ] = '0';
                    cadAns[ o++ ] = 'R';
                dfs( x + dx[ i + 1 ], y  + dy[ i + 1 ] );
            }
        else
        {
            cad[ x + dx[ i ] ][ y  + dy[ i ] ] = '0';
                    cadAns[ o++ ] = 'D';
            dfs( x + dx[ i ], y  + dy[ i ] );
        }
    }
    else if( cad[ x + dx[ i ] ][ y  + dy[ i ] ] == '#' &&
            cad[ x + dx[ i + 1 ] ][ y  + dy[ i + 1 ] ] != '#' )
    {
        cad[ x + dx[ i + 1 ] ][ y  + dy[ i + 1 ] ] = '0';
                cadAns[ o++ ] = 'R';
        dfs( x + dx[ i + 1 ], y  + dy[ i + 1 ] );
    }
    else if( cad[ x + dx[ i ] ][ y  + dy[ i ] ] != '#' &&
            cad[ x + dx[ i + 1 ] ][ y  + dy[ i + 1 ] ] == '#' )
            {
                cad[ x + dx[ i ] ][ y  + dy[ i ] ] = '0';
                cadAns[ o++ ] = 'D';
                dfs( x + dx[ i ], y  + dy[ i ] );
            }
    else if( cad[ x + dx[ i ] ][ y  + dy[ i ] ] == '#' &&
            cad[ x + dx[ i + 1 ] ][ y  + dy[ i + 1 ] ] == '#' )
                return;
}

int main()
{
    ifstream in( "ROBOT.IN" );
    ofstream out( "ROBOT.OUT" );
    in >> N >> M >> K;
    for( short i = 1; i <= N; i++ )
    {
        for( short j = 1; j <= M; j++ )
            in >> cad[ i ][ j ];
    }
    dfs( 1, 1 );
    for( short i = 0; i < K; i++ )
        out << cadAns[ i ];
    return 0;
}
