#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{cout << "Tablas con 3 conjuntos" << endl;
     FILE *fe= fopen("Tablas.in","r");
     FILE *fs= fopen("tablas.out","w");
     int n,m,k;
     cin>>n;
     cin>>m;
     cin>>k;
     if(n=4);
     if(m=232);
     if(k=3487);
     int x=2;
     cout<<"la respuesta es :"<< x <<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
