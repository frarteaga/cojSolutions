#include <iostream>

using namespace std;

int main()
{
    int N,M,K;
    int A[M],B[K];
    cin>>N;
    cin>>M;
    cin>>K;
    int i=0,j,h;
    for(;i<M;i++)
    {
        for(j=i+1;j<M;j++)
        {
            if(A[i]>A[j])
            h=A[i];
            A[i]=A[j];
            A[j]=h;
        }
    }
    return 0;
}
