#include <iostream>

using namespace std;

int main()
{
    int N,M,K,i,j;
    cin>>N >>M >>K;
    int campo[N][M];
    return 0;
}
