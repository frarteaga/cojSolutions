#include <iostream>

using namespace std;

int main()
{   int n,l,w,h;
    cout << "cuantas veces se uso el insecticida" << endl;
    cout << "cuantos arboles se lograron proteger tras cual fumigacion" << endl;
    cin>>n;
    cin>>l;
    cin>>w;
    cin>>h;

    return 0;
}
