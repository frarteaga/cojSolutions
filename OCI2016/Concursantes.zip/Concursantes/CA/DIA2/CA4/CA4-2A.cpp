#include <iostream>

using namespace std;

int main()
{   int n,m,k;
    n++;
    cout << "leer los valores de las variables n,m y k y los numeros que se encuentran en los conjuntos A y B" << endl;
    cin>>n;
    cin>>m;
    cin>>k;
    cout << "la orden de los conjuntos a y b" <<endl ;




















    return 0;
}
