#include <iostream>

using namespace std;

int main()
{
    int a,n,b,c,s,z;
    cin>>a;
    cin>>n;
    b=a+n;
    cout<<"30";
    cin>>c;
    cin>>s;
    z=c+s;
    cout<<"40";
    float, 30;
    float, 40;
    if(30<40);
    else "entonces la carretera mas larga es la segunda z";
    return 0;
}
