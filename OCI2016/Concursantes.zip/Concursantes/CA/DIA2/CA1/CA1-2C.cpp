#include <iostream>

using namespace std;

int main()
{
    int n,l,w;
    cin>>l;
    cin>>w;
    n=l+w;
    cout<<n;
    cout<<"cantidad de arboles fumigados";
    return 0;
}
