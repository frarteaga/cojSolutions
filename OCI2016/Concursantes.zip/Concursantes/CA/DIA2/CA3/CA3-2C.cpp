#include <iostream>

using namespace std;

int main()
{ int n,w,h;
    cout << "introducir dos cordenadas {x;y}" << endl;
    cin>>w;
    cin>>h;
    n=w*h;
    return 0;
}
