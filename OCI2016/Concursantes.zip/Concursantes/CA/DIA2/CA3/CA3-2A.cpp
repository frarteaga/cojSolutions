#include <iostream>

using namespace std;

int main()
{int n,a,b,c,m,k;
    cout << "introducir tres conjuntos de numeros enteros positivos" << endl;
    cin>>a;
    cin>>b;
    cin>>c;
    n=a+b+c;
    m=a;
    k=b;
    return 0;
}
