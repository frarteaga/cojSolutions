#include <iostream>

using namespace std;

int main()
{ int x,y,z;
    cout << "introducir tres numeros enteros positivos " << endl;
    cin>>z;
    cin>>x;
    cin>>y;
    x=z;
    y=z;
    return 0;
}
