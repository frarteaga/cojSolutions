#include <iostream>

using namespace std;

int main()
{int n,m,k,q,w,e,r;
cin>>n;
cin>>m;
cin>>k;
cin>>q;
cin>>w;
cin>>e;
cin>>r;
cout<<2;


    return 0;
}
