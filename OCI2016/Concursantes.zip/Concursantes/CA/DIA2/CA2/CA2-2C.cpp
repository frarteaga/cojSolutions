#include <iostream>

using namespace std;

int main()
{
    int n,l,w,h,x,y;
    cin>>n;
    cin>>l;
    cin>>w;
    cin>>h;-
    1<=n<=100000;
    1<=l<1000000000;
    1<=w,h<=l;
    0<x,y<=l;
    return 0;
}
