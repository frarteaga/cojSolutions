#include <iostream>

using namespace std;

int main()
{
   int n,m,k,a;

   1<n<=35;
   0<=m<=n;
   0<=k<=n;
   cin>>n;
   cin>>m;
   cout<<"el conjunto a es";
   cin>>a;
   cin>>k;

       return 0;
}
