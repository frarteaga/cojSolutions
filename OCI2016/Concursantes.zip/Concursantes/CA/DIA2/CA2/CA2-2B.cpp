#include <iostream>

using namespace std;

int main()
{
   int n,m,p,q;
   m,p,q>0;
   cin>>n;
   cin>>m;
   cin>>P;
   cin>>q;

   1<=q<=1000;
   1<=n<=500000;


    return 0;
}
