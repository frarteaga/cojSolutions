#include <cstdlib>
#include <fstream>

using namespace std;

int main()
{  fstream rutas.IN;
    cout << " careteras A"<< "\A";
    fstream rutas.OUT;
    for (int 1=0; 1<N<500000;)
     cout <<"careteras"<<"\1";
    int a;
    cin >> a;
    cout <<"careteras"<<"\2";
    int b;
    cin >> b;
    int suma = a+b;
   rutas.in =fopen(rutas.IN;);
    if (A==0)
    cout << "careteras 4" << "\B";
    for (int B=1; 2<M<1000);
    if (B==0)
     cout <<"careteras"<<"\3";
    int a;
    cin >> a;
    cout <<"careteras"<<"\4";
    int b;
    cin >> b;
    int suma = a+b;
    cout << "careteras 5" << "\5";
    for (int B=2; 0<K<N);
    if(C==0)
      rutas.out=fclose(rutas.OUT;);

    return (main ());
}
