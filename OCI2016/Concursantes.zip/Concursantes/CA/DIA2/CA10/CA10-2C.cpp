#include <cstdlib>
#include <iostream>

using namespace std;

int main()
{fstream FUMIGACION.IN;
    cout << " FUMIGACION A"<< "\A";
    fstream  FUMIGACION.OUT;
     cout << "FUMIGACION B" << "\B";
    for (int B=0; 1<N<100000;);
       if (B==0)
       cout <<"FUMIGACION"<<"\n";
    int a;
    cin >> a;
    cout <<"FUMIGACION"<<"\n";
    int b;
    cin >> b;
    int suma = a+b;
    cout <<"La suma es"<<"\n" <<suma;
    for (int A=0; 1<L<1000000000;);
     FUMIGACION.in =fopen(FUMIGACION.IN;);
    if (A==0)
    cout <<"FUMIGACION"<<"\n";
    int c;
    cin >> c;
    cout <<"FUMIGACION"<<"\n";
    int d;
    cin >> d;
    int resta = c-d;
    cout <<"FUMIGACION"<<"\n" <<resta;
    cout << "FUMIGACION B" << "\B";
    for (int B=1; 1<W,H<L;);
       if (B==0)
    cout << "FUMIGACION C" << "\C";
    for (int B=2; 0<Xi,Yi<L);
    if(C==0)
       FUMIGACION.out=fclose(FUMIGACION.OUT;);
   
    return (main ()) ;
}
