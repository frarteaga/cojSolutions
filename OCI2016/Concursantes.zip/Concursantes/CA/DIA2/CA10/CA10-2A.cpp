#include <cstdlib>
#include <fstream>

using namespace std;

int main()
{   fstream tablas.IN;
    cout << " tablas A"<< "\A";
    fstream tablas.OUT;
    for (int A=0; 1<N<35;)
    cuentas.in =fopen(tablas.IN;);
    if (A==0)
    cout << "enteros B" << "\B";
    for (int B=1; 2<M<1000);
    if (B==0)
    cout << "enteros C" << "\C";
    for (int B=2; 0<K<N);
    if(C==0)
      cuentas.out=fclose(tablas.OUT;);
    return(main());
}
  
  
