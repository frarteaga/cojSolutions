#include <iostream>

using namespace std;

int main()
{int n,l,s,q,a,z,w,p,x,e,d,c,r,f,v;
cin>>n;
cin>>l;
cin>>s;
cin>>q;
cin>>a;
cin>>z;
cin>>w;
cin>>p;
cin>>x;
cin>>e;
cin>>d;
cin>>c;
cin>>r;
cin>>f;
cin>>v;
cout<<4;








    return 0;
}
