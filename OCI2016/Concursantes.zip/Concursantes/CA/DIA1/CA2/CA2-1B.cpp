#include <iostream>

using namespace std;

int main()
{
    int n, l ,s ,p ,q,r;
    cin>>l;
    cin>>s;
    if(s=2,p=0,p=1);
    else(s=64,p>2);
    1<=n<=30000;
    1<=l<=200;





    return 0;
}
