#include <iostream>

using namespace std;

int main()
{
    int n, m ,k;
    1<=n<=200;
    1<=m<=200;
    1<=k<=100;

    return 0;
}
