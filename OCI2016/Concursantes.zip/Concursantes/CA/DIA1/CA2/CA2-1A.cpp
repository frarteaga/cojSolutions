#include <iostream>

using namespace std;

int main()
{
    int n,m,s,p,q;
    n,m,p,q,s>0;


    return 0;
}
