#include <iostream>

using namespace std;

   int n,l,s;
   cout<< "introducir dos numeros" << endl;
   sin>>s;
   sin>>n;
   l=n*s

    return 0;
}
