#include <iostream>

using namespace std;

    int n,m,s,p,q,x;
    cout << "introducir cinco numeros " << endl;
    sin>>n;
    sin>>m;
    sin>>s;
    sin>>p;
    sin>>q;
    x=n+m+s+p+q
    return 0;
}
