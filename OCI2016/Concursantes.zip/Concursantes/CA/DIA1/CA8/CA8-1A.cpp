#include <iostream>

using namespace std;

int main()
{
    cout << "Hexagono" << endl;

    void Crear()
 {
     FILE*fitch;
     fitch=fopen("Hexagono.txt","a+");
     printf("Entre el numero\n");
     scanf("%s",&x.Valor);
     fwrite(&x, sizeof(struct Cliente), 1, fitch);
     fclose(fitch);
 }

 void Leer()
 {
     FILE*fitch;
     fitch=fopen("Hexagono.txt","r");
     fread(&x, sizeof(struct Cliente), 1, fitch);
     while(!feof(fitch))
     {
         printf("%s\t\t%s\t\t%d\t\t%f\n\n",x.Valor,);
        fread(&x, sizeof(struct Cliente), 1, fitch);
     }
 }
    int n,m,s,p,q;
    cout<<n;
    cout<<m;
    cout<<s;
    cout<<p;
    cout<<q;
    if(n>0) endl;
    if(m>0) endl;
    if(s>0) endl;
    if(p>0) enfl;
    if(q>0) endl;
    if(1<n<=24*10^8) endl;
    if[0<m<3n*(n-1)] endl;
    if(1<s<18*10^18) endl;



    return main();
}
