#include <iostream>

using namespace std;

int main()
{   int a,b,c;
    cout << "Introduzca dos numeros a sumar" << endl;
    cin>>a;
    cin>>b;
    a+b=c;

    return 0;
}
