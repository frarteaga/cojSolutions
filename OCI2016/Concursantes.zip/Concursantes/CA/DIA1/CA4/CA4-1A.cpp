#include <iostream>

using namespace std;

int main()
{   int n,m,s,p,q;
    cout << "numeros faltantes en el hexagono" << endl;
    cout << "introduzca n numeros" << endl;
    cin >> "n" >>;
    cin >> "m" >>;
    n+m=s;

    return 0;
}
