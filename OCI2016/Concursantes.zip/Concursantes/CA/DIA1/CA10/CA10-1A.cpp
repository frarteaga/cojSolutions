#include <cstdlib>
#include <iostream>
/*Name: Alejandro Benitez Payan*/
using namespace std;

int main()
{   fstream Hexagono.in;
    fstream Hexagono.out;
    Hexagono.in =fopen(Hexagono.IN;"r");
    Hexagono.out=fclose(Hexagono.OUT;"w");
    cout <<"inserte un numero"<<"\r";
    int r;
    cin >> r;
    cout <<"inserte otro numero"<<"\w";
    int w;
    cin >> w;
    int suma = r+w+1;
    cout <<"La suma es"<<"\n" <<suma;
    return (main ());
}

 
