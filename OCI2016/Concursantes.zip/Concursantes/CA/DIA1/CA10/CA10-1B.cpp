#include <cstdlib>
#include <iostream>

using namespace std;

int main()
{   fstream cuentas.in;
    fstream cuentas.out;
    cuentas.in =fopen(cuentas.IN;"r");
    cuentas.out=fclose(cuentas.OUT;"w");
    int auxiliar=0,
    cout <<"mostrar todos los pares de letras";
    for (int N=0; 1<N<3000;)
     int digito1;
    int digito2;
    int digito3;
    int menor;
    cout << "entre el primer digito"<<"\n";
    cin>>digito1;
    cout << "entre el segundo digito"<<"\n";
    cin>>digito2;
    cout << "entre el tercer digito"<<"\n";
    cin>>digito3;
     for (int N=0; 1<L<200;)
{
    return (main);
}
