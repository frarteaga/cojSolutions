#include <iostream>

using namespace std;

int main()
{
    int n,l,s;
    cin>>n;
    cout<<("n es");
    cin>>l;
    cout<<("l es");
    cin>>s;
    cout<<("n+1");

    return 0;
}
