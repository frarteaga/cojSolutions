/***********************************
*  NAME : David Dominguez Gonzalez *
*  SCHOOL: Silberto Alvarez Aroche *
*  PROVINCE : Granma               *
*                                  *
************************************/

#include<bits/stdc++.h>

using namespace std;

int N,M,S,P,Q;
int cant,ub,may;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("HEXAGONO.IN","r",stdin);
    freopen("HEXAGONO.OUT","w",stdout);

    scanf("%d%d%d%d%d",&N,&M,&S,&P,&Q);

    cant = 3*N*(N-1);

    if(P == N && Q == N)
    {
        int sol = S + cant;

        if(sol <= M+S)
            printf("%d\n",sol);
        else printf("%d\n",0);
    }
    else
        printf("%d\n",S*Q+(P+1));

   may = S + M - 1;

    if(S != 0)
   printf("%d %d\n",may/S,(may-1)/S);

    return 0;
}
