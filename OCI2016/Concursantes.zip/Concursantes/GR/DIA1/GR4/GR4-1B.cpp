/***********************************
*  NAME : David Dominguez Gonzalez *
*  SCHOOL: Silberto Alvarez Aroche *
*  PROVINCE : Granma               *
*                                  *
************************************/

#include<bits/stdc++.h>

using namespace std;

int N,L,S,sol;
bool take[30001];
string arr[30001];

bool S_code(string a,string b)
{
    int C = 0;
    for(int i=0; i<a.size(); i++)
    {
        if(a[i] != b[i]) C++;
        if(C>1) return false;
    }
    return true;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);

    scanf("%d%d%d",&N,&L,&S);

    for(int i=0; i<N; i++)
    {
        cin >> arr[i];

        for(int j=i; j>=0; j--)
            if(j != i && S_code(arr[i],arr[j]))
                sol++;
    }

    printf("%d\n",sol);

    return 0;
}

