/***********************************
*  NAME : David Dominguez Gonzalez *
*  SCHOOL: Silberto Alvarez Aroche *
*  PROVINCE : Granma               *
*                                  *
************************************/

#include<bits/stdc++.h>

using namespace std;

typedef pair <int,int> Pii;
queue <Pii> Q;
int N,M,K,Sol;
char arr[201][201];

void BFS()
{
    Q.push((Pii)
    {
        1,1
    });

    while(!Q.empty())
    {
        int a = Q.front().first;
        int b = Q.front().second;

        Q.pop();


        if(arr[a+1][b]== '#') arr[a+1][b]='0';
        if(arr[a][b+1]== '#') arr[a][b+1]='0';

        if(max((arr[a+1][b]-'0'),(arr[a][b+1]-'0')) == (arr[a+1][b]-'0'))
        {
            cout<<"D";
            Q.push((Pii)
            {
                a+1,b
            });
            Sol++;
        }

        else
        {
            cout<<"R";
            Q.push((Pii)
            {
                a,b+1
            });
            Sol++;
        }

        if(Sol == K || (Q.front().first < 1 || Q.front().first > N) || (Q.front().second < 1 || Q.front().second > M)) break;
    }
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("ROBOT.IN","r",stdin);
    freopen("ROBOT.OUT","w",stdout);

    scanf("%d%d%d",&N,&M,&K);

    for(int i=1; i<=N; i++)
        scanf("%s",arr[i]+1);

    BFS();

    cout<<endl;
    return 0;
}
