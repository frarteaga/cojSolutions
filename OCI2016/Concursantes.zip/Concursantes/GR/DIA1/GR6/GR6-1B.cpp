/********************************
*Leonardo Ledea Santana         *
*11                             *
*IPVCE:"Silberto Alvarez Aroche"*
********************************/
#include<iostream>
#include<cstdio>

using namespace std;

int con=0,c=0;
long long cont=0;

int N,L,S;

string s,h;

int main()
{

    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);

    cin>>N>>L>>S;
    for(int i=0; i<N; i++)
    {
        cin>>s;

        for(int j=0; j<s.size(); j++)
            for(int k=0; k<h.size(); k++)

                if(s[j]==h[k])
                {
                    c++;
                }

        con=c+1;
        if(con==L)
        {
            cont++;
        }

        c=0;
        h=s;

    }
    cout<<cont+1<<endl;
    return 0;
}

