/********************************
*Leonardo Ledea Santana         *
*11                             *
*IPVCE:"Silberto Alvarez Aroche"*
********************************/
#include<iostream>
#include<cstdio>

using namespace std;

int N,M,S,P,Q;
int cont=0,con=0;

int main()
{
    freopen("HEXAGONO.IN","r",stdin);
    freopen("HEXAGONO.OUT","w",stdout);
cin>>N>>M>>S>>P>>Q;
cont=N+N+1;
if(con<=P){
cout<<0<<endl;
cout<<cont/2<<" "<<(cont/2)-1<<endl;
}
else{
    cout<<M<<endl;
cout<<cont/2<<" "<<(cont/2)-1<<endl;
}
    return 0;
}
