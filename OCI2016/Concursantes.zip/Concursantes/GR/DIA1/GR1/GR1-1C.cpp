/*
Ernesto Rosales Olivera 12
Granma
*/
#include<iostream>
#include<cstring>
#include<queue>
#include<algorithm>
#include<cstdio>

using namespace std;

int N,M,K;
int dp[202][202];
int best,x_ini,y_ini;
int path[202][202];
char camp[202][202];
string cam,new_cad;
priority_queue<pair<int,pair<int,int> > >Q;

string get_path(int x,int y)
{
    string sol="";
    while(path[x][y])
    {

    //cout<<x<<" "<<y<<endl;
        if(path[x][y]==1)
            {
                sol+='D';
                x--;
            }
        else
            {
                 sol+='R';
                 y--;
            }
    }

    reverse(sol.begin(),sol.end());
    return sol;
}

bool check(string c,int l)
{
    for(int j=l;j<c.size();j+=l)
        for(int i=0,k=j;i<i+l && k<c.size() && k<c.size();i++,k++)
            {
              if(c[i]!=c[k])return false;
            }
            return true;
}

bool comp(string c)
{
    if(c.size()<=K)
        {
            new_cad=c;
            return true;
        }
    for(int l=K;l>=1;l--)
        if(check(c,l))
        {
            new_cad=c.substr(0,l);
            return true;

        }

        return false;
}

int main()
{
    freopen("ROBOT.IN","r",stdin);
    freopen("ROBOT.OUT","w",stdout);

    cin>>N>>M>>K;

       for(int i=0; i<N; i++)
           cin>>camp[i];

    for(int i=0; i<N; i++)
        for(int j=0; j<M; j++)
            if(camp[i][j]!='#')
        {
            //cout<<i<<" "<<j<<endl;
            if(i-1>=0 && camp[i-1][j]!='#')
            {
                int u=dp[i-1][j]+(camp[i][j]-'0');
                if(dp[i][j]<u)
                {
                    dp[i][j]=u;
                    if(i==N-1 || j==M-1)Q.push(make_pair(dp[i][j],make_pair(i,j)));
                    path[i][j]=1;
                }
            }
            if(j-1>=0 && camp[i][j-1]!='#')
            {
                int l=dp[i][j-1]+(camp[i][j]-'0');
                if(dp[i][j]<l)
                {
                    dp[i][j]=l;
                    if(i==N-1 || j==M-1)Q.push(make_pair(dp[i][j],make_pair(i,j)));
                    path[i][j]=2;
                }
            }
        }

     while(!Q.empty())
     {
         //cout<<Q.top().second.first<<""<<Q.top().second.second<<endl;
          cam=get_path(Q.top().second.first,Q.top().second.second);
          if(comp(cam))
          {
              cout<<new_cad<<"\n";
              break;
          }
          Q.pop();
     }

    //cout<<best<<" "<<x_ini<<" "<<y_ini<<endl;

    return 0;
}
/*
3 4 3
012#
#045
6###
*/
