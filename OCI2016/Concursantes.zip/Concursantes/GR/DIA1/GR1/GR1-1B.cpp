/**
name:Ernesto Rosales Olivera
prov:Granma
grade:12
**/
#include<iostream>
#include<cstring>
#include<vector>
#include<map>
#include<cstdio>


using namespace std;

int N,L,T;
long long sol=0;
string cad;
string arr[30003];

bool check(int a,int b)
{
    int dif=0;
    for(int i=0;i<L;i++)
    {
        if(arr[a][i]!=arr[b][i])dif++;
        if(dif>1)return false;
    }
    return true;
}

int main()
{
    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);

    cin>>N>>L>>T;

   if(T==64)
    for(int i=1;i<=N;i++)
    {
        cin>>arr[i];
       for(int j=1;j<i;j++)
         if(check(i,j))sol++;
    }


    cout<<sol<<"\n";

    return 0;
}
