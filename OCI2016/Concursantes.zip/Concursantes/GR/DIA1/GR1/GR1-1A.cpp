/*
Ernesto Rosales Olivera
12 Granama
*/
#include<iostream>
#include<cstdio>

using namespace std;

unsigned long long  N,P,Q,val,x=1,y=0,x_sol,y_sol,sol=0,S,M,v1,v2,v3;
int dx[]= {0,1,1,0,-1,};
int dy[]= {1,1,-1,-1,0};

void succes()
{
    unsigned long long val=S-1;
    v1=2*(N-1)-1;
    v2=N-1;
    v3=N;
    while(val<S+M)
    {
        for(int i=1; i<=v3; i++)
        {
            x+=dx[0];
            y+=dy[0];
            val++;
            if(val==M+S-1)
            {
                x_sol=x;
                y_sol=y;
               return;
            }
            if(x==P && y==Q)sol=val;

            //cout<<" m1 -> "<<x<<" "<<y<<" "<<val<<endl;
        }
        for(int i=1; i<=v2; i++)
        {
            x+=dx[1];
            y+=dy[1];
            val++;
            if(val==M+S-1)
            {
                x_sol=x;
                y_sol=y;
               return;
            }
            if(x==P && y==Q)sol=val;

            //cout<<" m2 -> "<<x<<" "<<y<<" "<<val<<endl;
        }
        for(int i=1; i<=v2; i++)
        {
            x+=dx[2];
            y+=dy[2];
            val++;
            if(val==M+S-1)
            {
                x_sol=x;
                y_sol=y;
               return;
            }
            if(x==P && y==Q)sol=val;

            //cout<<" m3 -> "<<x<<" "<<y<<" "<<val<<endl;
        }
        for(int i=1; i<=v2; i++)
        {
            x+=dx[3];
            y+=dy[3];
            val++;
            if(val==M+S-1)
            {
                x_sol=x;
                y_sol=y;
                return;
            }
            if(x==P && y==Q)sol=val;

           //cout<<" m4 -> "<<x<<" "<<y<<" "<<val<<endl;
        }
        for(int i=1; i<=v1; i++)
        {
            x+=dx[4];
            y+=dy[4];
            val++;
            if(val==M+S-1)
            {
                x_sol=x;
                y_sol=y;
               return;
            }
            if(x==P && y==Q)sol=val;

            //cout<<" m5 -> "<<x<<" "<<y<<" "<<val<<endl;
        }
        v2--;
        v1-=2;
        v3--;
    }

}

int main()
{
    freopen("HEXAGONO.IN","r",stdin);
    freopen("HEXAGONO.OUT","w",stdout);

    cin>>N>>M>>S>>P>>Q;

    succes();

    cout<<sol<<"\n";
    cout<<x_sol<<" "<<y_sol<<"\n";


    return 0;
}
/*
3 16 5 2 3

2 7 1 2 3

3 19 1 3 2

4 36 1 5 4
*/
