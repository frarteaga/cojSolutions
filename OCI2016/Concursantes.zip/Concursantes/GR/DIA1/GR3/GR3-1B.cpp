/// Granma
/// IPVCE Silberto �lvarez Aroche
/// nombre: Denisel Dariel Ar�valo Quesada
/// GR3-1B

#include<iostream>
#include<cstdio>
#include<cstring>
#include<map>

using namespace std;

string S,ACR[100001],TEN[100001];

int N,L,T;

int con=0;

int F(string A,string B)
{
    int sol=0;
    for(int k=0; k<A.size(); k++)
        if(A[k]!=B[k])
        {
            sol++;
        }
    if(sol==1)return sol;
    return 0;

}

int main()
{
    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);

    int c,a=0;
    scanf("%d%d%d",&N,&L,&T);
    for(int i=1; i<=N; i++)
    {
        cin>>S;
        for(int k=0; k<a+1; k++)
        {
            con+=F(ACR[k],S);
        }
        ACR[a++]=S;

    }
    printf("%d\n",con);
}
