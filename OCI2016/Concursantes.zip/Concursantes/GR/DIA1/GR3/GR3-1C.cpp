/// Granma
/// IPVCE Silberto �lvarez Aroche
/// nombre: Denisel Dariel Ar�valo Quesada
/// GR3-1C

#include<iostream>
#include<queue>
#include<algorithm>
#include<cstdio>

using namespace std;

int mx[]= {0,1};
int my[]= {1,0};
string SOL;
queue<pair<int,int> >Q;
char S[1001][1001];
int N,M,K;
void BF(int i,int j)
{

    Q.push(make_pair(i,j));

    while(!Q.empty())
    {
        int x=Q.front().first;
        int y=Q.front().second;
        Q.pop();

        for(int k=0; k<2; k++)
        {
            if(x+mx[k]>=0 && x+mx[k]<N && y+my[k]>=0 && y+my[k]<M && S[x+mx[k]][y+my[k]]-'0'>=1 && S[x+mx[k]][y+my[k]]-'0'<=9)
            {
                Q.push(make_pair(x+mx[k],y+my[k]));
                if(mx[k]==1 && my[k]==0)SOL+='D';
                if(mx[k]==0 && my[k]==1)SOL+='R';

            }

        }

    }


}

int main()
{


freopen("ROBOT.IN","r",stdin);
freopen("ROBOT.OUT","w",stdout);

    cin>>N>>M>>K;

    for(int i=0; i<N; i++)
        for(int j=0; j<M; j++)
            cin>>S[i][j];
    int con=0;
    for(int i=0; i<N; i++)
        for(int j=0; j<M; j++)
            if(S[i][j]-'0'>=1)
            {
                con++;
                BF(i,j);


            }

    reverse(SOL.begin(),SOL.end());

    for(int l=0; l<K; l++)
        cout<<SOL[l];

cout<<"\n";


}
