/*************************************
* Concurso Nacional de Computacion   *
*                                    *
* Nombre: Jordan Gamboa Ballester    *
*                                    *
* Provincia: Granma   10mo Grado     *
*                                    *
**************************************/

#include<bits/stdc++.h>

using namespace std;


int N,S,L;

char CT[10000];

bool CS(int a,int b)
{
    for(int i=0; i<L; i++)
        cin>>CT[i];

    return CS;
}

int main()
{
    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);

    cin>>N>>L>>S;

    for(int i=0; i<N*L; i++)
        cin>>CT[i];


    cout<<N;

    return 0;
}
