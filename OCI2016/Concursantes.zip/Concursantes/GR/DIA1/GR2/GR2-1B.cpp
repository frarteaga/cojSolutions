/********************************************
 *  Nombre:Manuel Alejandro Arjona Garcia.  *
 *  Provincia:Granma.                       *
 *  Grado:12.                               *
 *  Problema:CUENTAS.                       *
 ********************************************/

#include<iostream>
#include<cstdio>
#include<map>

using namespace std;

char a[30001][201];

int n,len,z,sol=0,alf;

map<pair<char*,int>,int >M;

main()
{

    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);

    scanf("%d%d%d",&n,&len,&alf);

    for(int i=0; i<n; i++)
    {
        scanf("%s",a[i]);

        for(int j=i-1; j>=0; j--)
        {
            bool t=false;
            int pos=0;
            for(int k=0; k<len; k++)
            {
                if(a[i][k]!=a[j][k])
                {
                    if(M[make_pair(a[i],k)]){t=false;break;}
                    if(!t)
                    {
                        t=true;
                        pos=k;
                    }
                    else
                    {
                        t=false;
                        break;
                    };
                }
            }
        if(t && !M[make_pair(a[j],pos)] )M[make_pair(a[i],pos)]++;
        else if(t && M[make_pair(a[j],pos)] && !M[make_pair(a[i],pos)])
        {
            M[make_pair(a[i],pos)]+=M[make_pair(a[j],pos)]+1;
            M[make_pair(a[j],pos)]=0;
            break;
        }
    }
     }
    for(map<pair<char*,int>,int >::iterator p=M.begin(); p!=M.end(); p++)
    {
            int z=p->second;
            if(z)sol+=z*(z+1)/2;
    }

    printf("%d\n",sol);

}/*
4 3 64
Fax
fax
max
mac


*/
