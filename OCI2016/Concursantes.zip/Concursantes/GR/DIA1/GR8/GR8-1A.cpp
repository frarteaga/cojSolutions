/***********************************
 *  Nombre: Jiorvis Moreira Torres *
 *  Grado: 10mo                    *
 *  Tema: Hexagono con espiral     *
 ***********************************/

#include <bits/stdc++.h>

using namespace std;

deque < int > V;

int A[1000][1000];

int main()
{
    ///freopen("HEXAGONO.IN", "r", stdin);
    ///freopen("HEXAGONO.OUT", "w", stdout);
    int n, m, s, p, q;
    cin>>n>>m>>s>>p>>q;
    for (int i = s; i < s+m; i++)
        V.push_back (i);
    while (!V.empty())
    {
        int x = V.front();
        V.pop_front();
    }

}
