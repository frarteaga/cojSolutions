/********************************
* NOMBRE:CARLOS SILVENTE ARAUJO *
* PROVINCIA:GRM                 *
* PROBLEMA:1A-GRM5              *
********************************/
#include<bits/stdc++.h>
#define MAXX 301
int n,m,s,p,q;

void REC(int i,int j)
{
    if(i==s&&j==s)return ;
    else
        REC(i-1,j-1);
}
using namespace std;
int main()
{

    freopen("HEXAGONO.IN","r",stdin);
    freopen("HEGAGONO.OUT","w",stdout);
    int mat[MAXX][MAXX];

    cin>>n>>m>>s>>p>>q;

    int C=mat[n][n]=(n*6)+s;//centro case base;

    for(int i=C; i>s; i--)
        for(int j=C; j>s; j--)
        {
            mat[i][j]=mat[i-1][j-1]-1;

        }
    cout<<mat[p][q]<<endl;
    cout<<n<<" "<<n<<endl;
return 0;
}
