/********************************
* NOMBRE:CARLOS SILVENTE ARAUJO *
* PROVINCIA:GRM                 *
* PROBLEMA:1B-GRM5              *
********************************/
#include<bits/stdc++.h>
#define MAXX 30001

using namespace std;

int n,l,s,pos,sol,c;

string cad;
string V[MAXX];
stack<string>Q;

int main()
{

    freopen("CUENTAS.IN","r",stdin);
    freopen("CUENTAS.OUT","w",stdout);

    scanf("%d%d%d",&n,&l,&s);

    for(int i=0; i<n; i++)
    {
        cin>>cad;
        V[i]=cad;
        Q.push(cad);
    }

    while(!Q.empty())
    {
        c=0;
        string str=Q.top();
        Q.pop();

        for(int i=0; i<l; i++)
        {
            if(V[pos]!="")
            {

                if(V[pos][i]!=str[i])
                {
                    c++;
                    if(c>1)
                        break;
                }

            }

        }

        if(c==1)
            sol++;

        if(Q.empty()&&pos!=n)
        {
            V[pos]="";
            pos++;

            for(int i=0; i<n; i++)
                if(V[i]!="")
                {
                    Q.push(V[i]);
                }
        }
    }

    printf("%d\n",sol);
    return 0;
}

