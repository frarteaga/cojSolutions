/************************************************
** Concurso Nacional de Informatica             *
** provincia:Granma                             *
** nombre:Rene Alcolea Perez                    *
** escuela:IPVCE"Silberto Alvarez Aroche"       *
** grado:10mo                                   *
*************************************************/
#include<bits/stdc++.h>
using namespace std;
string T;

int main()
{
    /* freopen("cuentas.in","r",stdin);
       freopen("cuentas.out","w",stdout);*/
    int N, L, S;
    cin>>N>>L>>S;
    for(int i=0; i<N; i++)
    {
        if(S==64)
        {
            cin>>T;
        }
        else if(S==2)return false;

    }
    cout<<N<<"\n";

    return 0;
}
