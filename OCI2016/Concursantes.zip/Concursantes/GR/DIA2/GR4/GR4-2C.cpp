/***********************************
* NAME : David Dominguez Gonzalez  *
* SCHOOL : Silberto Alvarez Aroche *
* PROVINCE : Granma                *
*                                  *
************************************/
#include<bits/stdc++.h>

using namespace std;

int N,L,W,H,x,y,Nx,Ny,sol,si;

int MCD(int a,int b)
{
    if(b == 0) return a;
    else return MCD(b,a%b);
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("FUMIGACION.IN","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);

    scanf("%d%d%d%d",&N,&L,&W,&H);

    for(int i=0; i<N; i++)
    {
        si++;
        scanf("%d%d",&x,&y);

        if(x == H || y == H) Nx++;
        if(x == W || y == W) Ny++;

        if((H - MCD(H,W)) == Nx && (W - MCD(H,W)) == Ny)
            sol = si;
    }

    printf("%d\n",sol - MCD(W,H));

    return 0;
}
