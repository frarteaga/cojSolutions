/***********************************
* NAME : David Dominguez Gonzalez  *
* SCHOOL : Silberto Alvarez Aroche *
* PROVINCE : Granma                *
*                                  *
************************************/
#include<bits/stdc++.h>

using namespace std;

int A[36],B[36],C[36],cc,N,K,M,sol,e;

int conv(int n,int k)
{
    return (n==k || k==0) ? 1 : conv(n-1,k-1) + conv(n-1,k);
}
bool take[72]= {false};

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);

    scanf("%d",&N);

    scanf("%d",&M);
    for(int i=0; i<M; i++)
    {
        scanf("%d",&A[i]);
        take[A[i]]  = true;
    }

    sort(A,A+M);

    scanf("%d",&K);
    for(int i=0; i<K; i++)
    {
        scanf("%d",&B[i]);
        take[B[i]]  = true;
    }

    sort(B,B+K);

    for(int i=1; i<2*N; i++)
        if(!take[i]) C[e++] = i;
    sort(C,C+e);

    cc = 2*N - (M+K);
    int aux = cc;

  for(int j=0;j<M;j++)
    for(int i=0;i<=e;i++)
    {
        if(A[j] > C[i])  cc--;
    }

   for(int i=e;i>=0;i--)
    for(int j=K-1;j>=0;j--)
   {
       if(C[i] > B[j]) cc--;
       else break;
   }

   if(aux-(cc+M) == 2) sol = 2;
   else sol = conv(aux-(cc+M),2);

    printf("%d\n",sol);

    return 0;
}
