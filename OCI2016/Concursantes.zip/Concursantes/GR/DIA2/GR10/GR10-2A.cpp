/*************************************
* Concurso Nacional de Computacion   *
*                                    *
* Nombre: Jordan Gamboa Ballester    *
*                                    *
* Provincia: Granma   10mo Grado     *
*                                    *
**************************************/

#include<bits/stdc++.h>

using namespace std;

char M[36],K[36];

int main()
{
    freopen("TABLAS.IN","w",stdin);
    freopen("TABLAS.OUT","r",stdout);

    int N;
    int cont=0;

    cin>>N;

    for(int i=1; i<N; i++)
        cin>>M[i];

    for(int h=1; h<N; h++)
        cin>>K[h];

    sort(M, M + N);
         cont++;

    sort(K, K + N);
         cont++;

    cout<<cont;


    return 0;
}
