/************************************************
** Concurso Nacional de Informatica            **
** Provincia: Granma                           **
** nombre: Rene Adrian Alcolea Perez           **
** escuela: IPVCE"Silberto Avarez Aroche"      **
** grado: 10mo                                 **
*************************************************/
#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;

int M[10000], K[10000];

int main()
{
    freopen("tablas.in","r",stdin);
    freopen("tablas.out","w",stdout);

    int N;
    int c=0;
    cin>>N;

    for(int i=1; i<N; i++)
        cin>>M[i];

    sort(M, M+N);
    c++;
    sort(K,K+N);
    c++;

    for(int j=0; j<N; j++)
        cin>>K[j];

    cout<<c<<"\n";
    return 0;
}
/*
4
2 3 2
3 4 8 7
*/
