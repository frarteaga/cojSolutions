/********************************************
 *  Nombre:Manuel Alejandro Arjona Garcia.  *
 *  Provincia:Granma.                       *
 *  Grado:12.                               *
 *  Problema:TABLAS.                        *
 ********************************************/

#include<iostream>
#include<queue>
#include<vector>
#include<cstdio>
#include<set>

using namespace std;

typedef priority_queue<int,vector<int>,greater<int> > QQ;

QQ A,B,C,X,Y;

int n,a,b,sol=0,x;

bool t[101];

void comp(QQ a,QQ b)
{
    while(!a.empty())
    {
        if(a.top()>b.top())break;
        a.pop();
        b.pop();
    }

    if(!a.size())sol++;

}

void Buscar_pos_sol(QQ A,QQ B,QQ C)
{
    if(C.empty())
    {
        comp(A,B);
        return;
    }
    if(A.size()<n)
    {
        X=A;
        Y=C;
        X.push(C.top());
        Y.pop();
        Buscar_pos_sol(X,B,Y);
    }
    if(B.size()<n)
    {
        X=B;
        Y=C;
        X.push(C.top());
        Y.pop();
        Buscar_pos_sol(A,X,Y);
    }
}
main()
{
    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);
    cin>>n;

    cin>>a;

    for(int i=0; i<a; i++)
    {
        cin>>x;
        A.push(x);
        t[x]=1;
    }

    cin>>b;

    for(int i=0; i<b; i++)
    {
        cin>>x;
        B.push(x);
        t[x]=1;
    }

    for(int i=1; i<=2*n; i++)
        if(!t[i])C.push(i);

    Buscar_pos_sol(A,B,C);

    printf("%d\n",sol);
    return 0;
}
