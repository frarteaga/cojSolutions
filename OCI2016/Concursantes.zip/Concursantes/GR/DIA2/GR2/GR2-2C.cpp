/********************************************
 *  Nombre:Manuel Alejandro Arjona Garcia.  *
 *  Provincia:Granma.                       *
 *  Grado:12.                               *
 *  Problema:FUMIGACION.                    *
 ********************************************/

#include<cstdio>
#include<iostream>

using namespace std;

int n,m,x,y;

struct point{
int x,y;
}P[100001];

main(){

  freopen("FUMIGACION.IN","r",stdin);
  freopen("FUMIGACION.OUT","w",stdout);

  cin>>n>>m>>x>>y;

  for(int i=0;i<n;i++){
    scanf("%d %d",&P[i].x,&P[i].y);
  }

  if(x==m && y==m){cout<<1<<endl;return 0;}
  else printf("-1\n");
  return 0;

}
