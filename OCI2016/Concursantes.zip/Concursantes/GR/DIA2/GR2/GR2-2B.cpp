/********************************************
 *  Nombre:Manuel Alejandro Arjona Garcia.  *
 *  Provincia:Granma.                       *
 *  Grado:12.                               *
 *  Problema:RUTAS.                         *
 ********************************************/

#include<cstdio>
#include<iostream>
#include<vector>
#include<queue>
#include<map>
#include<cstdlib>
#include<cstring>

#define MAXN 500001

using namespace std;

typedef pair<int,int>par;
typedef long long LL;

int n,a,b,c;

map<par,bool> make;

vector<par>V[MAXN];
par G[MAXN];
bool t[MAXN];
int DFS(int node)
{
    if(!V[node].size())return 0;
    t[node]=1;
    int sum=0;

    for(int i=0; i<V[node].size(); i++)
    {
        int next=V[node][i].first;
        if(!make[par(node,next)] && !t[next])
        {
            sum=max(DFS(next)+V[node][i].second,sum);
        }
    }
    return sum;
}


LL Buscar_dos_max_ramas(int node)
{
    t[node]=1;
    LL may1=0,may2=0;
    for(int i=0; i<V[node].size(); i++)
    {
        if(!make[par(node,V[node][i].first)])
        {
            int val=DFS(V[node][i].first)+V[node][i].second;
            if(val>may1)
            {
                may2=may1;
                may1=val;
            }
            else if(val>may2)may2=val;
        }
    }
    return may1+may2;
}


main()
{
    freopen("RUTAS.IN","r",stdin);
    freopen("RUTAS.OUT","w",stdout);

    cin>>n;

    for(int i=0; i<n-1; i++)
    {
        scanf("%d%d%d",&a,&b,&c);
        V[a].push_back(par(b,c));
        V[b].push_back(par(a,c));
        G[i]=par(a,b);
    }

    for(int i=0; i<n-1; i++)
    {
        make[par(G[i].first,G[i].second)]=1;
        make[par(G[i].second,G[i].first)]=1;

        fill(t,t+MAXN+1,0);
        LL val1=Buscar_dos_max_ramas(G[i].first);
        LL val2=Buscar_dos_max_ramas(G[i].second);
        cout<<min(val1,val2)<<" "<<(max(val2,val1))<<endl;
    }

    return 0;
}
/*
10
1 2 5
2 3 2
2 4 1
3 5 4
3 6 3
4 7 2
4 8 3
1 9 3
9 10 1


*/


