//Ernesto Rosales Olivera GR 12
#include<iostream>
#include<cstdio>

using namespace std;

int C,N,M,n;

int main()
{

    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);

    cin>>C;

    cin>>N;
    for(int i=1;i<=N;i++)cin>>n;
    cin>>M;
    for(int i=1;i<=M;i++)cin>>n;

    if(C-N==0)cout<<M<<endl;
    else if(C-M==0)cout<<N<<endl;
    else cout<<(C-N)*(C-M)<<"\n";

}
