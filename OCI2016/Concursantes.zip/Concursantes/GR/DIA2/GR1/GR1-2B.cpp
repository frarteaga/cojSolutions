/*
Ernesto Rosales Olivera Granma 12
*/
#include<iostream>
#include<vector>
#include<set>
#include<map>
#include<queue>
#include<cstdio>

using namespace std;

int V,a,b,c,sol=0,val=0,max1,max2;
map<int,map<int,bool> >M;
vector<pair<int,int> >G[500005];
queue<pair<int,int> >Q;
bool mark[500005];
bool taked[500005];

int deter(int node,int ac)
{
    //cout<<" deter -> "<<node<<" "<<ac<<endl;
    val=max(val,ac);
    for(int i=0; i<G[node].size(); i++)
    {
        int next=G[node][i].first;
        int cost=G[node][i].second;
        if(!M[node][next] && !taked[next])
        {
            taked[next]=true;
            deter(next,ac+cost);
            taked[next]=false;
        }

    }
}
void comp(int node)
{
    //cout<<"comp-> "<<node<<endl;
    val=0;
    taked[node]=true;
    deter(node,0);
    sol=max(val,sol);
    taked[node]=false;
    for(int i=0; i<G[node].size(); i++)
    {
        int next=G[node][i].first;
        if(!M[node][next] && !mark[next])
        {
            mark[next]=true;
            comp(next);
            mark[next]=false;
        }

    }
}

int main()
{
    freopen("RUTAS.IN","r",stdin);
    freopen("RUTAS.OUT","w",stdout);

    cin>>V;

    for(int i=1; i<V; i++)
    {
        cin>>a>>b>>c;
        G[a].push_back(make_pair(b,c));
        G[b].push_back(make_pair(a,c));
        Q.push(make_pair(a,b));
    }

    while(!Q.empty())
    {
        a=Q.front().first;
        b=Q.front().second;
        Q.pop();

        M[a][b]=M[b][a]=true;
        sol=0;
        mark[a]=true;
        //cout<<" node-> "<<a<<endl;
        comp(a);
        mark[a]=false;
        max1=sol;
        sol=0;
        mark[b]=true;
        //cout<<" node-> "<<b<<endl;
        comp(b);
        mark[b]=false;
        max2=sol;

        if(max1>max2)swap(max1,max2);
        cout<<max1<<" "<<max2<<"\n";

    }


    return 0;
}
/*
5
1 2 2
2 3 1
2 4 2
1 5 3
*/
