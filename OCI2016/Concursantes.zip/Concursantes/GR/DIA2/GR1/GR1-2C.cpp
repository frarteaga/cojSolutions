/**
Ernesto Rosales Olivera 12 Granma
**/
#include<iostream>
#include<cstdio>

using namespace std;

int N,L,W,H,x=1,y=1,act;
pair<int,int> arr[100001];

bool check()
{
    int i,j,k;
    for(i=min(x,y); i<=L; i++)
        for(j=min(x,y); j<=L; j++)
        {

            bool ok=false;
            if(i-W>=0 && j-H>=0)
            {
                //if(i==5 && j==4)
                //cout<<"ok\n";

                for(k=1; k<=act; k++)
                {
                    if(arr[k].first<i && arr[k].first>i-W
                            && arr[k].second<j && arr[k].second>j-H)
                            {
                                //cout<<i<<" "<<j<<" "<<arr[k].first<<" "<<arr[k].second<<" ok1\n";
                                ok=true;
                            }

                }
                if(!ok)
                    {
                        x=i;
                        y=j;
                        return true;
                    }

            }

            if(i-H>=0 && j-W>=0)
            {
                //if(i==4 && j==2)
                //cout<<"ok\n";
                for(k=1; k<=act; k++)
                {
                    if(arr[k].first<i && arr[k].first>i-H
                            && arr[k].second<j && arr[k].second>j-W)
                            {
                                //cout<<i<<" "<<j<<" "<<arr[k].first<<" "<<arr[k].second<<" ok2\n";
                                 ok=true;
                            }

                }
                if(!ok)
                    {
                        x=i;
                        y=j;
                        return true;
                    }
            }


        }
        //cout<<"nada con este\n";
    return false;
}

int main()
{

    freopen("FUMIGACION.IN","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);

    cin>>N>>L>>W>>H;

    for(int i=1; i<=N; i++)
    {
        act=i;
        cin>>arr[i].first>>arr[i].second;
        if(!check())
        {
            cout<<i<<"\n";
            return 0;
        }
    }

    cout<<"-1\n";

    return 0;
}
/*
14 10 5 4
3 4
0 2
5 1
10 10
4 0
8 7
2 7
6 5
9 2
7 3
5 8
6 5
4 2
3 6
*/
