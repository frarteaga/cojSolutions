/********************************
* NOMBRE:CARLOS SILVENTE ARAUJO *
* 11noGRADO                     *
* PROVINCIA:GRM                 *
* PROBLEMA:2A-GR5               *
********************************/
#include<bits/stdc++.h>
using namespace std;
#define maxx 40
bool mark[maxx*2],mk[maxx];
int n,m,k,sol=1,A[maxx],B[maxx],C[maxx];

int pos,pos2;

int main()
{
    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);

    scanf("%d",&n);

    scanf("%d",&m);

    for(int i=1; i<=m; i++)
    {
        cin>>A[i];
        mark[A[i]]=true;
    }

    scanf("%d",&k);
    for(int i=1; i<=k; i++)
    {
       cin>>B[i];
        mark[B[i]]=true;
    }
    for(int i=1; i<=2*n; i++)
        if(!mark[i]){
            C[pos]=i;
        pos++;
        }
    for(int i=1; i<=n; i++){

        if(C[i]<A[pos]&&!mk[i]){
            mk[i]=true;

        }
        if(C[i]>A[pos]&&!mk[i]){

            if(C[i]>B[pos]&&!mk[i])
              mk[i]=true;
        }
        else pos++;
              if(pos==n)
            sol++;
        }
        cout<<sol<<endl;

    return 0;

    }




