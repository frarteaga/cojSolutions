/********************************
* NOMBRE:CARLOS SILVENTE ARAUJO *
* 11noGRADO                     *
* PROVINCIA:GRM                 *
* PROBLEMA:2C-GR5               *
********************************/

#include<bits/stdc++.h>
# define maxx 1000000001
int n,sol;
bool mat[maxx];
long  l,w,h,x,y;
using namespace std;
int main()
{
    typedef pair <int,int> par;
    deque<par>Q;

    freopen("FUMIGACION.IN","r",stdin);
     freopen("FUMIGACION.OUT","w",stdout);


    cin>>n;
    cin>>l>>w>>h;
    for(int i=0; i<n; i++)
    {
        cin>>x>>y;
        Q.push_back(par(x,y));
    }
if(l>1001){
    cout<<"-1"<<endl;
return 0;
}
    while(!Q.empty())
    {
        int x=Q.front().first;
        int y=Q.front().second;
        Q.pop_front();

        if(x<=w&&-y>=-h)
        {
            mat[x]=true;
            mat[-y]=true;
        }
        else sol++;
    }
    for(int i=-h; i<=w; i++)
        if(mat[i]==true&&mat[i+1]==true)
            sol++;
    if(sol!=0)
    {
        cout<<sol<<endl;
    }
    else
        cout<<"-1"<<endl;


    return 0;
}

/*
14 10 5 4
3 4
0 2
5 1
10 10
4 0
8 7
2 7
6 5
9 2
7 3
5 8
6 5
4 2
3 6
*/
