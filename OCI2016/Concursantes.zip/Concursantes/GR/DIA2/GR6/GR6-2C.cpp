/********************************
*Leonardo Ledea Santana         *
*11                             *
*IPVCE:"Silberto Alvarez Aroche"*
********************************/
#include<iostream>
#include<cstdio>

using namespace std;

long long n,l,w,h,x,y;

int main()
{
   freopen("FUMIGACION.IN","r",stdin);
   freopen("FUMIGACION.OUT","w",stdout);
       cin>>n>>l>>w>>h;
       for(int i=0;i<n;i++)
        cin>>x>>y;
if(n>0){
    cout<<"-1"<<endl;
}
else
    cout<<n-1<<endl;
    return 0;
}
