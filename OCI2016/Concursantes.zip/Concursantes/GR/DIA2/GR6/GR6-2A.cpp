/********************************
*Leonardo Ledea Santana         *
*11                             *
*IPVCE:"Silberto Alvarez Aroche"*
********************************/
#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;

int n,m,k,arr[37],ar[37];
int sum=0,sum1=0,con=0,sumt=0,sol=0,aux=0;
int main()
{
    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);

    cin>>n;
    cin>>m;
    for(int i=0; i<m; i++)
    {
        cin>>arr[i];
        sum+=arr[i];
    }
    cin>>k;
    for(int j=0; j<k; j++)
    {
        cin>>ar[j];
        sum1+=ar[j];
    }
    sort(arr,arr+m);
    sort(ar,ar+k);

    for(int j=0; j<k; j++)
        if(ar[j]==1)
        {
            cout<<0<<endl;
            return 0;
        }
    for(int i=0; i<m; i++)
        if(arr[i]==2*n)
        {
            cout<<0<<endl;
            return 0;
        }
        else if(n==2)
        {
            cout<<1<<endl;
            return 0;
        }

        else
        {
            if(sum>sum1)
            {
                sumt=sum;
            }
            else if(sum<sum1)
            {
                sumt=sum1;
            }

            con=((n*2)*((n*2)+1))/2;
            aux=con-sumt;

            if(aux>sumt)
            {
                sol=aux-sumt;
            }
            else if(aux<sumt)
            {
                sol=sumt-aux;
            }
            cout<<sol<<endl;
        return 0;
}
}
