///Granma
///GR3-2A
///IPVCE Silberto Albarez Aroche
///Denisel Dariel Ar�valo  Quesada

#include<iostream>
#include<algorithm>
#include<cstdio>

using namespace std;

int N,M,K;
int A[101],B[101],C[101];
int Ma[101][101];
bool Mark[101]= {false};

int main()
{

    freopen("TABLAS.IN","r",stdin);
    freopen("TABLAS.OUT","w",stdout);

    cin>>N;
    cin>>M;
    for(int i=1; i<=M; i++)
    {
        cin>>A[i];
        Mark[A[i]]=true;

    }
    cin>>K;
    for(int i=1; i<=K; i++)
    {
        cin>>B[i];
        if(B[i]==1)
        {
            cout<<0<<endl;
            return 0;
        }
        Mark[B[i]]=true;

    }

    for(int i=1; i<=N*2; i++)
        if(Mark[i]==false)C[i]=i;
    Ma[1][1]=1;
    for(int j=1; j<=2; j++)
        for(int k=2; k<=N; k++)
        {

            cout<<M*K-N<<endl;
            return 0;

        }



}
