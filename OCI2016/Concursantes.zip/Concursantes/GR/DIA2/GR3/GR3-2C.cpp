///Granma
///GR3-2C
///IPVCE Silberto Albarez Aroche
///Denisel Dariel Ar�valo  Quesada

#include<iostream>
#include<cmath>
#include<cstdio>

using namespace std;

double mod(double a)
{

    if(a<0)return a*-1;

}

double dis(double x,double y,double x1,double y1)
{
    return sqrt((mod(x-x1)+mod(y-y1)));
}

int N,a=0;
long long L;
double W,H,CON[100001];
struct nodo
{

    double X,Y;

} A[100001];

int main()
{
    freopen("FUMIGACION.IN","r",stdin);
    freopen("FUMIGACION.OUT","w",stdout);

    cin>>N>>L>>W>>H;
    for(int i=1; i<=N; i++)
        cin>>A[i].X>>A[i].Y;
    int con=0;
    for(int i=1; i<=N; i++)
        CON[a++]=dis(W,H,A[i].X,A[i].Y);
    for(int k=0; k<a; k++)
        for(int s=k+1; s<a; s++)
            if(CON[k]>0 && CON[k]==CON[s])
            {
                con++;
            }

    if(con>0)cout<<N-con;
    else cout<<-1<<endl;

}
