/*************************************\
 *  Nombre: Jiorvis Moreira Torres   *
 *  Grado: 10mo                      *
 *  Tema: Tablas con tres conjuntos  *
\*************************************/

#include <bits/stdc++.h>

using namespace std;

int A[1000001];
int B[1000001];
int C[1000001];
priority_queue < int, vector < int >, greater < int > > M;
priority_queue < int, vector < int >, greater < int > > M2;
priority_queue < int, vector < int >, greater < int > > M3;

int main()
{
    ///freopen ("TABLAS.IN", "r", stdin);
    ///freopen ("TABLAS.OUT", "w", stdout);
    int n, m, k;
    cin>>n>>m;
    for (int i=0; i<m; i++)
    {
        cin>>A[i];
        M.push(A[i]);
    }
    cin>>k;
    for (int j=0; j<k; j++)
    {
        cin>>B[j];
        M2.push(B[j]);
    }
    while ( !M.empty() )
    {
        int x = M.top();
        M.pop();
        cout<<x<<" ";
    }
    cout<<endl;
    while ( !M2.empty() )
    {
        int y = M2.top();
        M2.pop();
        cout<<y<<" ";
    }
    cout<<endl;
    for (int l=1; l<=2*n; l++)
    {
        if ( l != M.top() && l != M2.top() )
            M3.push(l);
    }
    while ( !M3.empty() )
    {
        int z = M3.top();
        M3.pop();
        cout<<z<<" ";
    }
    cout<<endl;
    return 0;
}
