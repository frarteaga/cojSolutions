///Maels Le�n Vali�o.*******
///10mo.*******
///GR7.*******
#include <bits/stdc++.h>
using namespace std;
bool Arr[2*36];
int c=0;
void T(int x,int N){
int n;
for(int i=1;i<=x;i++){
    cin>>n;
    if(n==1 || n==2*N ||n==0)c--;
    else if(n==1 && n==2*N)c-=2;
    if(Arr[n]==false){
        Arr[n]=true;
    }
}

}

int main(){
int N,A,B;

freopen("TABLAS.IN","r",stdin);
freopen("TABLAS.OUT","w",stdin);

cin>>N;
cin>>A;
T(A,N);
cin>>B;
T(B,N);
if ((2*N)-(A+B)==1){
    cout<<"1";
    return 0;
}
for(int i=1;i<=(2*N);i++){
    if(Arr[i]==false)c++;
}

cout<<c;

return 0;
}

