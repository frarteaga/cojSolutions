#By FR

def gray(n):
    """
    Retorna un arreglo con los n'umeros decimales que representan
    en base 2 al c'odigo de gray de n bits.
    """
    r = [0, 1]
    for i in xrange(2, n + 1):
        t = r[ : ]
        t.reverse()
        r += t
        for j in xrange(len(r) / 2, len(r)):
            r[j] += 2 ** (i - 1)
    return r

def tobin(n):
    """
    Convierte el decimal n a binario. tobin(10) = '1010'.
    """
    if n == 0:
        return '0'
    r = ''
    while n > 0:
        if n & 1:
            r = '1' + r
        else:
            r = '0' + r
        n >>= 1
    return r


while 1:
	n = int(raw_input())
	if n == 0:
		break
	s = ''
	for gc in gray(n):
		gcs = tobin(gc)
		gcs = '0' * (n - len(gcs)) + gcs
		s += gcs
	print s
    
