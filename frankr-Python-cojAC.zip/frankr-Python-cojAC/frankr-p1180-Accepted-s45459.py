for _ in range(input()):
	r = ''
	for x, y in zip((1, 1, 2, 2, 2, 8), [int(a) for a in raw_input().split(' ')]):
		r += str(x - y) + ' '
	print r