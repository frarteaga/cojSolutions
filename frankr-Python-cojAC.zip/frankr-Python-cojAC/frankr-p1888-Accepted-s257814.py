while 1:
	try:
		n = raw_input()
	except:
		break
	div = int(n) % 6 == 0
	if n[0] == '-':
		n = n[1: ]
	s = sum([int(c) for c in n]) % 6 == 0
	d6 = '6' in n
	if div and s and d6:
		print 'EVIL'
	else:
		print 'GOOD'