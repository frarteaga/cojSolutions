for _ in xrange(int(raw_input())):
  n = int(raw_input())
  print n & (-n)