T = input()

while T > 0:
	T -= 1
	N = input()
	r = N * (N + 1) * (2 * N + 4) / 12
	r *= r
	r %= 10 ** 9 + 7
	print r