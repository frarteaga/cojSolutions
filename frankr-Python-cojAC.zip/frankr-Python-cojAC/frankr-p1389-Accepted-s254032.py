n = raw_input()

l = len(n)

e = 0
while l > 0:
	for p in xrange(len(n) - l + 1):
		if n[p: p + l] == n[p: p + l][::-1]:
			print n[p: p + l]
			e = 1
			break
	if e:
		break
	l -= 1