#By FR

r = [0,0,1,2,24,1344,1128960]

while 1:
	try:
		n = int(raw_input())
		print r[n]
	except:
		break

"""
n = 0
r = 0
a = []

def comb(f, c):
	global n
	global r
	global a
	if f == n:
		r += 1
	else:
		for m in xrange(1, n + 1):
			e = 0
			for j in xrange(f):
				if a[j][c] == m:
					e = 1
					break
			if m in a[f]:
				e = 1
			if e == 0:
				a[f][c] = m
				if c == n - 1:
					comb(f + 1, 0)
				else:
					comb(f, c + 1)
				a[f][c] = 0

while 1:
	try:
		n = int(raw_input())
		a = [None] * n
		for c in xrange(len(a)):
			a[c] = [0] * n
			a[0][c] = c + 1
		r = 0
		comb(1, 0)
		print r
	except:
		break
"""
