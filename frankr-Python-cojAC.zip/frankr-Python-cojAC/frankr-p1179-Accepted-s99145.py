for _ in range(input()):
    n = input()
    a = [int(x) for x in raw_input().split()]
    print (max(a) - min(a)) * 2