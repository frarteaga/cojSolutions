import math
for _ in range(input()):
    o = [int(x) for x in raw_input().split()]
    r = 1
    for x in o:
        r *= math.factorial(x)
    print math.factorial(sum(o)) / r