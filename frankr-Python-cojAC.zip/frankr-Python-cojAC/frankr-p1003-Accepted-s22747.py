#By FR

for _ in xrange(int(raw_input())):
	n, m = [int(x) for x in raw_input().split(' ')]
	a = [0] * n
	for i in xrange(m):
		s = [int(y) for y in raw_input().split(' ')]
		for j in xrange(n):
			a[j] += s[j]
	r = 0
	for j in xrange(1, n):
		if a[j] > a[r]:
			r = j
	print r + 1

