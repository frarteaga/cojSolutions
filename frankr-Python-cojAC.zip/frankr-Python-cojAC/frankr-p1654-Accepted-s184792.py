while 1:
	n, m, y = [int(x) for x in raw_input().split()]
	if n == m == y == 0:
		break
	r = ''
	for x in xrange(m):
		if pow(x, n, m) == y:
			r += str(x) + ' '
	if r == '':
		print -1
	else:
		print r[ : -1]