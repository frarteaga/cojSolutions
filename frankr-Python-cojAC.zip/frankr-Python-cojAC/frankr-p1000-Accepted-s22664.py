a, b = raw_input().split(' ')

print int(a) + int(b)