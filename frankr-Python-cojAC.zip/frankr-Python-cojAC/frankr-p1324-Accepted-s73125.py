R = range(9)
a = [0] * 9
for _ in R:
	a[_] = input()
a.sort()
s = sum(a)
for i in R[: 8]:
	for j in R[i + 1: ]:
		if s - a[i] - a[j] == 100:
			for o in a[: i] + a[i + 1: j] + a[j + 1:]:
				print o	