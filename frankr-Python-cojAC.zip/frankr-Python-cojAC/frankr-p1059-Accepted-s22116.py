# By FR

def ToBin_(n):
	if n == 0:
		return ('0', 0)
	r = ''
	s = 0
	while n > 0:
		s += n & 1
		r = str(n & 1) + r
		n >>= 1
	return (r, str(s))

while 1:
	n = int(raw_input())
	if n == 0:
		break
	rr = ToBin_(n)
	print 'The parity of ' + str(rr[0]) + ' is ' + rr[1] + ' (mod 2).'

