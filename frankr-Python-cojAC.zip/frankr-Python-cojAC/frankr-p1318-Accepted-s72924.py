a=sorted([int(_) for _ in raw_input().split()])
b=[ord(c)-65 for c in raw_input()]
print a[b[0]], a[b[1]], a[b[2]]