for _ in xrange(int(raw_input())):
    e, f, c = [int(x) for x in raw_input().split(' ')]
    if c == 1:
        print 0
        continue
    if e + f == 0:
        print 0
        continue
    n = e + f
    r = 0
    while n >= c:
        r += (n / c)
        n = (n / c) + (n % c)
    print r
