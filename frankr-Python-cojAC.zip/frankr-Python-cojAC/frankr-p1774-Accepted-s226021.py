a = raw_input()
i = 1
r = a[0]
while i < len(a):
	if a[i].upper() == a[i]:
		r = ''
		for c in a:
			if c.upper() == c:
				r += c.lower()
			else:
				r += c.upper()
		break
	r += a[i]
	i += 1
print r