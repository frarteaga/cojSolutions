st = o = 0

for _ in xrange(int(raw_input())):
    x = int(raw_input())
    st += x
    o += (_ & 1) * x

print max(o, st - o), min(o, st - o)