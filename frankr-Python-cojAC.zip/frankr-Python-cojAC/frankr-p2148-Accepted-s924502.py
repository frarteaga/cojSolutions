def f(a, b, c):
    if (b**2-4*a*c)<0:
        return False
    return True
for i in range (input ()) :
    a, b, c=[int(j) for j in raw_input().split(" ")]
    if f(a, b, c):
        print "SI"
    else:
        print "NO"