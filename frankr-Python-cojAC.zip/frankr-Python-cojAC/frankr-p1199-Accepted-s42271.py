def f(a, nod):
	if a[nod][1] != -1 and a[nod][2] != -1:
		return a[nod][0] * f(a, a[nod][1]) + f(a, a[nod][2])
	if a[nod][1] != -1 and a[nod][2] == -1:
		return a[nod][0] * f(a, a[nod][1]) 
	if a[nod][1] == -1 and a[nod][2] != -1:
		return a[nod][0] + f(a, a[nod][2]) 
	return a[nod][0]	


for _ in xrange(int(raw_input())):
	n = int(raw_input())
	a = []
	for i in xrange(31):
		a.append([-1, -1, -1])
	r = c = 0
	for x in [int(b) for b in raw_input().split(' ')]:
		r = 0
		if a[r][0] == -1:
			a[r][0] = x
			continue
		p = r
		while r != -1:
			p = r
			if x < a[r][0]:
				r = a[r][1]
			else:
				r = a[r][2]
		c += 1
		if x < a[p][0]:
			a[p][1] = c
		else:
			a[p][2] = c
		a[c][0] = x
	print f(a, 0)