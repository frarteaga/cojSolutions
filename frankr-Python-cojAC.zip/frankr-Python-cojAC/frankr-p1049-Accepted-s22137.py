#By FR

n = int(raw_input())
if n > 0:
	print n * (n + 1) >> 1
else:
	n = -n
	print -((n * (n + 1) >> 1) - 1)