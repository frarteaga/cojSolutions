#By FR

while 1:
	try:
		n = int(raw_input())
		print n * (n + 1) * (n + n + 1) / 6, (n * (n + 1) >> 1) ** 2
	except:
		break
