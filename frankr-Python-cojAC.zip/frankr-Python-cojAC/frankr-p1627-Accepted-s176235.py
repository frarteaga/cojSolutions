def e(n, p):
	r = 0
	while n / p > 0:
		r += n / p
		n /= p
	return r

for _ in range(input()):
	print e(int(raw_input()), 5)