N = int(raw_input())

T = []
mayor = 0
indice = 0
for i in range(0,N):
	T.append( float( raw_input() ) )
	if T[i] >= mayor:
		mayor = T[i]
		indice = i

print indice+1
