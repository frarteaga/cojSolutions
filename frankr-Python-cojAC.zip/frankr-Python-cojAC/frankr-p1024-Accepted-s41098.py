while 1:
    n = float(raw_input())
    if n == 0.0:
        break
    r = 0.0
    i = 2
    while 1:
        r += 1. / float(i)
        if r >= n:
            break
        i += 1
    print str(i - 1) + " card(s)"