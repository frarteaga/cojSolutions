sd = [0] * 501

for d in xrange(1, 256):
	k = 2 * d 
	while k <= 500:
		sd[k] += d
		k += d

for c in xrange(input()):
	n = input()
	if sd[n] < n:
		print 'Deficient'
	elif sd[n] > n:
		print 'Abundant'
	else:
		print 'Perfect'
