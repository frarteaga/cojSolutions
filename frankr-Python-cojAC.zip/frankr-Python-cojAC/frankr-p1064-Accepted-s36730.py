while 1:
#	h1 = m1 = h2 = m2 = 0	
	h1, m1, h2, m2 = [int(x) for x in raw_input().strip().split(' ')]
#	try:
#		h1, m1, h2, m2 = [int(x) for x in raw_input().strip().split(' ')]
#	except:
#		for i in xrange(1, 10 ** 8):
#			for j in xrange(1, 10 ** 8):			
#				s = i + j + 2
	#print h1, m1, h2, m2
	if h1 == m1 == h2 == m2 == 0:
		break
	if (h2 == h1) and (m2 < m1):
		print 24 * 60 - m1 + m2
		continue
	elif h2 < h1:
		h2 += 24
	print (h2 - h1) * 60 - m1 + m2
	