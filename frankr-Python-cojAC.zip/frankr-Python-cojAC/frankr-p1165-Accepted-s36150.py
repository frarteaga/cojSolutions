def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

def lcm(a, b):
    return a * b / gcd(a, b)

while 1:
    L = raw_input()
    if L == "*":
        break
    if L[0] == "N":
        print -1
        continue
    n = 1
    for i in xrange(1, len(L) + 1):
        if L[i - 1] == "Y":
            n = lcm(n, i);
    for i in xrange(1, len(L) + 1):
        if L[i - 1] == "N" and n % i == 0:
            n = -1
            break
    print n
                  