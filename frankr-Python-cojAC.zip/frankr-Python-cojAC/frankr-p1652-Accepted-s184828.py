def h(a, b, c, n):
	if n == 1:
		print 'Move ring from stick ' + a + ' to stick ' + c + '.'
	else:
		h(a, c, b, n - 1)
		print 'Move ring from stick ' + a + ' to stick ' + c + '.'
		h(b, a, c, n - 1)

n = input()
h('1', '2', '3', n)

print "You needs " + str(2 ** n - 1) + " moves."