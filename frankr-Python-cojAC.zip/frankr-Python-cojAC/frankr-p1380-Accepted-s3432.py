t = {'0': '000', '1': '001', '2': '010', '3': '011', '4': '100', '5': '101', '6': '110', '7': '111'}

def tobin(s):
	r = ''
	for d in s:
		r += t[d]
	i = 0
	while r[i] == '0':
		i += 1
	return r[i: ] 
				

while 1:
	n = input()
	if n != 0:
		min = max = raw_input()
		n -= 1
		while n > 0:
			x = raw_input()
			if len(x) > len(max):
				max = x
			elif len(x) == len(max):
				if x > max:
					max = x
			if len(x) < len(min):
				min = x
			elif len(x) == len(min):
				if x < min:
					min = x
			n -= 1
		print tobin(min), tobin(max)
	else:
		break
