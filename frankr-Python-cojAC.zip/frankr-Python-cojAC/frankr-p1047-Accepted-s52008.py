def gcd(a, b):
	while b > 0:
		t = a % b
		a = b
		b = t
	return a

r = [0] * 1001

for i in xrange(2, 1001):
	r[i] = r[i - 1]
	for j in xrange(1, i):
		if gcd(i, j) == 1:
			r[i] += 1


for c in xrange(int(raw_input())):
	n = int(raw_input())
	print c + 1, n, r[n] + r[n] + 3