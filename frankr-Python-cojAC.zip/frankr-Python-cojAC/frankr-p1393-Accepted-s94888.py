n, p = [int(x) for x in raw_input().split()]
s = str(n ** p)
p = 0
while p < len(s):
        print s[p : p + 70]
        p += 70