s = 'Case '
t = 0

while 1:
	try:
		a, b, c = [int(x) for x in raw_input().split()]
		t += 1
	except:
		break
	if a + b == c:
		print s + str(t) + ": " + str(a) + "+" + str(b) + "=" + str(c)
	elif a == b + c:
		print s + str(t) + ": " + str(a) + "=" + str(b) + "+" + str(c)
	elif a - b == c:
		print s + str(t) + ": " + str(a) + "-" + str(b) + "=" + str(c)
	elif a == b - c:
		print s + str(t) + ": " + str(a) + "=" + str(b) + "-" + str(c)
	elif a * b == c:
		print s + str(t) + ": " + str(a) + "*" + str(b) + "=" + str(c)
	elif a == b * c:
		print s + str(t) + ": " + str(a) + "=" + str(b) + "*" + str(c)
	elif (a % b == 0) and (a / b == c):
	#elif a / b == c:
		print s + str(t) + ": " + str(a) + "/" + str(b) + "=" + str(c)
	#elif (b % c == 0) and (a == b / c):
	else:
		print s + str(t) + ": " + str(a) + "=" + str(b) + "/" + str(c)
