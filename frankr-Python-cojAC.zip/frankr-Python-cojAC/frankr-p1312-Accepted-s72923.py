a,b = raw_input().split()
print int(b)*2-int(a)