while 1:
 a, b, c = [abs(int(x)) for x in raw_input().split()]
 if (a, b, c) == (0, 0, 0):
  break
 while b != 0:
  t = b
  b = a % b
  a = t
 if c % a == 0:
  print 'YES'
 else:
  print 'NO'