while 1:
	s = raw_input().replace('%', '%25').replace('!', '%21').replace('$', '%24').replace(' ', '%20').replace('(', '%28').replace(')', '%29').replace('*', '%2a')
	if s == '#':
		break
	print s