for _ in range(input()):
	print 3 ** input() - 1
	