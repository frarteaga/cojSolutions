for _ in range(input()):
        a, b = [float(x) for x in raw_input().split()]
        print round((a * b / (a + b)) ** 2, 4)