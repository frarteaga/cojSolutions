n = input()

a = [int(x) for x in raw_input().split()]
r = [0] * n

for i in xrange(n):
	r[a[i] - 1] = i + 1
	
s = ""
	
for c in r:
	s += str(c) + " "
	
print s[ :-1]