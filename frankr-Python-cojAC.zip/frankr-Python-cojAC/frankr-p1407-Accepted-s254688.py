for _ in xrange(10):
        n = input()
        s = input()
        print (n + s) / 2
        print n - (n + s) / 2
