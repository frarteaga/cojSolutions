#By FR

L = raw_input()

while L != '0':
	t = [int(x) for x in L.split(' ')]
	t.sort()
	if t[0] ** 2 + t[1] ** 2 == t[2] ** 2:
		print 'right'
	else:
		print 'wrong'
	L = raw_input()
