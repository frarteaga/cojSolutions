pn = [6, 28, 496, 8128]

while 1:
	N = input()
	if N == -1:
		break
	R = str(N) + ' '
	if N not in pn:
		R += 'is NOT perfect.' 
	else:
		R += '= 1'
		for d in xrange(2, N / 2 + 1):
			if N % d == 0:
				R += ' + ' + str(d)
	print R