for _ in xrange(input()):
	print 8 * input() + 42