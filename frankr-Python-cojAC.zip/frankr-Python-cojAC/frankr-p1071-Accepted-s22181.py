#By FR

while 1:
	try:
		n = int(raw_input())
		if n == 1:
			print 1
		else:
			print n + n - 2
	except:
		break