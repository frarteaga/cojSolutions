while 1:
	n = input()
	if n == 0:
		break
	maxs = n
	while n > 1:
		if n & 1:
			n = 3 * n + 1
		else:
			n >>= 1
		if n > maxs:
			maxs = n
	print maxs