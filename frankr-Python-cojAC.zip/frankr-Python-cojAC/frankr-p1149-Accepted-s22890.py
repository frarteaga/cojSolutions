#By FR

TT = 0

while 1:
	S, T, N = [int(x) for x in raw_input().split(' ')]
	if T + S + N == 0:
		break
	TT += 1
	s = ('*' * T + '.' * S) * N + '*' * T
	b = '*' * len(s) + '\n'
	s += '\n'
	r = (b * T + s * S) * N + b * T
	print 'Case ' + str(TT) + ':\n' + r
