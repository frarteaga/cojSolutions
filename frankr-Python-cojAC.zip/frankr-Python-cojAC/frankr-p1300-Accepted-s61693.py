s=set()
for _ in range(10):
 s.add(input()%42)
print len(s)