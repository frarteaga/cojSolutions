import string

for _ in xrange(int(raw_input())):
	b = [int(x) for x in raw_input().split()]
	a = ['0'] * 10
	c = range(9, -1, -1)
	i = 9
	while i > -1:
		a[i] = str(c.index(b[i]))
		for j in xrange(int(a[i])):
			c[j] -= 1
		c[int(a[i])] = -1
		i -= 1
	print string.join(a)
		
