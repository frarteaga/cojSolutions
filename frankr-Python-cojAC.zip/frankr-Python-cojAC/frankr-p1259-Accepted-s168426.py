for _ in xrange(int(raw_input())):
	n = raw_input()
	si = sp = 0
	for i in xrange(len(n)):
		if i & 1:
			si += int(n[i])
		else:
			sp += int(n[i])
	if ((si - sp) & 3) == 0:
		print 'YES'
	else:
		print 'NO'
		