#By FR

def mod11(n):
	s = 0
	for i in xrange(0, len(n), 2):
		s += int(n[i])
	for i in xrange(1, len(n), 2):
		s -= int(n[i])		
	return s % 11

n = raw_input()

while n != '0':
	if mod11(n) == 0:
		print n + " is a multiple of 11."
	else:
		print n + " is not a multiple of 11."
	n = raw_input()