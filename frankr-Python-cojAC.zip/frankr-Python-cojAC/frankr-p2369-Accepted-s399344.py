Es = ('A+B*C', 
	  'A*B+C', 
	  'A*(B+C)',
	  '(A+B)*C',
	  'B+A*C',
	  'B*(A+C)')

t = input()

while t > 0:
	A, B, C = [int(x) for x in raw_input().split()]
	Max = -1000000000000000000
	Min = -Max
	for e in Es:
		v = eval(e)
		if v > Max:
			Max = v
		if v < Min:
			Min = v
	print Min, Max
	t -= 1