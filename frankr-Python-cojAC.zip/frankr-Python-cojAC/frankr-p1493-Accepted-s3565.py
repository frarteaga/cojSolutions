r=round
a=PI=3.14
L=raw_input().split()
if len(L)==2:
	a=str(r(float(L[1])**2*PI,2))
else:
	a=str(r(float(L[1])*float(L[2])/2,2))
if len(a.split('.')[1])==1:
	print a+'0'
else:
	print a