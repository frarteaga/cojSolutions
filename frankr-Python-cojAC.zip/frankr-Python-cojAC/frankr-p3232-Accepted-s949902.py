#3232 - Penalty Calculation
#frankr@coj

N = input()

s = []

while N > 0:
	L = raw_input().split()
	P = int(L[0])
	V = L[1]
	s.append((P, V))
	N -= 1
	
s.sort()

r = i = 0
for p, v in s:
	if v == 'AC':
		r = i * 20 + p
		break
	i += 1
	
print r