c = (1, 1, 2, 2, 2, 8)
for _ in xrange(int(raw_input())):
	r = ''
	for x, y in zip(c, [int(a) for a in raw_input().split(' ')]):
		r += str(x - y) + ' '
	print r[ : -1]