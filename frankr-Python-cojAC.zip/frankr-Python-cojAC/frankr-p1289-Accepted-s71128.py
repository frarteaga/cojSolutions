p = [2 ** i for i in range(20)]
#print p
n = 1
while 1:
	try:
		n = input()
	except:
		break
	a = range(n + 1)
	r = a[-1]
	while len(a) > 1:
#		print a
		pp = 0
		while p[pp] < len(a):
			pp += 1
		#print pp
		pp -= 1
		r = a[p[pp]]
		while pp > -1:
			del(a[p[pp]])
			pp -= 1
#	print a
	print r