n = input()
while n > 0:
 A = raw_input()
 m = M = 0
 for c in A:
  if 'a' <= c <= 'z':
   m += 1
  else:
   M += 1
 if M == m:
  print 'SI'
 else:
  print 'NO'
 n -= 1