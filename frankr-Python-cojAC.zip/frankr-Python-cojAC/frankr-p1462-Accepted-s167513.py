s = 0
for _ in range(input()):
	s += (int(raw_input()[-7: ]) & 127)
print s & 127