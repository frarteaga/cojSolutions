while 1:
        n = [s[ : 1].lower() for s in raw_input().split()]
        if n == ['*']:
                break
        for i in xrange(1, len(n)):
                if n[i] != n[i - 1]:
                        print 'N'
                        n = None
                        break
        if n != None:
                print 'Y'
