#By FR

T = int(raw_input())

while T > 0:
    L = raw_input().split(' ')
    n = int(L[0])
    m = int(L[1])
    if n > m:
        if m % 2 == 1:
            print "D"
        else:
            print "U"
    else:
        if n % 2 == 1:
            print "R"
        else:
            print "L"
    T -= 1
