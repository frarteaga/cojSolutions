for _ in xrange(int(raw_input())):
	a, b = raw_input().split()
	print str(int(a[: : -1]) + int(b[: : -1]))[: : -1]