while 1:
	n = raw_input()
	if n == '0':
		break
	r = 0
	p = 2
	for c in n[: : -1]:
		r += (p - 1) * int(c)
		p *= 2
	print r