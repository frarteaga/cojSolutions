while 1:
	a, b = raw_input().split(' ')
	if a == "*" and b == "*":
		break
	i = 0
	while i < len(a) and a[i] == '0':
		i += 1
	a = a[i : ]
	i = 0
	while i < len(b) and b[i] == '0':
		i += 1
	b = b[i : ] 
	if len(a) < len(b):
		print "<"
	elif len(a) > len(b):
		print ">"
	else:
		if a < b:
			print "<"
		elif a > b:
			print ">"
		else:
			print "="