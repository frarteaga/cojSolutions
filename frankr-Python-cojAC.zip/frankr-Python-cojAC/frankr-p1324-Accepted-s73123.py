R = range(9)
a = [0] * 9
for _ in R:
	a[_] = input()
m = [1] * 9
for i in R[: 8]:
	m[i] = 0
	for j in R[i + 1: ]:
		s = m[j] = 0
		for k in R:
			s += m[k] * a[k]
		if s == 100:
			for o in sorted([x for p, x in zip(R, a) if m[p] == 1]):
				print o
		m[j] = 1
	m[i] = 1