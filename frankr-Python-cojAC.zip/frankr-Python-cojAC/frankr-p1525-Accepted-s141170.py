def f(n):
	if n & 1:
		return 1 + (f(n >> 1) << 2)
	return 0

n, m = [int(x) for x in raw_input().split()]

print min(f(n), f(m))