for _ in range(input()):
 if input()%4:
  print 'NO'
 else:
  print 'YES'