n = input()

a = 2 ** n

r = (a + 1) * (a - 1)

sol = str(oct(r))

if sol[-1] == 'L':
	sol = sol[: -1]

print sol[1: ]