while 1:
 a, b = [int(x) for x in raw_input().split()]
 if a == b == 0:
  break
 print pow(a, b, 10)