print 'Lumberjacks:'
n = input()
for nn in xrange(n):
 a = [int(x) for x in raw_input().split()]
 c = True
 for i in xrange(1, len(a)):
  if a[i] < a[i - 1]:
   c = False
   break
 d = True
 for i in xrange(1, len(a)):
  if a[i] > a[i - 1]:
   d = False
   break
 if c or d:
  print 'Ordered'
 else:
  print 'Unordered'
