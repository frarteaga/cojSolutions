a, b = [int(x) for x in raw_input().split(' ')]

while 1:
  if (a == 0 and b == 0):
    break
  print 2 * min(a, b) - max(a, b)
  a, b = [int(x) for x in raw_input().split(' ')]
