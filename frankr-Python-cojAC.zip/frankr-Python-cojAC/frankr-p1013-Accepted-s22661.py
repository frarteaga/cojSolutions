#By FR

while 1:
	n = int(raw_input())
	if n == 0:
		break
	r = 1
	if n > 0:
		for p in xrange(2, 33):
			ini = int(n ** (1./p))
			while ini ** p < n:
				ini += 1
			if ini ** p == n:
				r = p
	else:
		n = -n
		for p in xrange(3, 33, 2):
			ini = int(n ** (1./p))
			while ini ** p < n:
				ini += 1
			if ini ** p == n:
				r = p
	print r
