a = [c for c in raw_input()]
a.sort()
s = ''
for c in a:
	s += c
print s