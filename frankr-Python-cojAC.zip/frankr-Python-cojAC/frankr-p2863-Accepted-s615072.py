a = raw_input()
op = raw_input()
b = raw_input()
if op != '/':
	print eval(a + op + b)
else:
	if a >= b:
		print eval(a + op + b)
	else:
		cz = len(b) - len(a) - 1
		print '0.' + ('0' * cz) + '1'
