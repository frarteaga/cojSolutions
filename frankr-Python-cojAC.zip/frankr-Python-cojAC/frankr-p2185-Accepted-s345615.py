a, b = [int(x) for x in raw_input().split()]
print a + b
print a - b
print a * b
print a / b
print a % b