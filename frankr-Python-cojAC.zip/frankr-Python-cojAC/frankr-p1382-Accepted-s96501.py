for _ in range(input()):
	a, b = [int(x) for x in raw_input().split()]
	a -= 1
	x = int(a ** (1./3)) - 1
	while x ** 3 <= a:
		x += 1
	x -= 1
	y = int(b ** (1./3)) - 1
	while y ** 3 <= b:
		y += 1
	y -= 1
	print (((y * (y + 1)) ** 2) / 4 - ((x * (x + 1)) ** 2) / 4) % 1000007