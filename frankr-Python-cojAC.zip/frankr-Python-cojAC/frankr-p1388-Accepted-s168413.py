for _ in range(input()):
	a, b = [int(x) for x in raw_input().split()]
	print pow(a, b, 10)