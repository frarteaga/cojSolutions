while 1:
    s = raw_input().split()
    for n in s:
        if n == '-1':
            break
        print 'f(' + n + ') =', (int(n) + 1) / 2, '\n'
    if s[-1] == '-1':
        break
