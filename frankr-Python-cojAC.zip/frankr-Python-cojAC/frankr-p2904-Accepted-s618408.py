n = input()
s = 0

while n > 0:
 s += input()
 n -= 1

print s