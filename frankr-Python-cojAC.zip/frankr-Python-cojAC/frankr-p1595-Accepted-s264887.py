while 1:
	n = int(raw_input())
	if n == 0:
		break
	if n == 9:
		print '9 is a multiple of 9 and has 9-degree 1.'
		continue
	d = 1
	s = sum(int(d) for d in str(n))
	while s > 9:
		d += 1
		s = sum(int(d) for d in str(s))
	if s == 9:
		print n, 'is a multiple of 9 and has 9-degree ' + str(d) + '.'
	else:
		print n, 'is not a multiple of 9.'