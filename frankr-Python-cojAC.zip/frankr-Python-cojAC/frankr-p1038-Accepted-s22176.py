#By FR

n = raw_input()

while n != 'END':
	if n == '1':
		print 1
	elif len(n) == 1:
		print 2
	elif len(n) >= 2 and len(n) <= 9:
		print 3
	else:
		print 4
	n = raw_input()