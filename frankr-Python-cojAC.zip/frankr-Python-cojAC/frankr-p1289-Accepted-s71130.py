p = [2 ** i for i in range(12)]
while 1:
	try:
		n = input()
		a = range(n + 1)
		r = a[-1]
		while len(a) > 1:
			pp = 0
			while p[pp] < len(a):
				pp += 1
			pp -= 1
			r = a[p[pp]]
			while pp > -1:
				del(a[p[pp]])
				pp -= 1
		print r
	except:
		break