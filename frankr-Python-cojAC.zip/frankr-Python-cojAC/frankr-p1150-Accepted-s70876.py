for _ in range(1000):
	n = input() % 10
	if n:
		print '1\n' + str(n)
	else:
		print 2
