X = input()
Y = input()

R = 1. - Y / X

SR = str(round(R, 2))

if SR[-2] == '.': 
	SR += "0"
	
print SR