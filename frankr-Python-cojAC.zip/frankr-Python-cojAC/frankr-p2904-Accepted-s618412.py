n = input()
s = 0

while n > 0:
 L = raw_input()
 try:
  s += int(L)
 except:
  pass
 n -= 1

print s