T = input()
while T > 0:
	N, K = [int(x) for x in raw_input().split()]
	print pow(K + 1, N, 1000000007)
	T -= 1