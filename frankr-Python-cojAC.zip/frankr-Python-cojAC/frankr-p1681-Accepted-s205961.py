a, b, c = [float(x) for x in raw_input().split()]
if b * b - 4 * a * c >= 0:
	print 'YES'
else:
	print 'NO'