for _ in range(input()):
	if (int(raw_input(), 16) & 1):
		print "YES"
	else:
		print "NO"