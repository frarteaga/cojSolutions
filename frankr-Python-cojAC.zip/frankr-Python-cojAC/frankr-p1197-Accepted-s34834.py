a = [int(x) for x in raw_input().split('.')]
b = [int(x) for x in raw_input().split('.')]

print a[3] + a[2] * 256 + a[1] * 65536 + a[0] * 65536 * 256 - (b[3] + b[2] * 256 + b[1] * 

65536 + b[0] * 65536 * 256) + 1