#By FR

n = int(raw_input())

if n % 3 == 0:
	res = n / 3 * 2
elif n % 3 == 2:
	res = (n - 1) / 3 * 2 + 1
else:
	res = (n - 1) / 3 * 2 

print res
