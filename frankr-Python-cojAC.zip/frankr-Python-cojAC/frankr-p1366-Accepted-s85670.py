for _ in range(input()):
	n = input()
	p = 5
	r = 0
	while n > 0:
		r += p * (n & 1)
		p *= 5
		n /= 2
	print r