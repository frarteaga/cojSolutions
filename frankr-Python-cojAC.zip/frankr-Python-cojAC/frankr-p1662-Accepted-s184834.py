import string
for _ in xrange(input()):
	s = raw_input()
	l = r = ''
	n = 0
	for c in s:
		if c in string.uppercase:
			r += l * n
			n = 0
			l = c
		else:
			n = n * 10 + int(c)
	print 'Case ' + str(_ + 1) + ': ' + r + l * n