k = int(raw_input())
a = [int(x) for x in raw_input().split(' ')]
a.sort()
res = 0
for i in xrange(k / 2 + 1):
	res += a[i] / 2 + 1
print res