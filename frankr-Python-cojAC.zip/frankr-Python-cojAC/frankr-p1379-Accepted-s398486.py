
LN_ = ['', '6']
def LN(n):
	global LN_
	MC = len(LN_) - 1
	if n <= MC:
		return LN_[n]
	Num = LN_[MC][: ]
	while MC < n:
		MC += 1
		if '6' not in Num:
			LN_.append('6' + Num.replace('8', '6'))
		elif '8' not in Num:
			LN_.append('8' + Num[1: ])
		else:
			LN_.append(Num.replace('86', '88'))
		Num = LN_[MC][: ]
	return LN_[MC]

"""
LN(10)
LN(100)
print LN_[: 11]
"""

t = input()
while t > 0:
	x = input()
	if (x % 10) % 5 == 0:
		print -1
	else:
		p = 1
		while 1:
			Num = LN(p)
			#print 'DDDD ', p, Num
			if len(Num) > 200:
				print -1
				break
			if int(Num) % x == 0:
				print Num
				break
			p += 1	
	t -= 1	

"""
i = 1
while 1:
	#print LN(i)
	if len(LN(i)) > 200:
		break
	i += 1

print len(LN_)

#input()
"""