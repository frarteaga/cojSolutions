for _ in xrange(int(raw_input())):
	s = raw_input().replace('()', '0').replace('(*)', '1')
	print 'Case ' + str(_ + 1) +  ': ' + str(int(s[ : 2], 2)) + str(int(s[2 : 6], 2)) + ':' + str(int(s[6 : 9], 2)) + str(int(s[9 : 13], 2)) + ':' + str(int(s[13 : 16], 2)) + str(int(s[16: 20], 2))
	