while 1:
        n = input()
        if n == -1:
                break
        r = ''
        while n > 0:
                r = str(n % 3) + r
                n /= 3
        print r
