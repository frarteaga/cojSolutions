r = input()
print 'A' + 'a' * r * 4 + 'h'