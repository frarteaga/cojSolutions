for _ in xrange(int(raw_input())):
  raw_input()
  n = int(raw_input())
  s = 0
  for i in xrange(n):
    s += int(raw_input())
  if s % n == 0:
    print "YES"
  else:
    print "NO"

