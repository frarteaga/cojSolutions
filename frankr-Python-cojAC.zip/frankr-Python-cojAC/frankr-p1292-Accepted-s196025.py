a = ''
b = ''
d = {}

def f(la, lb):
	if la < lb:
		return 0
	if d.get((la, lb)) != None:
		return d[(la, lb)]
	if lb == 1:
		r = 0
		for i in xrange(la):
			if a[i] == b[0]:
				r += 1
		d[(la, lb)] = r
	else:
		r = f(la - 1, lb)
		if a[la - 1] == b[lb - 1]:
			r += f(la - 1, lb - 1)
		d[(la, lb)] = r
	return r

for _ in xrange(int(raw_input())):
	d = {}
	a = raw_input()
	b = raw_input()
	print f(len(a), len(b))