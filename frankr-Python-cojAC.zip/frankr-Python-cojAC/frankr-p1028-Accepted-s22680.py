#By FR

while 1:
	try:
		s, t = raw_input().split(' ')
		i = 0
		for c in t:
			if c == s[i]:
				i += 1
				if i == len(s):
					break
		if i == len(s):
			print 'Yes'
		else:
			print 'No'
	except:
		break
