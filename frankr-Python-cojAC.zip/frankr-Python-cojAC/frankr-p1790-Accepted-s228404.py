n = input()
a = [int(x) for x in raw_input().split()]
mi = ma = a[0]
s = 0
for x in a[1: ]:
	if x > ma:
		ma = x
		s += 1
	if x < mi:
		mi = x
		s += 1
print s