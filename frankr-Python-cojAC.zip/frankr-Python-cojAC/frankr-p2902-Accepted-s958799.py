while 1:
	try:
		N, K = [int(x) for x in raw_input().split()]
		print pow(pow(2, K, 10 ** 9) - 2, N, 10 ** 9)
	except:
		break