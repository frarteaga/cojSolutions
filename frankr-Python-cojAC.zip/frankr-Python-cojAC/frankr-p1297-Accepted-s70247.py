for _ in range(input()):
 r='YES'
 if input()%495:
  r='NO'
 print r 