def f(N, P):
	r = 0
	while N / P > 0:
		r += N / P
		N /= P
	return r;

def o(x):
	if x == 0:
		return '0'
	os = str(oct(x))[1: ]
	if os[-1] == 'L':
		return os[: -1]
	return os
	

while 1:
	try:
		A, B, P = [int(x) for x in raw_input().split()]
		print o(f(B, P) - f(A - 1, P))
	except:
		break
