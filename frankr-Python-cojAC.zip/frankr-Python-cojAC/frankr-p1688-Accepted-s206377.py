while 1:
	c = input()
	if c == -1:
		break
	elif c == 3:
		w, h = [int(x) for x in raw_input().split()]
		print ('*' * w + '\n') * h
	elif c == 2:
		w, h = [int(x) for x in raw_input().split()]
		s = ''
		for f in xrange(h):
			s += ' ' * (h - 1 - f) + '*' * w + '\n'
			#print 'd- ', s
		print s
	else:
		h = input()
		s = ''
		for f in xrange(h):
			s += ' ' * (h - 1 - f) + '*' * (2 * f + 1) + '\n'
		print s