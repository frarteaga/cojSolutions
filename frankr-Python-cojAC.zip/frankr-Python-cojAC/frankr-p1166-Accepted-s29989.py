for _ in xrange(int(raw_input())):
	n = int(raw_input())
	odd = 0
	for x in (int(d) for d in raw_input().split(' ')):
		odd += (x & 1)
	print str(n - odd) + " even and " + str(odd) + " odd."