for _ in xrange(input()):
	u = raw_input().split()
	print u[0][: 3] + '*'.join(u[1: ]) + u[0][3: ]