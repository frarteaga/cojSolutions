#By FR

def __gcd__(a, b):
	while b:
		a, b = b, a % b
		#t = a % b
		#a = b
		#b = t
	return a

class frac:
	"""
	FIXME
	"""

	def __init__(self, n, d):
		if d == 0:
			raise ZeroDivisionError()
		g = __gcd__(n, d)
		self.n = n / g
		self.d = d / g

	def __str__(self):
		if self.d == 1:
			return str(self.n)
		return str(self.n) + "/" + str(self.d)

	def __add__(self, y):
		return frac(self.n * y.d + y.n * self.d, self.d * y.d)

	def __sub__(self, y):
		return frac(self.n * y.d - y.n * self.d, self.d * y.d)

	def __mul__(self, y):
		return frac(self.n * y.n, self.d * y.d)


x = [0, frac(0, 1)]
y = [0, frac(0, 1)]


for i in xrange(2, 16):
	x.append( (frac(1, 1) - frac(2, i)) * x[i - 1] - frac(1, i) * y[i - 1] + frac(4, i) )
	y.append( (frac(1, 1) - frac(1, i)) * y[i - 1] - frac(1, i) * x[i - 1] + frac(3, i) )
			  
while 1:
	n = input()
	if n == 0:
		break
	print "(x" + str(n) + ",y" + str(n) + ") = (" + str(x[n]) + "," + str(y[n]) + ")"
