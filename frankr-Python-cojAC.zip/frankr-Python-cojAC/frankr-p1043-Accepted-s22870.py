#By FR

def bin(n):
	r = ""
	while n > 0:
		r = str(n & 1) + r
		n >>= 1
	return r

for _ in xrange(int(raw_input())):
	n = int(raw_input())
	b = bin(n)
	p = len(b) - 1
	r = 0
	s = ''
	while p > -1:
		if b[p] == '1':
			s += str(r) + ' '
		r += 1
		p -= 1
	print s[ : -1]