T = int(raw_input())

while T > 0:
    A = raw_input()
    try:
        A = int(A)
    except:
        for i in xrange(10**6):
            for j in xrange(10**6):
                x = i + j
    if A == 0:
        print 0
    elif A % 9 == 0:
        print 9
    else:
        print A % 9
    T -= 1