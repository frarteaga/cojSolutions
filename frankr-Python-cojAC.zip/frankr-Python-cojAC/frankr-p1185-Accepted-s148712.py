import functools

def memoize(function):
    cache = {}
    @functools.wraps(function)
    def memoized(*args):
        if args in cache:
            return cache[args]
        else:
            res = function(*args)
            cache[args] = res 
            return res 
    return memoized

@memoize
def f(d, t, c, s):
	if d + t + c + s == 0:
		return 0
	res = int('2' * d + '3' * t + '5' * c + '7' * s)
	if t >= 1:
		r = f(d, t -1, c, s) 
		if 10 * r + 3 < res:
			res = 10 * r + 3
		r = int('3' + str(r))
		if r < res:
			res = r
	if d >= 1:
		r = f(d - 1, t, c, s) 
		if 10 * r + 2 < res:
			res = 10 * r + 2
		r = int('2' + str(r))
		if r < res:
			res = r
	if t >= 2:
		r = f(d, t - 2, c, s) 
		if 10 * r + 9 < res:
			res = 10 * r + 9
		r = int('9' + str(r))
		if r < res:
			res = r
	if t >= 1 and d >= 1:
		r = f(d - 1, t - 1, c, s) 
		if 10 * r + 6 < res:
			res = 10 * r + 6
		r = int('6' + str(r))
		if r < res:
			res = r
	if d >= 3:
		r = f(d - 3, t, c, s)
		if 10 * r + 8 < res:
			res = 10 * r + 8
		r = int('8' + str(r))
		if r < res:
			res = r
	if d >= 2:
		r = f(d - 2, t, c, s) 
		if 10 * r + 4 < res:
			res = 10 * r + 4
		r = int('4' + str(r))
		if r < res:
			res = r
	if c >= 1:
		r = f(d, t, c - 1, s) 
		if 10 * r + 5 < res:
			res = 10 * r + 5
		r = int('5' + str(r))
		if r < res:
			res = r
	if s >= 1:
		r = f(d, t, c, s - 1) 
		if 10 * r + 7 < res:
			res = 10 * r + 7
		r = int('7' + str(r))
		if r < res:
			res = r
	return res

while 1:
	try:
		n = input()
		if n < 10:
			if n == 0:
				print 10
				continue
			print n
			continue
		f2 = f3 = f5 = f7 = 0
		while (n & 1) == 0:
			f2 += 1
			n >>= 1
		while n % 3 == 0:
			f3 += 1
			n /= 3
		while n % 5 == 0:
			f5 += 1
			n /= 5
		while n % 7 == 0:
			f7 += 1
			n /= 7
		if n > 1:
			print -1
		else:
			print f(f2, f3, f5, f7)
	except:
		break
