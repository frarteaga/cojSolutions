t = input()
while t > 0:
	t -= 1
	n, k, ty = raw_input().split()
	n = int(n)
	k = int(k)
	a = [int(x) for x in raw_input().split()]
	a.sort()
	if ty == 'regulate':
		print sum(a[-k: ])
	else:
		print sum(a[: k])
	