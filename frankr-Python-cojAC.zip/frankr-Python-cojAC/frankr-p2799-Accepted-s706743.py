a = input()
b = input()
c = input()

if a <= 0 or b <= 0 or c <= 0 or a + b + c != 180:
	print 'Error'
elif a == b == c:
	print 'Equilateral'
elif a == b or b == c or c == a:
	print 'Isosceles' 
else:
	print 'Scalene'