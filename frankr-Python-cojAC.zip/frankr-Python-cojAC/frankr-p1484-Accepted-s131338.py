p=r=0
for _ in range(input()):
 e=float(input())
 if e>=r:
  p=_+1
  r=e
print p
