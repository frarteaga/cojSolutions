for _ in range(input()):
 r='YES'
 if input()%4:
  r='NO'
 print r
