#By FR

s = [None] * 12
a = [0.0] * 12

for _ in xrange(12):
	s[_] = raw_input().strip()
	a[_] = float(s[_])
	
p = len(s[-1].split('.')[1])

print "$"+str(round((sum(a) / 12.), p))
