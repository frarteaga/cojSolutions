while 1:
        a, b, c = [int(x) for x in raw_input().split()]
        if a == b == c == 0:
                break
        if b + b == a + c:
                print 'AP', c + c - b
        else:
                print 'GP', c * c / b