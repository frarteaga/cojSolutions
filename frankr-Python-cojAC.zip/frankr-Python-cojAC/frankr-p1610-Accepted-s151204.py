t = int(raw_input())

while t > 0:
	l = raw_input().split()
	if l[1] == "0":
		print "Airborne wins."
	else:
		print "Pagfloyd wins."	
	t -= 1