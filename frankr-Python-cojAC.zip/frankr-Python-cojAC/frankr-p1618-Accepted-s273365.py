while 1:
 try:
  n, a, b = [int(x) for x in raw_input().split()]
  print min(n - a, b + 1)
 except:
  break 