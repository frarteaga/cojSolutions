#By FR

s = [0] * 1001

for i in xrange(1, 1001):
	s[i] = (s[i - 1] + i * (i + 1) * (i + 2)) % 100

for _ in xrange(int(raw_input())):
	a, b = [int(x) for x in raw_input().split(' ')]
	r = s[b] - s[a - 1]
	if r < 0:
		print r + 100
	else:
		print r

