n = input()

r = 1

for a in [int(x) for x in raw_input().split()]:
	r *= a

q = input()

for x in raw_input().split():
	if r % int(x) == 0:
		print 'YES'
	else:
		print 'NO'
