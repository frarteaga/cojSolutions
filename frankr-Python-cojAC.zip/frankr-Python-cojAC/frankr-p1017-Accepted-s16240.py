#By FR

n = int(raw_input()) - 1

while n > -1:
    r = '{ '
    p = 1
    while n > 0:
        if n & 1 == 1:
            r += str(p) + ', ' 
        n >>= 1
        p *= 3
    r = r[:-2] + ' }'    
    print r
    n = int(raw_input()) - 1
