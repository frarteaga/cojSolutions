def is_prime(n):
	i = 3
	while i * i <= n:
		if n % i == 0:
			return False
		i += 2
	return True

p = [[], [2, 3, 5, 7]]

for d in xrange(2, 9):
	p.append([])
	for prime in p[d - 1]:
		for c in (1, 3, 7, 9):
			if is_prime(prime * 10 + c):
				p[d].append(prime * 10 + c)
	

while 1:
	try:
		n = int(raw_input())
		for x in p[n]:
			print x
	except:
		break	