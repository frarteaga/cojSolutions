d = {'W' : 1., 'H': .5, 'Q': .25, 'E': .125, 'S': .0625, 'T': 1./32, 'X': 1./64}
while 1:
	try:
		print len([n for n in raw_input().split('/') if sum([d[c] for c in n]) == 1])
	except:
		break
