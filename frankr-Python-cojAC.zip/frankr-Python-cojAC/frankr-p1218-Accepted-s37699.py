d = {}

def f(n, k):
	global d
	if d.get((n, k)) != None:
		return d[(n, k)]
	r = n + 1
	for i in xrange(2, k):
		r *= (n + i)
		r /= i
	d[(n, k)] = r
	return r

for _ in xrange(int(raw_input())):
	k = int(raw_input())
	a = set([int(x) for x in raw_input().strip().split(' ')])
	s = 0
	for e in a:
		s += f(e, k)
	print s
