sa = []

def ps(n, p, r):
	if p == len(n):
		sa.append(r)
		return
	if n[p] == '5' or n[p] == '6':
		ps(n, p + 1, r + '5')	
		ps(n, p + 1, r + '6')
	else:
		ps(n, p + 1, r + n[p])


a, b = raw_input().split()

ps(a, 0, '')
csa = sa[: ]
sa = []
ps(b, 0, '')

#print csa, sa

Min = 1000000000000
Max = 0
for va in csa:
	for vb in sa:
		if int(va) + int(vb) > Max:
			Max = int(va) + int(vb)
		if int(va) + int(vb) < Min:
			Min = int(va) + int(vb)

print Min, Max
