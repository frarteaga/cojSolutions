t = input()

while t > 0:
	L = raw_input().split()
	n = int(L[0])
	s = L[1]
	p = int(L[2])
	if s == 'odd':
		print 2 * p
	else:
		print 2 * p - 1
	t -= 1
