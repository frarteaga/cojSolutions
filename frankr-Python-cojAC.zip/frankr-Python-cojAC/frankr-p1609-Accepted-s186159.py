import functools

def memoize(function):
    cache = {}
    @functools.wraps(function)
    def memoized(*args):
        if args in cache:
            return cache[args]
        else:
            res = function(*args)
            cache[args] = res
            return res
    return memoized

@memoize
def f(n, m):    
    if n == 0:
        return [[],]
    if n < 0:
        return []
    if m == 0:
        return []
    r = f(n, m - 1)[: ]
    r1 = f(n - m, m); 
    for e in r1:
        r.append(e + [m,])
    return r

t = input()
for _ in xrange(t):
	n = input()
	r = f(n, n)
	r.sort()
	for p in r:
		pp = (str(x) for x in p)
		print n, '= ' + ' + '.join(pp)
	if _ < t - 1:
		print

#print f(4, 4)

#for i in xrange(1, 40):
#	print i, len(f(i, i))
