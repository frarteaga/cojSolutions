r=[]
for _ in range(input()):
 r+=[input()]
for x in sorted(r):
 print x