import math

while 1:
    r = raw_input().strip().split()
    if r[0] == r[1] == r[2] == '0':
        break
    L = float(r[0])
    n = int(r[1])
    k = int(r[2])
    r1 = float(k) / n 
    r2 = float(n - k) / n 
    print int(round((L ** 2 * 3 ** (1./2.)) / 4 - 3 * (math.sin(60. / 180. * math.pi) * (L ** 2) * r1 * r2 * 1./2)))