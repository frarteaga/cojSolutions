N, M = [int(x) for x in raw_input().split()]

s1 = sum([int(x) for x in raw_input().split()])
s2 = sum([int(x) for x in raw_input().split()])

if s1 > s2:
	print "first win"
elif s2 > s1:
	print "second win"
else:
	print "tie"