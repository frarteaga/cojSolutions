import string

pots = {}
p = 1
for c in string.lowercase:
	pots[c] = p
	p <<= 1
	
lr = string.lowercase[: : -1]
def rights_from_number(n):
	global lr
	r = ''
	for c in lr:
		if n >= pots[c]:
			n -= pots[c]
			r = c + r
	return r

id = 0
while 1:
	entrys = raw_input().split(',')
	if entrys[0] == '#':
		break
	acl = {}
	for E in string.uppercase:
		acl[E] = 0 #no rights at the beginig
	id += 1
	sol = str(id) + ':'
	for en in entrys:
		eq = en.find('=')
		if eq != -1:
			r = 0
			for c in en[eq + 1: ]:
				r += pots[c]
			for E in en[: eq]:
				acl[E] = r
			#print 'Debug', acl
		else:
			ma = en.find('+')
			if ma != -1:
				for E in en[: ma]:
					for c in en[ma + 1: ]:
						if (acl[E] & pots[c]) == 0:
							acl[E] = acl[E] + pots[c]
				#print 'Debug', acl
			else:
				mi = en.find('-')
				for E in en[: mi]:
					for c in en[mi + 1: ]:
						if (acl[E] & pots[c]) != 0:
							acl[E] = acl[E] - pots[c]
	i = ord('A')
	while i <= ord('Z'):
		if acl[chr(i)] != 0:
			j = i + 1
			while j <= ord('Z') and (acl[chr(i)] == acl[chr(j)] or acl[chr(j)] == 0):
				j += 1
			Es = ''
			Rs = rights_from_number(acl[chr(i)])
			for E in xrange(i, j):
				if acl[chr(E)] != 0:
					Es += chr(E)
			sol += Es+Rs
			i = j 
		else:
			i += 1
	print sol