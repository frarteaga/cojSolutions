d = {1:1}

#mm = 0

def f(n):
#global mm 
#	if n > mm:
#		mm = n
	if d.get(n) == None:
		if n & 1:
			d[n] = 1 + f(3 * n + 1)
		else:
			d[n] = 1 + f(n >> 1)
	return d[n]

L = ''
	
while 1:
	try:
		L = raw_input().strip()
	except:
		break
	while L.find('  ') != -1:
		L = L.replace('  ', ' ')
	n, m = [int(x) for x in L.split(' ')]
	e = 0
	if m < n:
		n, m = m, n
		e = 1
	max = f(n)
	for i in xrange(n + 1, m + 1):
		if f(i) > max:
			max = d[i]
	if e == 0:
		print str(n) + ' ' + str(m) + ' ' + str(max)
	else:
		print str(m) + ' ' + str(n) + ' ' + str(max)
#	print 'mm ', mm
#	print len(d)