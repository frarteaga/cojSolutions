import math

d = [0] * 1001

d[1] = 1
d[2] = 2
d[3] = 3

for i in xrange(4, 1001):
	if i & (i - 1) == 0:
		d[i] = d[i - 1]
	else:
		a = d[i - 1]
		n = i
		while 1:
			a -= (int(math.log(a, 2)) + 1)
			if a & (a - 1) == 0:
				d[i] = i
				break
			n -= (int(math.log(n, 2)) + 1)
			if n & (n - 1) == 0:
				d[i] = d[i - 1]
				break

while 1:
	try:
		n = int(raw_input())
		print d[n]
	except:
		break