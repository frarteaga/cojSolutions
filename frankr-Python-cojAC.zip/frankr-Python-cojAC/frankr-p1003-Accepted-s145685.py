for _ in range(input()):
	n, m = [int(x) for x in raw_input().split()]
	a = [0] * n
	for i in range(m):
		s = [int(y) for y in raw_input().split()]
		for j in range(n):
			a[j] += s[j]
	r = 0
	for j in range(1, n):
		if a[j] > a[r]:
			r = j
	print r + 1