#Primorial
#frankr@coj

primes = [2, 3, 5, 7, 11]

def prime(N):
	global primes
	for p in primes:
		if p * p > N:
			break
		if N % p == 0:
			return False
	return True
	
def primorial(N):
	r = 1
	for x in xrange(2, N + 1):
		if prime(x):
			r *= x
	return r;

T = input()

while T > 0:
	N = input()
	print primorial(N)
	T -= 1
