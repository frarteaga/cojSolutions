n = input()
s = 0

def isI(K):
    try:
        int(K)
        return True
    except:
        return False

while n > 0:
    L = raw_input()
    if (isI(L)):
        s += int(L)
        n -= 1

print s