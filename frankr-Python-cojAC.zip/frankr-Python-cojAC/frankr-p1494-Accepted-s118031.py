print 'I got my first solution!!!'
