R = ['B', 'A']

K, L, M = [int(x) for x in raw_input().split()]

dp = [0] * 1000001
dp[1] = dp[K] = dp[L] = 1

for i in xrange(2, 1000001):
	if dp[i - 1] == 0:
		dp[i] = 1
	if i - K > 0 and dp[i - K] == 0:
		dp[i] = 1
	if i - L > 0 and dp[i - L] == 0:
		dp[i] = 1
		
Res = ""
for N in [int(x) for x in raw_input().split()]:
	Res += R[dp[N]]
print Res
	
#input()