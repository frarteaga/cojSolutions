import string

def eliminateP(s):
	"""
	>>> eliminateP('((A))+(B)')
	'A+B'
	>>> eliminateP('A+(B+(C*J)+D)')
	'A+B+C*J+D'
	"""
	#print s
	if '(' not in s:
		return s
	if '*' not in s:
		return s.replace('(', '').replace(')', '')
	if '+' not in s:
		return s.replace('(', '').replace(')', '')
	if s[0] == '(' and s[-1] == ')':
		cp = 0
		z = 0
		for x in s:
			if x == '(':
				cp += 1
			elif x == ')':
				cp -= 1
				if cp == 0:
					z += 1
		if z == 1:
			return eliminateP(s[1: -1])
	ts = terms1p(s)
#	print ts
	if len(ts) > 1:
		i = 0
		while i < len(ts):
			ts[i] = eliminateP(ts[i])
			i += 1
		return string.join(ts, '+')
	else:
		return s


def terms1(s):
	"""
	>>> terms1('A')
	['A']
	>>> terms1('A*B')
	['A*B']
	>>> terms1('B*(C+A)+A')
	['B*(C+A)', 'A']
	>>> terms1('(B*(C+A))*D+A*E')
	['(B*(C+A))*D', 'A*E']
	>>> terms1('(B*(C+(E+Y)*A))*D+A*(C+F)*E+(R*J+Y)+I')
	['(B*(C+(E+Y)*A))*D', 'A*(C+F)*E', 'R*J', 'Y', 'I']
	"""
	r = []
	t = ''
	i = 0
	while i < len(s):
		x = s[i]
		if x in string.uppercase + '*':
			t += x
			i += 1
		elif x == '+':
			#print t
			r.extend(terms1p(eliminateP(t)))
			t = ''
			i += 1
		elif x == '(':
			cp = 0
			while 1:
				t += x
				i += 1
				if x == ')':
					cp -= 1
					if cp == 0:
						break
				elif x == '(':
					cp += 1
				x = s[i]
	r.extend(terms1p(eliminateP(t)))
	return r		
	
def terms1p(s):
	"""
	>>> terms1p('A')
	['A']
	>>> terms1p('(A*B)')
	['(A*B)']
	>>> terms1p('B*(C+A)+A')
	['B*(C+A)', 'A']
	>>> terms1p('(B*(C+(E+Y)*A))*D+A*(C+F)*E+(R*J+Y)+I')
	['(B*(C+(E+Y)*A))*D', 'A*(C+F)*E', '(R*J+Y)', 'I']
	"""
	r = []
	t = ''
	i = 0
	while i < len(s):
		x = s[i]
		if x in string.uppercase + '*':
			t += x
			i += 1
		elif x == '+':
#			print t
			r.append(t)
			t = ''
			i += 1
		elif x == '(':
			cp = 0
			while 1:
				t += x
				i += 1
				if x == ')':
					cp -= 1
					if cp == 0:
						break
				elif x == '(':
					cp += 1
				x = s[i]
	r.append(t)
	return r	
	
def factors1(s):
	"""
	>>> factors1('(A)')
	['A']
	>>> factors1('A*B')
	['A', 'B']
	>>> factors1('(A*B)*(C+D)')
	['A*B', 'C+D']
	>>> factors1('(A*B)*(C+D*H)')
	['A*B', 'C+D*H']
	"""
	s = eliminateP(s)
	r = []
	t = ''
	i = 0
	while i < len(s):
		x = s[i]
		if x in string.uppercase + '+':
			t += x
			i += 1
		elif x == '*':
			#FIXME
			r.append(eliminateP(t))
			t = ''
			i += 1
		elif x == '(':
			cp = 0
			while 1:
				t += x
				i += 1
				if x == ')':
					cp -= 1
					if cp == 0:
						break
				elif x == '(':
					cp += 1
				x = s[i]
	r.append(eliminateP(t))
	return r		
	
def expand(s):
	"""
	>>> expand('A*((C+D)*B)+(F)')
	'['A*C*B', 'A*D*B', 'F']
	"""
	r = []
	ts = terms1(s)
	for t in ts:
		if '+' not in t:
			r.append(t)
		else:
			rf = ['']
			fs = factors1(t)
			for f in fs:
				if '+' not in f:
					for i in xrange(0, len(rf)):
						if rf[i] != '':
							rf[i] = rf[i] + '*' + f	
						else:
							rf[i] = f
				else:
					of = expand(f)
					co = rf[: ]
					rf = []
					for f1 in co:
						for f2 in of:
							if f1 != '':
								rf.append(f1 + '*' + f2)
							else:
								rf.append(f2)
			r.extend(rf)
	return r

def cmp(a, b):
	if len(a) > len(b):
		return -1
	elif len(a) < len(b):
		return 1
	else:
		if a < b:
			return -1
		else:
			return 1

T = input()
for _ in xrange(T):
	r = expand(raw_input().strip())
	for i in xrange(len(r)):
		rr = sorted(r[i].replace('*', ''))
		r[i] = string.join(rr, '*')
	print string.join(sorted(r, cmp), '+')
	
	
	
	
#print expand('(((A)+C)*((D+(B))*((F+E)))+((T)*T)+((G+(U)*U+I)))')

#print eliminateP('B*(C+A)+A')	
#print eliminateP('((A))')
#print eliminateP('((((A))+((B)*G))+(((F)+(H*(O)))))')

"""
def factors1p(s):
	r = []
	t = ''
	i = 0
	while i < len(s):
		x = s[i]
		if x in string.uppercase + '+':
			t += x
			i += 1
		elif x == '*':
			r.append(t)
			t = ''
			i += 1
		elif x == '(':
			cp = 0
			while 1:
				t += x
				i += 1
				if x == ')':
					cp -= 1
					if cp == 0:
						break
				elif x == '(':
					cp += 1
				x = s[i]
	r.append(t)
	return r		
"""
