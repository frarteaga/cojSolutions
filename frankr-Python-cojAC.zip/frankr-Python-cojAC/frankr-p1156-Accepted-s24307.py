while 1:
  try:
    n = raw_input()
    if n == '42':
      break
    print n
  except:
    break 