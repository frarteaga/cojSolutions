for _ in range(input()):
        if int(raw_input()[-2 : ]) % 4 == 0:
                print 'YES'
        else:
                print 'NO'
