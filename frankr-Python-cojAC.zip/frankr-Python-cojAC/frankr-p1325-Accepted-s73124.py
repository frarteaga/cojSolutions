r = 0
for i in range(4):
	a = raw_input()
	for j in range(4):
		if a[j] != '.':
			k = ord(a[j]) - 65
			r += abs(k / 4 - i) + abs(k % 4 - j)
print r