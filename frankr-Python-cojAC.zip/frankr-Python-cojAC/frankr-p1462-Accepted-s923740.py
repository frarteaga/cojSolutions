N = input()

solve = 0

for i in xrange(0,N):
    temp = (input())%128

    solve = ( solve + temp)%128

print solve