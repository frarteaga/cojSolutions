n = input()                                                    
r = raw_input()                                                
for _ in range(input()):                                       
        s = raw_input()                                        
        p = float(n)                                           
        for k in range(n):                                     
                if s[k] == '#':                                
                        p -= 1                                 
                elif s[k] != r[k]:                             
                        p -= 1.25                              
        print "%.2f" % p