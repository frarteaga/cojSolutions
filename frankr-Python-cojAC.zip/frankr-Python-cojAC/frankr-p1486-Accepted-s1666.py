try:
    import math
except:
    for i in range(10000000):
        for j in range(100000):
            x = pow(i, j, 30011)
for _ in range(input()):
    o = [int(x) for x in raw_input().split()]
    r = 1
    for x in o:
        r *= math.factorial(x)
    print math.factorial(sum(o)) / r