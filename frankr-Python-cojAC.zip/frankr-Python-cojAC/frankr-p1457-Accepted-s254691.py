n, k = [int(x) for x in raw_input().split()]

print n * (n - 1) / 2 * k
